# Набор субагентов: Веб-разработка и Telegram-боты

7 субагентов для Claude Code, которые закрывают полный цикл веб-проекта и Telegram-бота: от схемы БД и API до фронтенда, тестов, деплоя и ревью.

## Состав

| Агент | Что делает | Пишет код | Модель |
|---|---|---|---|
| `frontend-dev` | Страницы, компоненты, формы, адаптив, доступность (React/Next/Vue/Svelte, Tailwind) | да | sonnet |
| `backend-api-dev` | REST/GraphQL/WebSocket, авторизация, вебхуки, интеграции (Node, FastAPI, Django, Go) | да | sonnet |
| `tg-bot-dev` | Боты: команды, клавиатуры, FSM, inline, платежи, Mini Apps, рассылки (aiogram 3, PTB, grammY, Telegraf) | да | sonnet |
| `database-designer` | Схема, связи, индексы, безопасные миграции (Prisma, Drizzle, SQLAlchemy/Alembic, Django) | да | sonnet |
| `web-tester` | Unit / API / e2e тесты (Vitest, Jest, Playwright, pytest), моки Telegram | только тесты | sonnet |
| `devops-deployer` | Docker, compose, Nginx/Caddy, HTTPS, CI/CD, VPS/Vercel/Render, бэкапы | конфиги | sonnet |
| `web-reviewer` | Ревью перед коммитом: баги, OWASP, секреты, UX, лимиты Telegram API | нет (read-only) | sonnet |

## Установка

**Вариант 1 — через Claude (рекомендуется).** Открой `INSTALL_PROMPT.md`, скопируй промт и вставь в Claude Code. Claude спросит, ставить глобально или в проект, проверит конфликты имён и скопирует файлы.

**Вариант 2 — вручную.**

Глобально (для всех проектов):
```bash
mkdir -p ~/.claude/agents && cp -n ~/Desktop/Claude-субагенты-1-Веб-и-ТГ-боты/agents/*.md ~/.claude/agents/
```

Только в текущий проект (выполнить в корне проекта):
```bash
mkdir -p .claude/agents && cp -n ~/Desktop/Claude-субагенты-1-Веб-и-ТГ-боты/agents/*.md .claude/agents/
```

`cp -n` не перезапишет уже существующие файлы с тем же именем. После установки открой новую сессию Claude Code.

## Как пользоваться

Claude сам выбирает агента по описанию задачи, но надёжнее назвать его явно:

- «Используй **tg-bot-dev**: сделай бота-записи к мастеру на aiogram 3 с выбором даты и напоминаниями»
- «**database-designer**, спроектируй схему для интернет-магазина: товары, корзина, заказы»
- «**backend-api-dev**, добавь эндпоинты CRUD для заказов с проверкой владельца»
- «**frontend-dev**, сделай страницу каталога с фильтрами и пагинацией»
- «**web-tester**, покрой тестами модуль оплаты»
- «**devops-deployer**, подготовь Docker и деплой бота на VPS с webhook»
- «**web-reviewer**, проверь изменения перед релизом»

### Типовой конвейер для новой фичи
```
database-designer → backend-api-dev / tg-bot-dev → frontend-dev → web-tester → web-reviewer → devops-deployer
```
Попроси главного Claude: «Сделай фичу X, проведи её по конвейеру агентов из набора веб-разработки».

## Безопасность по умолчанию
- Токены и ключи — только через переменные окружения и `.env.example`, никогда в коде.
- `devops-deployer` не выполняет действия на серверах, в облаке и git push без твоего подтверждения.
- `web-reviewer` ничего не меняет — только отчёт.
- `web-tester` не меняет продовый код — найденные баги описывает.

## Настройка
Каждый агент — обычный Markdown-файл с YAML-шапкой. Можно менять:
- `model:` — `haiku` (дешевле/быстрее), `sonnet` (по умолчанию), `opus` (сложные задачи);
- `tools:` — список доступных инструментов;
- текст ниже шапки — инструкции и правила агента.

Удаление: удали соответствующие `.md` из `~/.claude/agents/` или `.claude/agents/`.
