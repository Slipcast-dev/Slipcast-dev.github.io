---
name: iep-goal-support
description: "Draft SMART IEP goals, accommodations, and present-levels statements that are measurable and compliant in spirit. Use when asked to write an IEP goal, draft special-education goals, list accommodations, or write a present-levels (PLAAFP) statement. Produces measurable annual goals with baselines, criteria, and measurement methods, plus matched accommodations. A drafting aid for educators — not legal advice; the IEP team and local requirements govern."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# IEP Goal Support Skill

IEP goals only help a student if they're measurable: a baseline, a target, a timeframe, and how progress is checked. This skill drafts SMART goals and matched accommodations educators can bring to the team. **This is a drafting aid, not legal advice — the IEP team, the student's data, and local/IDEA requirements govern the final document.**

## Working from a brief

Given a student profile and area of need, **draft full goals anyway**, using clearly-labelled illustrative baselines *(replace with the student's real data)*. Never invent specific diagnoses; work from the need described. Always keep the disclaimer.

## Required Inputs

Ask for (if not already provided):
- **Area of need** (reading fluency, math, writing, behaviour/SEL, communication, motor, executive function)
- **Present level** — what the student can do now (baseline data if available)
- **Grade/age** and any relevant context
- **Timeframe** (typically annual) and how progress is measured

## Output Format

### Present levels (PLAAFP) statement
A concise, strengths-first paragraph: what the student can currently do, the baseline data, and how the need affects access to the general curriculum.

### Annual goal(s) — SMART
For each: *"By [date], given [condition], [student] will [observable behaviour] to [criterion], as measured by [method] across [n] occasions."*
- Baseline → Target → Criterion (e.g. accuracy %, words/min, trials)
- **Measurement method** (probes, work samples, observation, charts) and **frequency**

### Short-term objectives / benchmarks (optional)
2–4 steps that ladder up to the annual goal.

### Accommodations & supports
Matched to the need (e.g. extended time, text-to-speech, chunked tasks, movement breaks) — distinguish **accommodations** (access) from **modifications** (changed expectations).

### Progress-monitoring plan
What data is collected, how often, and what counts as on-track vs needs-revision.

## Quality Checks

- [ ] Every goal is measurable: baseline, condition, observable behaviour, criterion, measurement method, timeframe
- [ ] Goals tie directly to the present-levels statement
- [ ] Accommodations are matched to the stated need and distinguished from modifications
- [ ] Illustrative baselines are clearly flagged *(replace with real data)*
- [ ] Retains the "drafting aid, not legal advice; team/IDEA governs" note

## Anti-Patterns

- Vague goals ("will improve reading") with no criterion or measurement
- Inventing a diagnosis or specific data not provided
- Confusing accommodations with modifications
- Presenting drafts as final/compliant without team review

## Example Trigger Phrases

- "Write an IEP goal."
- "Draft special-education goals."
- "List accommodations."
- "Write a present-levels statement."
