---
name: rubric-builder
description: "Create a clear grading rubric with criteria and performance-level descriptors that make scoring fair, fast, and consistent. Use when asked to build a rubric, create grading criteria, design an assessment scoring guide, or make grading more objective. Produces an analytic rubric table (criteria × performance levels) with concrete, observable descriptors and a points scheme — plus a short version students can self-check against."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Rubric Builder Skill

A good rubric turns "this feels like a B" into a defensible, repeatable judgment — and tells students exactly how to do better. This skill builds one with observable descriptors at each level.

## Working from a brief

Given the assignment and level, **build the full rubric anyway**, inferring sensible criteria and weighting. Mark anything assumed. Never leave "[describe level]"; write concrete descriptors.

## Required Inputs

Ask for (if not already provided):
- **The assignment / task** being graded and **grade or level**
- **What matters most** (the criteria, or let the skill propose them)
- **Scale** (e.g. 4-level: Exemplary/Proficient/Developing/Beginning) and total points
- **Type** — analytic (per-criterion) or holistic (single overall judgment)

## Output Format

### Rubric overview
- **Assignment · Level · Total points**
- **Criteria & weighting:** list each criterion and its share of the grade.

### Analytic rubric

| Criterion (weight) | Exemplary (4) | Proficient (3) | Developing (2) | Beginning (1) |
|---|---|---|---|---|
| [Criterion 1] | observable descriptor | | | |
| [Criterion 2] | | | | |
| [Criterion 3] | | | | |

Each cell describes **what the work actually looks like** at that level — observable evidence, not "excellent/good/poor."

### Scoring
How levels convert to points/grade, including weighting.

### Student-facing checklist
A short "before you submit, check you've…" version students can self-assess against.

### Feedback stems (optional)
2–3 sentence starters per criterion to speed up consistent written feedback.

## Quality Checks

- [ ] Descriptors are observable and specific (what the work shows), not vague labels
- [ ] Levels are clearly distinguishable — the jump from one to the next is a real difference
- [ ] Criteria are weighted and sum correctly to the total
- [ ] Includes a student-facing version so the rubric guides, not just grades

## Anti-Patterns

- Descriptors that just add adjectives ("good" → "very good" → "excellent")
- Overlapping levels a grader can't tell apart
- Criteria that measure effort/length instead of the learning goal
- A rubric only the teacher can read

## Example Trigger Phrases

- "Build a rubric."
- "Create grading criteria."
- "Design an assessment scoring guide."
- "Make grading more objective."
