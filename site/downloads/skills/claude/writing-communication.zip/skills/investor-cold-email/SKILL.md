---
name: investor-cold-email
description: "Write a cold or warm-intro email to an investor that actually gets a reply — short, specific, traction-forward, with a clear ask. Use when asked to email an investor, write a fundraising outreach, request a warm intro, or craft a forwardable blurb. Produces a tight cold email, a forwardable intro blurb a mutual contact can paste, and the follow-up — all skimmable on a phone."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Investor Cold Email Skill

Investors skim outreach on their phone in seconds. The emails that get replies are short, lead with the most credible proof, and make one clear ask. This skill writes them.

## Working from a brief

Given a rough company description, **write the full email anyway** and flag invented metrics *(assumed — replace with real)*. Keep it ruthlessly short. Never leave placeholders an investor would see.

## Required Inputs

Ask for (if not already provided):
- **What the company does** in one line, and stage/raise
- **The single most credible traction fact** (revenue, growth, notable customer/user count, waitlist)
- **The investor** and any genuine reason for reaching out to *them* specifically
- **The connection** (cold, or a mutual contact for a warm intro)

## Output Format

### 1. The cold email
- **Subject:** 4–7 words, specific (e.g. `Acme — $30k MRR, growing 25% MoM, raising seed`)
- **Body:** ≤ 120 words, 4 short paragraphs:
  1. One line: who you are + the hook (the best traction number)
  2. What you do + why now (one sentence each)
  3. The single most impressive proof point
  4. The ask — a specific, low-friction next step (a 20-min call; deck attached)
- Why *them*: one genuine line on why this investor (thesis fit, portfolio, public take) — never generic flattery.

### 2. Forwardable intro blurb
A 3–4 sentence paragraph the mutual contact can paste with zero editing — written so it makes *them* look good for forwarding it.

### 3. The follow-up
A 2-line nudge to send if there's no reply in ~5 business days — adds a *new* data point (a milestone, a new customer), never just "bumping this."

## Quality Checks

- [ ] Cold email is under ~120 words and skims on a phone
- [ ] Leads with the single most credible proof point
- [ ] One clear, low-friction ask — not "let me know if interested"
- [ ] The "why you" line is specific to this investor, not flattery
- [ ] Forwardable blurb needs zero editing by the intro-giver

## Anti-Patterns

- Long backstory before the hook
- Generic flattery ("I love your work")
- Multiple asks or a vague one
- A follow-up that just says "bumping this" with no new information

## Example Trigger Phrases

- "Email an investor."
- "Write a fundraising outreach."
- "Request a warm intro."
- "Craft a forwardable blurb."
