---
name: discharge-summary
description: "Turn a hospital stay into a complete, well-structured discharge summary. Use when asked to write a discharge summary, a hospital discharge note, or to document a patient's admission-to-discharge course for handoff. Produces a standard discharge summary — admission reason, hospital course, diagnoses, procedures, discharge medications, condition, and follow-up/return precautions — from the provided details."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Haiku 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Complete one bounded step and verify the expected output format.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Discharge Summary Skill

The discharge summary is the handoff that the next clinician (and the patient) actually relies on: why they were
admitted, what happened, what changed, and what to do next. This skill structures the stay into a complete,
scannable summary so nothing critical — a new medication, a pending result, a follow-up — falls through the gap.

> **Not quite this?** Use `physio-discharge-summary` when you are closing an outpatient physiotherapy episode.

> **Clinical-safety note:** this is a documentation-formatting aid, **not medical advice**. It organises
> information a qualified clinician provides; the treating clinician must review and verify every detail
> (especially the medication list and follow-up) before it is finalised. Do not invent diagnoses, medications,
> doses, or results.

## Working from a brief

Given the admission notes and course, **produce the full summary anyway** — organise what's provided into every
standard section. Where a section's detail wasn't given, mark it clearly (e.g. "Pending results: none reported")
rather than inventing it. Never fabricate medications, doses, or diagnoses.

## Required Inputs

Ask for these only if they aren't already provided (else mark as not documented):

- **Admission** — reason for admission, date, and presenting problem.
- **Hospital course** — what happened during the stay: diagnoses, key events, procedures, consults, results.
- **Discharge medications** — the reconciled med list (new, changed, stopped, continued).
- **Discharge status & disposition** — condition at discharge and where they're going (home, facility).
- **Follow-up** — appointments, pending results, and return/escalation precautions.

## Output Format

### Discharge Summary

- **Patient & dates** — identifiers as provided; admission and discharge dates.
- **Admission diagnosis / reason for admission.**
- **Discharge diagnoses** — principal and secondary.
- **Hospital course** — a concise narrative of the stay: presentation → workup → treatment → response, by problem.
- **Procedures / significant events** — with dates.
- **Discharge medications** — reconciled list, flagging **new / changed / discontinued** explicitly.
- **Condition at discharge & disposition.**
- **Follow-up plan** — appointments (who/when), pending results to chase, and clear **return precautions** (when to seek care).
- **Patient instructions** — in plain language for the patient/carer.

Close with **fields not documented** and a clinician-review reminder.

## Quality Checks

- [ ] Medication reconciliation is explicit — new / changed / stopped / continued are distinguished
- [ ] Follow-up names who, when, and any pending results to chase — nothing left dangling
- [ ] Clear return/escalation precautions are included for the patient
- [ ] The hospital course is organised by problem, not a raw chronological dump
- [ ] No diagnosis, medication, dose, or result is invented — gaps are marked
- [ ] A patient-facing plain-language instruction set is included alongside the clinical summary

## Anti-Patterns

- [ ] Do not invent medications, doses, diagnoses, or results to complete a section
- [ ] Do not present this as medical advice — it formats clinician-provided information for handoff
- [ ] Do not leave the medication list ambiguous about what changed during the stay
- [ ] Do not omit pending results or follow-up ownership — that's where handoffs fail
- [ ] Do not write patient instructions in clinical jargon the patient can't act on

## Based On

Clinical handoff/documentation practice — structured discharge summaries with medication reconciliation, explicit follow-up, and return precautions.

## Example Trigger Phrases

- "Write a discharge summary."
- "Write the hospital discharge note."
- "Document this patient's admission-to-discharge course for handoff."
- "Summarise this admission for the GP."
