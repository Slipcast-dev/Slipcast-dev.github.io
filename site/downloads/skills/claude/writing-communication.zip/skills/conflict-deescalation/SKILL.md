---
name: conflict-deescalation
description: "Calm a heated conflict — in person or in writing — before it does damage, by lowering the temperature instead of winning the point. Use when asked help me de-escalate this, this argument is getting heated, calm this situation down, or how do I respond without making it worse. Produces a read on what's actually driving the heat (often an unmet need under the surface argument), the de-escalation moves (acknowledge, slow down, find the shared ground), what to say and what to avoid, and how to steer toward resolution once the temperature drops — because you can't solve anything while everyone's activated."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Conflict De-escalation

When a conflict is hot, nobody's thinking — you're both defending, not listening, and every reply pours fuel. Winning the point in that state loses the relationship. De-escalation is the skill of lowering the temperature *first*, so an actual resolution becomes possible. This reads what's really driving the heat, gives you the moves that calm it, and steers toward resolution once people can think again.

## What This Skill Produces

- **The real driver** — what's actually fueling the heat (usually an unmet need — to feel heard, respected, safe — under the surface argument)
- **The de-escalation moves** — acknowledge the other person's feeling, slow the pace, lower your intensity, and find a shred of shared ground
- **What to say / what to avoid** — the phrases that calm ("I hear that this matters to you") vs. the ones that escalate (defensiveness, "calm down," being right)
- **A path to resolution** — how to move toward the actual issue once the temperature has dropped
- **A safety note** — recognizing when to disengage entirely (it's not de-escalating, or there's a safety risk)

## Required Inputs

Ask for these if not provided:
- **The conflict** — what's happening, with whom, in person or in writing
- **What was said** — the recent exchange, if you're mid-conflict
- **Your goal** — calm it and resolve, calm it and pause, or exit safely
- **The stakes/relationship** — who it's with and how much it matters
- **Your state** — how activated *you* are (you may need to de-escalate yourself first)

## Framework: Lower The Temperature Before The Point

1. **De-escalate yourself first.** You can't calm a conflict while you're activated — a pause, a breath, and dropping your own intensity comes before anything.
2. **Find what's really driving it.** The surface argument is rarely the real issue; underneath is usually a need to feel heard, respected, or safe. Address that.
3. **Acknowledge before you respond.** Naming the other person's feeling ("I can see you're really frustrated") lowers defenses faster than any argument — people de-escalate when they feel heard.
4. **Slow down and soften.** Lower your pace, volume, and intensity; the other person tends to mirror it. Avoid the escalators: defensiveness, "calm down," and needing to be right.
5. **Find shared ground.** Even a small point of agreement shifts it from opponents to collaborators.
6. **Then move to the issue.** Only once the heat drops, steer gently toward resolving the actual thing.
7. **Know when to disengage.** If it won't cool, or there's any safety concern, exiting is the right move — say so.

## Output Format

### Conflict: [what's happening] · with [who] · [in person/writing]

**What's really driving it:** [the unmet need under the surface argument].
**De-escalate**
1. Calm yourself first: [pause/breath/drop intensity].
2. Acknowledge them: "[name their feeling]".
3. Slow & soften: [lower pace/intensity] · avoid: defensiveness, "calm down," being right.
4. Shared ground: [a point you can agree on].
**Then, once it's cooler:** [move toward the actual issue].
**Disengage if:** [it won't cool / any safety concern].

## Quality Checks
- [ ] Starts with de-escalating oneself
- [ ] Identifies the real need under the surface argument
- [ ] Leads with acknowledging the other person's feeling
- [ ] Includes slowing/softening and the escalators to avoid
- [ ] Finds shared ground before problem-solving
- [ ] Includes when to disengage / a safety note

## Anti-Patterns
- **Trying to win the point** while it's hot.
- **"Calm down"** — the classic escalator.
- **Defending/counter-attacking** instead of acknowledging.
- **Jumping to problem-solving** before the temperature drops.
- **Staying in it** when disengaging is the safe move.

## Example Trigger Phrases
- "This argument with my partner is getting heated — help me de-escalate."
- "How do I respond to this angry email without making it worse?"
- "A conversation at work is turning into a fight. Calm it down."
- "Someone's yelling at me — how do I lower the temperature?"
- "Help me handle this conflict without it blowing up."
