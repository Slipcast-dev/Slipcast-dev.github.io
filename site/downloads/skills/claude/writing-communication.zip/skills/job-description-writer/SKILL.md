---
name: job-description-writer
description: "Write a clear, inclusive, and structured job description for any role. Use when asked to write a job description, job posting, JD, or job advert. Produces a complete JD with role summary, responsibilities, requirements, and inclusive language review."
disable-model-invocation: true  # skill-optimizer
---

# Job Description Writer Skill

Writes complete, inclusive job descriptions that attract the right candidates and reduce bias in the hiring process.

## Required Inputs
- **Job title and level**
- **Team and reporting line**
- **Top 5 things this person will actually do**
- **Must-have requirements** (be ruthless — only what is truly required)
- **Nice-to-have requirements**
- **Salary range** (JDs with salary ranges get 30% more applicants)
- **Location and remote policy**
- **Company description** (2-3 sentences)

## Output Structure

### [Job Title]
**[Company] | [Location] | [Remote policy] | [Salary range]**

**About [Company]**
[2-3 sentences. Specific and honest — not marketing copy.]

**The Role**
[3-4 sentences. What this person will own, why the role exists now, what success looks like in year one.]

**What You Will Do**
[6-8 bullet points. Outcomes and responsibilities, not activities. Start each with an action verb. Most important first.]

**What We Are Looking For**

Must have (4-6 items only):
- [Requirement]

Nice to have (3-4 items):
- [Nice to have]

**What We Offer**
[Compensation, benefits, development. Be specific.]

**How to Apply**
[Clear instructions. What to send, where, timeline.]

---

### Inclusive Language Review

**Words to remove or replace:**

| Original | Replace with | Why |
|---|---|---|
| "rockstar" | "experienced" | Gendered connotation |
| "ninja" | "skilled" | Same issue |
| "must have degree" | "relevant experience or qualification" | Excludes qualified non-graduates |

**Requirement audit:**
- Years of experience requirements flagged (screen out women and underrepresented groups disproportionately)
- Any requirements potentially discriminating against protected characteristics

## Quality Checks
- [ ] Salary range included
- [ ] Must-haves genuinely essential (6 items max)
- [ ] Each responsibility starts with action verb
- [ ] Inclusive language review completed
- [ ] No years-of-experience requirements unless legally required

## Anti-Patterns

- [ ] Do not include years-of-experience requirements unless legally necessary — they exclude qualified candidates and may create legal risk
- [ ] Do not list "nice to have" items in the requirements section — separate mandatory from desirable clearly
- [ ] Do not use gendered or exclusionary language — run the inclusive language check before finalising
- [ ] Do not write a responsibilities section with more than 8 items — prioritise the most important duties
- [ ] Do not omit compensation range where legally required or culturally expected — hiding salary deters qualified candidates

## Example Trigger Phrases
- "Write a job description for a [role]"
- "Create an inclusive job posting for [role]"
- "Review and rewrite this JD: [paste]"
