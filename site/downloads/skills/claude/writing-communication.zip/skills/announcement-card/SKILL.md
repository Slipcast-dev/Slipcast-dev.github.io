---
name: announcement-card
description: "Write a short, punchy announcement designed to be shared as an image or social card. Use when asked to announce a launch, milestone, feature, hire, funding, or win — something to post on LinkedIn/X/Slack. Produces a tight, visually-structured announcement (headline, one-liner, 2-3 proof points, CTA) that looks great exported as a PNG card from the playground."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Announcement Card Skill

A great announcement is short, concrete, and easy to skim — the opposite of a press release. This skill
writes a tight announcement built to be **shared as an image**: a bold headline, a one-line "what & why it
matters", a few proof points, and a clear next step. In the playground it exports beautifully via **🖼️ Save
as image**.

## Required Inputs

Ask for these only if they aren't already provided:

- **What you're announcing** — the launch / milestone / feature / hire / funding / win.
- **Why it matters** — the benefit or significance to the audience.
- **One or two proof points** — a number, a name, a before/after, a quote.
- **Audience & channel** — LinkedIn, X, Slack, email — and the tone (celebratory, matter-of-fact).
- **Call to action** — what you want people to do next (try it, read more, congratulate the team).

## Output Format

Keep it short enough to read in five seconds. Use this structure:

### [🎉 emoji] [Punchy headline — the news in one line]

**[One sentence: what it is and why it matters.]**

- **[Proof point 1]** — a number or concrete fact
- **[Proof point 2]** — another
- *(optional)* **[Proof point 3]**

👉 **[Call to action]** — [link or next step]

---
*Then provide:*
- **3 alternate headlines** — so they can pick the punchiest.
- **A one-line caption** for the post body (the card is the image; this is the text beside it).
- **Channel note** — any tweak for the chosen channel (hashtags for X, tag-the-team for LinkedIn, etc.).

## Quality Checks

- [ ] Headline states the actual news — not "Exciting update!" but the specific thing
- [ ] Reads in ~5 seconds; every line earns its place
- [ ] At least one concrete proof point (number, name, before/after) — not just adjectives
- [ ] One clear call to action
- [ ] Tone matches the channel and audience
- [ ] Structured to look great as an exported image card (short lines, scannable)

## Anti-Patterns

- [ ] Do not write a press release — this is a card, not three paragraphs
- [ ] Do not bury the news under throat-clearing ("We're thrilled to share that…") — lead with it
- [ ] Do not use hollow hype — "game-changing", "revolutionary" with no proof
- [ ] Do not cram multiple announcements into one card — one piece of news
- [ ] Do not omit the call to action — tell people what to do next

## Based On

Social/launch announcement craft (lead with the news, proof over adjectives, one CTA, skimmable for an image card).

## Example Trigger Phrases

- "Announce our launch on LinkedIn."
- "Write a post announcing our new hire."
- "We just raised a round: write the announcement."
- "Make a shareable card for this milestone."
