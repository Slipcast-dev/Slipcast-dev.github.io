# Модели / Models

Выберите модель в своей сессии. Доступ зависит от клиента, тарифа и организации.

Choose a model in your session. Availability depends on your client, plan, and organization.

| Задача / Work | Рекомендуемая модель / Suggested model |
| --- | --- |
| Короткий шаг / Focused task | Claude Haiku 5.5 |
| Обычная работа / Everyday work | Claude Sonnet 5.5 |
| Изображения и интерфейс / Images and UI | Claude Sonnet 5.5 |
| Глубокая проверка / In-depth review | Claude Opus 5.5 |
| Сложная задача / Flagship workflow | Claude Fable 5.2 |

Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.

Read relevant files, preserve existing contracts, and verify the affected workflow.

[Модели / Models](https://code.claude.com/docs/en/model-config) · [Скиллы / Skills](https://code.claude.com/docs/en/skills)
