---
name: the-skeptic-and-the-believer
description: "See an idea through two committed extremes — a true believer and a hard skeptic — so you get the full range before settling in the middle. Use when asked should I believe this, is this hype or real, give me both sides, or how excited should I be about. Produces the believer's fullest bull case and the skeptic's sharpest bear case (each committed, not hedged), the crux question that separates them, and a grounded read on where the truth probably sits — great for evaluating claims, trends, opportunities, and your own enthusiasm."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Separate decisions from assumptions. State dependencies, decision criteria, and the next step.
<!-- slipcast-model-profile:end -->


# The Skeptic and the Believer

When you're evaluating a claim, a trend, or your own excitement, a balanced take hides the real range. This splits it into two committed extremes: a believer who makes the fullest bull case and a skeptic who makes the sharpest bear case, neither hedging toward the other. Seeing both at full strength — then finding the crux between them — gets you to a grounded view faster than a cautious middle ever could.

## What This Skill Produces

- **The believer's case** — the fullest, most compelling argument that this is real/great/worth it
- **The skeptic's case** — the sharpest argument that it's hype/flawed/not worth it
- **The crux** — the single question whose answer decides which side is right
- **The grounded read** — where the truth probably sits, and what you'd need to know to be sure

## Required Inputs

Ask for these if not provided:
- **The thing** — the claim, trend, opportunity, product, or your own excitement about something
- **Why it's on your radar** — what's prompting the evaluation
- **Your current lean** — believer, skeptic, or genuinely unsure
- **What's at stake** — how much rides on getting it right

## Framework: Both Extremes, Then The Crux

1. **Let the believer go all in.** The strongest bull case, committed — every reason this is real and worth it, no hedging.
2. **Let the skeptic go all in.** The strongest bear case, committed — every reason it's overhyped, flawed, or a trap.
3. **Keep them from blending.** Two full-strength extremes reveal more than one balanced average.
4. **Find the crux.** Identify the one question whose answer would settle which side is right — usually a fact, a timeframe, or a fit-to-you question.
5. **Land it, grounded.** Say where the truth likely sits given what's known, and what evidence would move it — without false balance if one side is clearly stronger.

## Output Format

### Evaluating: [the thing]

**🙌 The Believer:** [fullest bull case].
**🧐 The Skeptic:** [sharpest bear case].
**The crux:** [the one question that decides it].
**Grounded read:** [where the truth probably sits + what would confirm it].

## Quality Checks
- [ ] The believer and skeptic are both committed, not hedged
- [ ] The two cases genuinely oppose each other
- [ ] A single crux question is identified
- [ ] The grounded read is honest, not forced-balanced
- [ ] It names what evidence would resolve the question

## Anti-Patterns
- **Two lukewarm takes** that basically agree.
- **False balance** when one side is clearly right.
- **No crux** — just two piles of points.
- **A wishy-washy landing** with no actual read.

## Example Trigger Phrases
- "Is this trend real or hype? Give me both sides hard."
- "Should I believe the claims about this product?"
- "I'm really excited about this — believer vs skeptic, go."
- "Bull case and bear case on this investment idea."
- "Talk me through both extremes on whether this is worth it."
