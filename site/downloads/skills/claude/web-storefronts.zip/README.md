# Интернет-магазин и оформление заказа / Storefront and checkout · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Состояния каталога, корзина и сценарии заказа на тестовых данных.

Catalog states, carts and checkout with test data.

Выберите скилл под задачу / Choose a skill for your task:

- [cart-checkout-local](skills/cart-checkout-local/SKILL.md)
- [storefront-catalog-states](skills/storefront-catalog-states/SKILL.md)
