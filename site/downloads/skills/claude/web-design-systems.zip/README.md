# Веб-дизайн и дизайн-системы / Web design and design systems · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Адаптивные макеты и дизайн-токены.

Responsive layouts and design tokens.

Выберите скилл под задачу / Choose a skill for your task:

- [design-token-integration](skills/design-token-integration/SKILL.md)
- [responsive-page-sketch](skills/responsive-page-sketch/SKILL.md)
