# Фронтенд и состояния интерфейса / Frontend and UI states · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Загрузка, ошибки, повтор запроса и регрессионные сценарии.

Loading, errors, retries and UI regression checks.

Выберите скилл под задачу / Choose a skill for your task:

- [async-ui-state](skills/async-ui-state/SKILL.md)
- [frontend-state-regression](skills/frontend-state-regression/SKILL.md)
