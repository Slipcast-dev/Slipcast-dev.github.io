# Мониторинг и диагностика веб-приложений / Web observability and incident triage · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Контракт событий браузера и разбор сбоев по журналам.

Client telemetry contracts and incident triage.

Выберите скилл под задачу / Choose a skill for your task:

- [client-telemetry-contract](skills/client-telemetry-contract/SKILL.md)
- [web-incident-triage](skills/web-incident-triage/SKILL.md)
