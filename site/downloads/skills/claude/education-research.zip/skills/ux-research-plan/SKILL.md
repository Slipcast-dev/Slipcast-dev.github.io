---
name: ux-research-plan
description: "Create a structured UX research plan for any product question or feature. Use when asked to write a research plan, design a user study, create a discussion guide, write screener questions, or plan usability testing. Produces a full research plan with objectives, methodology, screener, discussion guide, and synthesis framework."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Ground conclusions in a specific region of the image or document.
- Preserve source references and units. Validate totals against a reference example.
<!-- slipcast-model-profile:end -->


# UX Research Plan Skill

This skill creates a complete, ready-to-execute UX research plan. Output covers everything from research objectives to screener questions, discussion guide, and synthesis framework.

## Required Inputs

Work from what is given. If any of these is missing, still produce the complete output: fill each gap with a reasonable assumption marked *(assumed, confirm)* and list those assumptions at the end. Ask a question first only when the core subject itself is missing (there is nothing to write about).
- **Research question** (what decision will this research inform?)
- **Product area or feature** being researched
- **Research type** (Generative / Evaluative / Usability testing / Diary study / Survey)
- **Stage** (Discovery / Concept validation / Prototype testing / Live product)
- **Target participants** (role, demographics, behaviour — who should we talk to?)
- **Timeline and number of sessions**
- **Existing assumptions or hypotheses** (optional but valuable)

## Output Structure

---

# UX Research Plan: [Study Title]
**Product area:** [Area]
**Research type:** [Type]
**Date:** [Timeline]
**Researcher:** [Leave for user]

---

## 1. Research Objectives

State 2–4 clear research objectives. Each objective should map to a decision that will be made differently depending on what you find.

**Objective [N]:** Understand [specific thing] so we can [decision this informs].

---

## 2. Research Questions

[5–8 questions — the actual questions you want research to answer. These are not the interview questions; they're the knowledge gaps. Organised under each objective.]

**Objective 1:**
- RQ1.1: [Research question]
- RQ1.2: [Research question]

---

## 3. Methodology & Rationale

**Method chosen:** [e.g. Semi-structured interviews / Usability testing / Concept testing]

**Why this method:**
[2–3 sentences. Match method to research type. If evaluative: usability testing. If generative: contextual inquiry or interviews. If testing comprehension: 5-second test or concept test.]

**What this method will and won't tell us:**
- **Will tell us:** [What this method is good at revealing]
- **Won't tell us:** [What's out of scope — be honest about limits]

**Sample size:** [Recommended number of sessions and why — e.g. "5–6 moderated interviews for generative research; 5–8 usability sessions to identify top issues"]

---

## 4. Participant Screener

**Recruitment criteria:**

| Criterion | Must Have / Nice to Have | Disqualify if |
|---|---|---|
| [e.g. Uses project management software daily] | Must Have | [Never uses any PM tool] |
| [e.g. Works in a team of 5+] | Must Have | — |
| [e.g. B2B industry] | Nice to Have | — |

**Screener questions (5–8 questions):**

[Q1] [Screening question — clear, not leading]
- [Answer options — flag which qualify/disqualify]

[Q2] ...

**Incentive recommendation:** [Amount and format — e.g. "£50 gift voucher for a 60-min session is standard in the UK for professional participants"]

---

## 5. Discussion Guide

Structure the session:

### Opening (5 min)
- Introduce yourself and the study
- "We're testing the design, not you — there are no wrong answers"
- Permission to record
- Warm-up: [1–2 easy questions to build rapport — e.g. "Tell me about your role and what a typical week looks like"]

### Core Questions (by section)

**Section [A]: [Topic]** *(~X min)*

1. [Open question — start broad] *[Probe: Tell me more about...]*
2. [Follow-up to go deeper] *[Probe: Can you walk me through what happened?]*
3. [Specific scenario or past behaviour question]

**Section [B]: [Topic]** *(~X min)*
[Continue with 2–3 questions per section]

**Usability tasks (if applicable):**
> "I'm going to ask you to try a few things with this prototype. Please think aloud as you go."

- Task [N]: [Clear task instruction — write from the user's perspective, not "click on X" but "find where you would go to do Y"]
  - **Success criteria:** [What "completing this task" looks like]
  - **What to observe:** [Where friction typically appears]

### Closing (5 min)
- "Is there anything about [topic] we haven't covered that you think is important?"
- "If you could change one thing about [product/concept], what would it be?"
- Debrief and thank

---

## 6. Synthesis Framework

After sessions, use this framework to synthesise findings:

**Step 1: Session notes → Key observations**
For each session: 3–5 specific observations (behaviours, quotes, reactions — not interpretations yet)

**Step 2: Affinity mapping**
Group observations by theme across all sessions. Aim for 4–7 clusters.

**Step 3: Insight statements**
For each cluster: "When [context], users [behaviour/experience], because [underlying need or mental model]."

**Step 4: Implications**
For each insight: "This means we should [design/product implication]" or "This challenges our assumption that [assumption]."

**Step 5: Research report structure:**
- Key findings (3–5 headlines)
- Supporting evidence per finding
- Design recommendations
- Open questions for next research cycle

---

## Quality Checks

- [ ] Research objectives map to real decisions
- [ ] Discussion guide opens broad before going specific
- [ ] Screener criteria are specific enough to get the right participants
- [ ] Tasks (if usability) are written from the user's perspective
- [ ] Synthesis framework is included
- [ ] Incentive recommendation is included

## Anti-Patterns

- [ ] Do not write a research plan without clearly stated research objectives — every methodology choice must flow from the objectives
- [ ] Do not design a plan that mixes generative and evaluative research without clearly separating them
- [ ] Do not omit screener criteria — recruiting unqualified participants invalidates the research
- [ ] Do not write discussion guide questions that are leading — questions must be neutral and open-ended
- [ ] Do not skip the incentive recommendation — uncompensated research has lower participant quality and completion rates

## Example Trigger Phrases

- "Write a research plan for [feature or product area]"
- "Create a discussion guide for user interviews about [topic]"
- "Plan a usability test for [prototype or feature]"
- "Write screener questions for [target user type]"
