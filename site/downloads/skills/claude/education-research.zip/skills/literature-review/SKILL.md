---
name: literature-review
description: "Structure and write a literature review for any research topic."
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Opus 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Compare options, check edge cases, and state the remaining risks.
- Preserve source references and units. Validate totals against a reference example.
<!-- slipcast-model-profile:end -->


# Literature Review Skill

Structures and writes literature reviews — from background sections of a dissertation through to standalone narrative reviews for publication.

> **Not quite this?** Use `literature-review-builder` when you are a student building an argued review from a reading list.

## Required Inputs
- **Topic or research question**
- **Type of review** (narrative / systematic / scoping / integrative / background section)
- **Sources provided** (paste references, abstracts, or key findings)
- **Word count target**
- **Audience** (academic journal / thesis / grant proposal / policy brief)
- **Time period to cover**

## Output Structure

### 1. Search Strategy Summary (for systematic/scoping reviews)
**Databases:** [PubMed, EMBASE, PsycINFO, etc.]
**Search terms:** [Key terms and Boolean combinations]
**Inclusion criteria:** Study types, population, date range, language
**Exclusion criteria:** [List]
**Results:** [n] identified → [n] after deduplication → [n] screened → [n] included

### 2. Literature Review Body

Organised thematically — not chronologically. Each theme = one section.

**Structure per thematic section:**

**[Theme heading]**

[Opening: state what this section covers and what evidence shows overall]

[Evidence synthesis: present what multiple studies found, compare and contrast. Do NOT summarise one paper then the next — synthesise across them: "Three studies found X (Smith, 2019; Jones, 2020; Lee, 2021), while two found Y, with the difference attributable to..."]

[Critical analysis: note methodological strengths and weaknesses — sample sizes, study designs, generalisability, risk of bias]

[Closing: transition to next theme]

### 3. Synthesis Table (systematic/scoping reviews)

| Author, year | Study design | Population | n | Key findings | Quality/Limitations |
|---|---|---|---|---|---|

### 4. Gap Analysis

**Well-established:** [What literature consistently shows]
**Contested:** [Areas where evidence is mixed and why]
**Missing:** [Gaps the field needs to address]
**How your study addresses the gap:** [If this is for a research proposal]

### 5. Conclusion Paragraph
[3-5 sentences. Current state of knowledge and what is needed next]

## Critical Analysis Framework
For each paper: internal validity, external validity, bias types, effect size significance vs clinical significance, funding conflicts.

## Quality Checks
- [ ] Organised thematically (not as individual paper summaries)
- [ ] Evidence synthesised across papers (not summarised one by one)
- [ ] Critical analysis of methodology included for key studies
- [ ] Gaps identified — what the field still needs
- [ ] All claims cited

## Anti-Patterns

- [ ] Do not summarise papers one by one — evidence must be synthesised thematically across multiple studies, not presented as a sequence of abstracts
- [ ] Do not omit methodological critique — a literature review that only reports findings without assessing study quality is not a critical review
- [ ] Do not organise by chronology when thematic organisation is possible — chronological reviews bury the conceptual structure of the field
- [ ] Do not present contested findings as settled consensus — where evidence is mixed, name both sides and why the evidence diverges
- [ ] Do not skip the gap analysis — identifying what the field still needs is a core deliverable, not an optional addition

## Example Trigger Phrases
- "Write a literature review on [topic]"
- "Synthesise the evidence on [topic] from these papers: [paste]"
- "Write the background section for my research proposal on [topic]"
