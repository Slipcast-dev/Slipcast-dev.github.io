# Веб-разработка и браузерная приёмка / Web development and browser acceptance · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Компоненты, доступность в браузере, проверка контракта веб-API.

Components, browser accessibility, web API contract checks.

Рекомендуемый порядок / Suggested order:

1. [frontend-component-contract](skills/frontend-component-contract/SKILL.md)
2. [web-api-consumer-contract](skills/web-api-consumer-contract/SKILL.md)
3. [browser-accessibility-acceptance](skills/browser-accessibility-acceptance/SKILL.md)
