# Тестирование импорта данных / Data import testing · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Тестовые CSV и JSON, сверка импорта.

CSV and JSON fixtures, import reconciliation.

Рекомендуемый порядок / Suggested order:

1. [synthetic-import-fixtures](skills/synthetic-import-fixtures/SKILL.md)
2. [import-reconciliation](skills/import-reconciliation/SKILL.md)
