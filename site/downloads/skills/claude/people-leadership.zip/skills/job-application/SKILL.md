---
name: job-application
description: "Tailors a CV and cover letter to a specific job description. Use when asked to write a cover letter, tailor a CV or resume, optimise for ATS, match a job description, or prepare a job application. Produces an ATS-optimised tailored CV summary and a personalised cover letter aligned to the role's requirements."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Separate decisions from assumptions. State dependencies, decision criteria, and the next step.
<!-- slipcast-model-profile:end -->


# Job Application Skill

This skill tailors a CV and cover letter to a specific job description — optimising for ATS keyword matching while keeping the writing human and compelling. It also flags gaps between the candidate's profile and the role requirements.

## Required Inputs

Work from what is given. If any of these is missing, still produce the complete output: fill each gap with a reasonable assumption marked *(assumed, confirm)* and list those assumptions at the end. Ask a question first only when the core subject itself is missing (there is nothing to write about).
- **Job description** (paste in full)
- **Current CV / resume** (paste or describe key experience, roles, and skills)
- **The specific thing that excites them about this role** (used in the cover letter — must be genuine)
- **Any particular strengths to emphasise** (optional)
- **Any gaps they're worried about** (optional — helps address them proactively)

## Output Structure

---

## Part 1: JD Analysis

Before writing anything, analyse the job description and output:

### Must-Have Requirements
[List explicit requirements from the JD — qualifications, years of experience, specific skills]

### Key Themes in the JD
[3–5 themes that repeat or are emphasised — these are the keywords and priorities the hiring manager cares about most]

### ATS Keywords to Include
[List 10–15 specific keywords and phrases from the JD that should appear in the CV and cover letter. Include: tools, methodologies, job titles, skills]

### Gaps Assessment
[Honest comparison between the candidate's profile and the JD requirements. Flag: "Strong match" / "Partial match — can be positioned as X" / "Gap — address in cover letter or don't apply"]

---

## Part 2: Tailored CV Summary / Profile Section

Rewrite or create the candidate's CV summary/profile section (the 3–5 lines at the top of a CV) specifically for this role:

**Rules:**
- Open with the job title or a near-match (ATS reward)
- Include 2–3 keywords from the JD naturally
- Reference years of experience in the relevant area
- End with a forward-looking line connecting their background to what this role needs
- Keep to 60–80 words maximum

**Tailored CV Summary:**
[Write the summary]

---

## Part 3: Experience Bullet Point Rewrites

For the 2–3 most relevant roles on the CV, suggest how to reframe existing bullet points to better match this JD:

**[Role Title] at [Company]**

| Original Bullet | Tailored Version | Why |
|---|---|---|
| [Candidate's original text] | [Improved version with JD keywords and stronger impact framing] | [Brief note on what changed] |

**Rules for bullet point rewrites:**
- Lead with an action verb
- Include a quantified outcome where possible (%, £, time saved, users impacted)
- Weave in JD keywords naturally — not forced
- Keep to one line (2 max)

---

## Part 4: Cover Letter

**Format:** 3 paragraphs + closing. Target: 250–350 words. Anything longer won't be read.

---

[Hiring Manager's name if known, otherwise "Hiring Team"]

**Paragraph 1 — The Hook (Why this role, specifically)**
[2–4 sentences. Reference something specific about the company or role — not generic enthusiasm. The candidate's genuine reason for applying goes here. This is what makes it human. Generic openers like "I am writing to apply for..." are filtered out mentally within 3 seconds.]

**Paragraph 2 — The Evidence (Why them)**
[3–5 sentences. 2–3 specific examples from their background that directly address the JD's key themes. Use the language of the JD. Include at least one quantified achievement. Don't list everything — pick the 2–3 strongest matches and go deep, not broad.]

**Paragraph 3 — The Forward Bridge (Why now)**
[2–3 sentences. Connect their trajectory to this role. Why is this the logical next step? What do they want to learn or build that this role enables? This should feel like the natural continuation of their career, not just "I want a new challenge."]

---

I'd welcome the chance to discuss how my background could contribute to [Company/Team]. Thank you for your time.

[Name]
[Email] | [LinkedIn URL] | [Location if relevant]

---

## Part 5: Application Checklist

Before submitting:
- [ ] CV summary updated with tailored version above
- [ ] ATS keywords appear in CV body (not just summary)
- [ ] Cover letter is under 400 words
- [ ] Company name is spelled correctly throughout (sounds obvious — it happens)
- [ ] No generic phrases: "passionate about," "results-driven," "team player" without evidence
- [ ] LinkedIn profile updated to match CV (recruiters cross-check)
- [ ] Role title in subject line if emailing directly

---

## Deeper Materials

- [`references/six-second-scan.md`](references/six-second-scan.md) — how the ATS parser and the 6-second human scan actually read an application, and the 20-minute tailoring budget

## Quality Checks

- [ ] JD analysis completed before writing (not skipped)
- [ ] ATS keywords are integrated naturally (not stuffed)
- [ ] Cover letter opens with something specific (not a generic opener)
- [ ] Paragraph 2 includes at least one quantified achievement
- [ ] Cover letter is 250–350 words
- [ ] Gaps are either addressed or strategically omitted

## Anti-Patterns

- [ ] Do not fabricate or embellish experience — only use real achievements from the provided CV
- [ ] Do not use the same cover letter template for every role — every letter must reference specific details of the job description
- [ ] Do not address selection criteria that aren't in the JD — match keywords the employer actually used
- [ ] Do not omit ATS optimisation — ensure role-specific keywords from the JD appear naturally in the CV summary
- [ ] Do not write a cover letter that re-summarises the CV — it must add context and motivation, not repeat bullet points

## Example Trigger Phrases

- "Help me apply for this job: [paste JD]"
- "Tailor my CV for this role: [paste JD + CV]"
- "Write a cover letter for [role] at [company]"
- "Optimise my application for ATS for this job description"
