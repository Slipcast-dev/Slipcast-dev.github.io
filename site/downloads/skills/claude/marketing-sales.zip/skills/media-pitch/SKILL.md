---
name: media-pitch
description: "Write a media pitch or press outreach email for any story or announcement. Use when asked to write a media pitch, journalist outreach email, press pitch, or story angle for PR. Produces a concise pitch with a compelling news angle, journalist-specific hook, and clear call to action."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Media Pitch Skill

Writes media pitches that journalists actually respond to — built around the story angle, not the company's desire for coverage. Most pitches fail because they are press releases in an email. Good pitches are a human proposing a story to another human.

## Required Inputs

Work from what is given. If any of these is missing, still produce the complete output: fill each gap with a reasonable assumption marked *(assumed, confirm)* and list those assumptions at the end. Ask a question first only when the core subject itself is missing (there is nothing to write about).
- **The story** (what is the actual news or interesting angle?)
- **Target publication or journalist** (who are you pitching to and what do they cover?)
- **Company or organisation** (who is behind this?)
- **Key proof point** (data, customer story, or exclusive that makes this credible)
- **Why now** (why is this timely?)
- **What you are offering** (interview / exclusive data / embargoed information / spokespeople)

## Output Structure

---

### Pitch: [Target journalist / outlet]

**Subject line:** [Under 10 words. The story angle, not the company name. Specific, not "Exciting news from [Company]"]

---

Hi [First name],

[Opening sentence — one hook that makes them want to read the next line. Reference their recent work if genuinely relevant: "I read your piece on X last week, which is why I thought you'd be interested in this."]

[Paragraph 1 — The story in 2–3 sentences. Lead with why the reader of [publication] would care. Not what the company does. The news angle, with the most interesting fact first.]

[Paragraph 2 — Why this is a story now. One data point, trend, or timely hook. Be specific: "In the last 6 months, X has increased by Y, according to [source]." Generic claims about "growing trends" are ignored.]

[Paragraph 3 — What you are offering. Interview with [specific person + their relevant credential]. Exclusive data / first look. Access to [specific thing]. One clear offering.]

[Brief company context — 1 sentence maximum. Journalists don't need your history; they need to know you're credible.]

Happy to send more details, connect you with [spokesperson], or share [specific exclusive asset] under embargo.

[Name]
[Title, Company]
[Mobile — journalists work on deadline and text faster than email]

---

## Pitch Rules

- Subject line is the pitch — if it doesn't earn a click, nothing else matters
- The story angle is not "Company launches product" — it is what that product reveals about the world
- One pitch, one journalist — mass BCC pitches are recognisable and ignored
- Follow up once, after 3–5 business days, with new information (not "just checking in")
- If offering an exclusive, name it explicitly and set a response deadline

## Angle Development Framework

If the user doesn't have a strong angle, help them find one:

| Angle type | Example | Works for |
|---|---|---|
| Data reveal | "Our research of 10,000 users shows X" | Survey findings, product insights |
| Trend + proof | "This is happening and here is evidence" | Market trends, behaviour change |
| Contrarian | "Everyone thinks X but actually Y" | Counter-intuitive findings |
| Human story | "This person's experience illustrates X" | Customer stories, case studies |
| Milestone | "First / fastest / largest in [category]" | Launches, records |

## Quality Checks

- [ ] Subject line is the story angle (under 10 words, no company name)
- [ ] Opening doesn't start with "I'm reaching out" or "I hope this email finds you well"
- [ ] The story angle is clear in the first two sentences
- [ ] A specific exclusive or offer is named
- [ ] Journalist's name is used (not "Hi there")
- [ ] Mobile number included for deadline follow-up

## Anti-Patterns

- [ ] Do not write a pitch that leads with the company's history or description — the story angle must come first, not who the company is
- [ ] Do not use vague data points ("significant growth", "thousands of users") — every statistic must be specific and verifiable
- [ ] Do not send the same pitch to multiple journalists in a BCC — pitches must be individually tailored to each journalist's beat and recent work
- [ ] Do not offer an exclusive without setting a response deadline — an open-ended exclusive invitation is ignored or used to delay indefinitely
- [ ] Do not follow up with "just checking in" — a follow-up must contain new information or a fresh angle, otherwise it is noise

## Example Trigger Phrases

- "Write a media pitch for [story or announcement]"
- "Draft a journalist outreach email for [topic]"
- "Help me pitch [story] to [type of journalist or outlet]"
- "What is a good angle for a media pitch about [topic]?"
