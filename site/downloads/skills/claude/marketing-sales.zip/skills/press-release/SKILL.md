---
name: press-release
description: "Write a professional press release for any announcement. Use when asked to write a press release, media announcement, news release, or press statement. Produces a structured press release with headline, dateline, body, boilerplate, and media contact — ready to send to journalists."
disable-model-invocation: true  # skill-optimizer
---

# Press Release Skill

Writes press releases that journalists actually read — structured around the news angle, not the desire to promote.

## Required Inputs
- **The news** (what is actually happening — be specific)
- **Company name**
- **Date of announcement / embargo date**
- **Key quote** (from which executive and approximately what they want to say)
- **Why this matters** (to the reader, not the company)
- **Target media** (trade / national / local / consumer / investor)
- **Media contact details**

## Output Structure

---

FOR IMMEDIATE RELEASE / EMBARGOED UNTIL: [Date and time]

---

# [Headline — active verb, specific news, under 10 words]
## [Subheadline — the so-what in one sentence, adds context not repetition]

**[City, Date]** — [Opening paragraph: Who, What, When, Where, Why in 2-3 sentences. A journalist should be able to run this paragraph alone. No background, no context, no company history.]

[Second paragraph: the significance. Why does this matter? What does it mean for customers or the industry?]

[Third paragraph: quote from executive. Human and specific. Not a restatement of the headline.]

"[Quote text — specific, adds something the facts do not say]," said [Name], [Title] at [Company]. "[Second sentence extending the thought]."

[Fourth paragraph: supporting detail — data, customer names with permission, additional context]

[Fifth paragraph optional: what happens next, when it goes live, what people can do]

---

ENDS

---

**Notes to editors:**

**About [Company]**
[Boilerplate: 3-4 sentences. What the company does, when founded, where based, key facts. Factual not promotional.]

**Media contact:**
[Name] | [Title] | [Email] | [Phone] | [Hours/timezone]

---

## Headline Rules
- Active voice: "Company launches X" not "X is launched by Company"
- Specific: "raises 5M" not "secures significant investment"
- Under 10 words
- Never start with the company name — lead with the news

## Journalist Test
Would a journalist care? Is the headline the full story? Is there a human angle? Is the quote something a human would say? Can the first paragraph stand alone?

## Deeper Materials

This skill ships with support files — use them when they are available:

- **`references/newsworthiness.md`** — Newsworthiness: What Makes a Release News Instead of Noise. Apply it while producing the output; it carries the calibration and judgment calls the method summary above compresses.
- **`templates/release-skeleton.md`** — a fill-in version of the deliverable with the quality gates inline. Offer it when the user wants to work the document themselves rather than have it generated.

## Scoring Rubric (0–40)

Score any output of this skill before handing it over; 32+ is ship-quality.

| Dimension | 0 | 5 | 10 |
|---|---|---|---|
| **Headline & lead** | Passive headline over 12 words starting with the company name; the news is buried mid-release | Active headline, but the first paragraph needs the second to make sense | Active, specific headline under 10 words; first paragraph carries who/what/when/where/why and could run verbatim |
| **Newsworthiness** | Reads as advertising — superlatives, no reader-side "so what" | Real news present but wrapped in promotional framing a journalist must strip | Significance paragraph answers why an outsider cares; limitations stated plainly rather than hidden |
| **Quote quality** | Quote restates the headline in corporate voice | Quote sounds human but adds no information the facts don't already carry | Quote says something new, sounds like a person, and would survive being the only excerpt used |
| **Apparatus completeness** | No release/embargo line, boilerplate, or media contact | Apparatus present but boilerplate is promotional or contact lacks phone/hours | Release line, ENDS marker, factual dates-and-numbers boilerplate, and full contact with hours/timezone |

## Quality Checks

- [ ] Headline uses active voice and is under 10 words
- [ ] First paragraph stands alone as the complete story
- [ ] Quote adds something the facts don't say (not a restatement)
- [ ] Boilerplate is factual, not promotional
- [ ] Embargo date and media contact are included

## Anti-Patterns

- [ ] Do not bury the news — the most important information must appear in the first paragraph (inverted pyramid)
- [ ] Do not use promotional language or superlatives — press releases must read as news, not advertising copy
- [ ] Do not omit the boilerplate — every press release needs the standard "About [Company]" paragraph at the end
- [ ] Do not forget the embargo date and media contact — journalists need both to use the release
- [ ] Do not write a headline longer than 12 words — it must be scannable and specific

## Example Trigger Phrases
- "Write a press release announcing [news]"
- "Draft a media statement about [event]"
- "We are launching [product] — write the press release"
- "Turn this announcement into a press release: [paste notes]"
