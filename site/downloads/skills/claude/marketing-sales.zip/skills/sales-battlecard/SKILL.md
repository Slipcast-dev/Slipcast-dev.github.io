---
name: sales-battlecard
description: "Create a competitive sales battlecard for any competitor. Use when asked to build a battlecard, competitive comparison, sales cheat sheet, or objection handling guide for a specific competitor. Produces a one-page battlecard with positioning, differentiators, objection responses, and landmines."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Preserve facts, audience, and tone. Check the result against the required format.
<!-- slipcast-model-profile:end -->


# Sales Battlecard Skill

Produces a practical one-page competitive battlecard that sales reps can use in calls — not a theoretical analysis.

## Required Inputs
- **Your product/company**
- **Competitor name**
- **Your target customer** (ICP)
- **Your top 3 differentiators** vs this competitor
- **Common objections** when competing against them
- **Known competitor weaknesses**

## Output Structure

---

# Battlecard: [Your Product] vs [Competitor]
Updated: [Date] — Review quarterly

---

### In One Sentence
When a prospect mentions [Competitor], say: "[Your positioning in one sentence]"

---

### Why Customers Choose [Competitor]
(Be honest about their genuine strengths)
- [Strength 1]
- [Strength 2]

---

### Why Customers Choose Us
(Specific differentiators with proof points)
- **[Differentiator 1]:** [Proof point — customer outcome or capability]
- **[Differentiator 2]:** [Proof point]

---

### Objection Responses

**"[Competitor] is cheaper"**
"You are right their list price is lower. What our customers find is [specific TCO difference]. [Customer] saw [result]. Should we explore total cost of ownership?"

**"We already use [Competitor]"**
"That is helpful. What is working well? [Listen] And what is one thing you wish was better?"

**"[Competitor] has [feature] you do not"**
"You are right. What problem are you solving with that feature? [Listen] Here is how our customers solve that..."

---

### Landmines to Plant
- "How do you currently handle [area where competitor is weak]?"
- "What happens when you need to [scenario competitor struggles with]?"

---

### Traps to Avoid
- Never badmouth [Competitor] directly
- Do not lead with features — lead with the prospect problem
- Do not claim you do everything better — be specific about where you win

---

### When We Win / When We Lose
We win when: [Scenario — e.g. customer prioritises outcome over price]
We lose when: [Honest scenario — e.g. primary driver is lowest upfront cost]

## Quality Checks

- [ ] Competitor strengths are listed honestly (not minimised)
- [ ] Differentiators have proof points (not just claims)
- [ ] Objection responses are conversational (not scripted-sounding)
- [ ] Landmine questions are natural and non-confrontational
- [ ] "When we lose" is included and honest
- [ ] Battlecard has a review date

## Example Trigger Phrases
- "Build a battlecard against [competitor]"
- "Create a competitive cheat sheet for [competitor]"
- "Write objection handling for [competitor] comparisons"

## Anti-Patterns

- [ ] Do not minimise or ignore genuine competitor strengths — sales reps who encounter them unprepared lose credibility
- [ ] Do not write differentiators without proof points — a claim without evidence is marketing, not a battlecard
- [ ] Do not make the battlecard exhaustive — it is a one-page cheat sheet, not a full competitive analysis
- [ ] Do not include a "When we lose" section that is dishonestly optimistic — honest loss scenarios build rep trust
- [ ] Do not skip the review date — an outdated battlecard with wrong information is worse than no battlecard
