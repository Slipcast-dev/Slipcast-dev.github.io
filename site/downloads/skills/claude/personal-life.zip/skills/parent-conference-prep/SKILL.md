---
name: parent-conference-prep
description: "Prepare for a K-12 parent-teacher conference — including the hard ones. Use when asked to prep for a parent conference, plan what to say to a parent, or handle a difficult conversation about a student's behavior or grades. Produces a structured agenda, strengths-first talking points backed by specific evidence, a plan for the tough message, anticipated parent reactions with responses, and agreed next steps."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Keep the stated constraints. Give a concrete next step and identify missing inputs.
<!-- slipcast-model-profile:end -->


# Parent Conference Prep Skill

Parents remember how a conference *felt* more than the data in it. The teachers who land hard messages lead with genuine strengths, bring specifics instead of labels, and leave the parent with a partnership, not a verdict. This skill preps the whole conversation — including the reaction you're bracing for.

> **Not quite this?** Use `parent-teacher-conference-prep` when you are the parent getting ready for the meeting.

## Working from a brief

Given the student and the reason for the conference, **write the full prep** — infer likely parent concerns from the situation. Keep it partnership-framed: the teacher and parent on the same side of the table, the challenge on the other.

## Required Inputs

Ask for (if not provided, else infer and label):
- **Grade** and the **reason** for the conference (routine, grades, behavior, a specific incident)
- **The student's strengths** and the **concern**, with any specific examples
- **Anything known about the parent** (prior contact, sensitivities, language needs)

## Output Format

### Agenda (the arc)
Open warm → strengths with evidence → the concern (specific, non-labeling) → what we'll each do → close on partnership. With rough timing for a ~15–20 min slot.

### Strengths first
2–3 genuine strengths, each with a **specific example** (not "he's a good kid").

### The concern, said well
The hard message scripted: describe the behavior/pattern with evidence, not a character label ("I've seen him leave three assignments unfinished this week" — not "he's lazy"). Name the impact, then pivot to the plan.

### Anticipated reactions
The likely parent responses (defensiveness, blame, overwhelm, disengagement) and a calm, non-escalating reply for each.

### Next steps
2–3 concrete, shared actions — what the teacher will do, what the parent can do, and when you'll check back.

## Quality Checks

- [ ] Opens with genuine, specific strengths before any concern
- [ ] The concern is described with evidence and impact, never a character label
- [ ] At least two anticipated reactions have a prepared, de-escalating response
- [ ] Next steps are shared, concrete, and have a check-back
- [ ] Tone is partnership, not verdict; jargon is translated to plain language

## Anti-Patterns

- Leading with the problem before any strength
- Labels ("lazy," "disruptive," "unmotivated") instead of observed behavior
- Dumping data with no plan or partnership
- No plan for the defensive or upset reaction
- Education jargon (RTI, standards codes) left untranslated for the parent

## Example Trigger Phrases

- "Prep for a parent conference."
- "Plan what to say to a parent."
- "Handle a difficult conversation about a student's behavior."
