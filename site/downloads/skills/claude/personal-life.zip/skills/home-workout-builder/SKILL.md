---
name: home-workout-builder
description: "Build a home workout plan that fits your gear, time, and goal — a real weekly structure, not a random list of exercises. Use when asked to build a home workout, make me a workout plan, exercise routine at home, or how do I work out with no gym. Produces a weekly plan matched to your equipment and schedule, each session with warm-up, main work, sets/reps, and progression, swaps for missing gear, and a way to make it harder over time — with a plain 'this isn't medical advice, stop if it hurts' note."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Keep the stated constraints. Give a concrete next step and identify missing inputs.
<!-- slipcast-model-profile:end -->


# Home Workout Builder

A pile of random exercises isn't a program. This builds a structured weekly plan around what you actually have — bodyweight, a couple of dumbbells, a band — and where you want to go, with a way to progress so you keep getting results instead of plateauing or losing interest.

## What This Skill Produces

- **A weekly structure** — how many sessions, which days, what each targets (full-body, upper/lower, etc.)
- **Full sessions** — warm-up, main exercises with sets/reps/rest, and a cool-down
- **Equipment swaps** — alternatives for gear you don't have
- **Progression** — how to make it harder each week (reps, sets, tempo, harder variations)
- **Safety framing** — form cues, and a clear "not medical advice — see a professional for pain or conditions" note

## Required Inputs

Ask for these if not provided:
- **Goal** — strength, muscle, fat loss, general fitness, mobility
- **Equipment** — bodyweight only, dumbbells, bands, pull-up bar, etc.
- **Time** — days per week and minutes per session
- **Level** — beginner, returning, or experienced
- **Limits** — injuries, joints to protect, space constraints

## Framework: Structure, Then Progress

1. **Fit the split to the days.** 2–3 days → full-body; 4+ → upper/lower or push/pull. Match the plan to what they'll actually do.
2. **Cover the movement patterns.** Push, pull, squat/hinge, and core each session or across the week — not just the fun exercises.
3. **Prescribe sets, reps, and rest.** Vague "do some push-ups" doesn't progress; give real numbers tied to the goal.
4. **Build in progression.** Add reps/sets, slow the tempo, or move to a harder variation weekly — progressive overload is what makes it work.
5. **Keep it safe and doable.** Warm-up, form cues, and honest scaling; flag that pain isn't "pushing through," and to see a professional for injuries/conditions.

## Output Format

### Plan: [goal] · [equipment] · [days/week × mins] · [level]

**Weekly structure:** [e.g. Mon full-body, Wed …].

**Session A — [focus]**
- Warm-up: [2–3 min].
- Main: [exercise] [sets×reps, rest] · [exercise] … (swap: [if no gear]).
- Cool-down: [stretch].

**Progression:** week to week — [add reps/sets/tempo/harder variation].

> Not medical advice. Use good form, stop if something hurts (not the same as muscle burn), and check with a professional for injuries or health conditions.

## Quality Checks
- [ ] Split matches the available days/week
- [ ] Sessions cover the main movement patterns, not just favorites
- [ ] Exercises have sets, reps, and rest — not vague instructions
- [ ] Equipment swaps are provided
- [ ] A progression scheme is included
- [ ] Safety/not-medical-advice framing is present

## Anti-Patterns
- **A random exercise list** with no structure or progression.
- **Ignoring the equipment** — programming barbell lifts for a bodyweight setup.
- **No sets/reps/rest** — un-programmable and un-progressable.
- **Skipping warm-up or form cues.**
- **"Push through the pain"** — dangerous; distinguish pain from effort.

## Example Trigger Phrases
- "Build me a home workout — dumbbells only, 3 days a week, 30 minutes."
- "I want to build muscle at home with just bodyweight."
- "Make me a beginner exercise routine, no equipment."
- "Upper/lower split I can do at home with bands and a bench."
- "Full-body workout plan, 20 minutes, bad knees."
