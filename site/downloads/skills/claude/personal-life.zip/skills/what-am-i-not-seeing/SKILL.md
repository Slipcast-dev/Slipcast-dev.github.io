---
name: what-am-i-not-seeing
description: "Surface the blind spot — the missing stakeholder, the ignored option, the risk outside your frame, the thing you're too close to notice. Use when asked what am I missing, what's my blind spot, what haven't I considered, or is there something I'm not seeing here. Produces the considerations outside your current frame: who you haven't accounted for, what you've ruled out without noticing, the second-order effects, and the thing your closeness to the situation hides — the opposite of confirming what you already think."
disable-model-invocation: true  # skill-optimizer
---

# What Am I Not Seeing

The most dangerous gaps are the ones outside your frame — you can't see what you're not looking at. This deliberately searches the edges of your thinking: the stakeholder you forgot, the option you unconsciously ruled out, the ripple effect two steps downstream, and the obvious thing you've gone blind to from being too close. It answers a question your own mind structurally can't.

## What This Skill Produces

- **The missing people** — stakeholders, affected parties, or perspectives you haven't accounted for
- **The unconsidered options** — choices you ruled out without noticing, or never generated
- **The second-order effects** — the consequences of the consequences, downstream of your plan
- **The too-close blind spot** — the thing obvious to an outsider that you've stopped seeing
- **The uncomfortable angle** — the consideration you're subtly avoiding

## Required Inputs

Ask for these if not provided:
- **The situation or plan** — what you're thinking through
- **Your current framing** — how you're seeing it now (so we can look outside it)
- **Who/what you've considered** — to find who you haven't
- **What's been decided** — options already closed off (some may deserve reopening)

## Framework: Look Outside The Frame

1. **Map the current frame.** Understand how the person is seeing it — the edges of that frame are where the blind spots live.
2. **Find the missing actors.** Who's affected or involved that isn't in the picture? Absent stakeholders are a classic gap.
3. **Reopen the ruled-out.** What options were dismissed instantly or never generated? Surface at least one worth a second look.
4. **Trace second-order effects.** Follow the consequences one step further than the person has — the ripple, not just the splash.
5. **Name the too-close miss.** What would an outsider immediately notice that familiarity has hidden? And what's the person avoiding looking at?

## Output Format

### Situation: [what you're thinking through]

**Missing people:** [stakeholders/perspectives not accounted for].
**Unconsidered options:** [choices ruled out or never generated].
**Second-order effects:** [consequences downstream of the obvious].
**The too-close blind spot:** [what an outsider would notice].
**The thing you're avoiding:** [the uncomfortable angle].
**Most important gap:** [the one worth addressing now].

## Quality Checks
- [ ] Looks outside the current frame, not confirming it
- [ ] Names specific missing stakeholders/perspectives
- [ ] Reopens at least one unconsidered option
- [ ] Traces genuine second-order effects
- [ ] Surfaces a too-close or avoided blind spot
- [ ] Flags the single most important gap

## Anti-Patterns
- **Confirming the existing frame** instead of expanding it.
- **Generic "consider the risks"** with nothing specific.
- **Only surface-level gaps** the person already half-knows.
- **No prioritization** of which gap matters most.

## Example Trigger Phrases
- "What am I missing in this plan?"
- "What's my blind spot on this decision?"
- "Who haven't I considered here?"
- "Is there something about this I'm too close to see?"
- "What haven't I thought about with this move?"
