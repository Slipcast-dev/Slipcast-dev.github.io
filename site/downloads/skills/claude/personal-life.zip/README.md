# Дом, семья и образ жизни / Home, Family & Lifestyle · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
