# Редакционный план и переработка контента / Editorial planning and repurposing · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

План публикаций и адаптация материалов по каналам.

Editorial schedules and adaptation across formats.

Выберите скилл под задачу / Choose a skill for your task:

- [content-channel-repurposing](skills/content-channel-repurposing/SKILL.md)
- [editorial-calendar-production](skills/editorial-calendar-production/SKILL.md)
