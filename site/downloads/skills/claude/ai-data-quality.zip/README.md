# Структурированные ответы и качество источников / Structured outputs and source quality · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Проверка схемы ответа и качества источников для поиска с генерацией (RAG).

Response schema and source quality checks for retrieval-augmented generation (RAG).

Рекомендуемый порядок / Suggested order:

1. [structured-output-schema-check](skills/structured-output-schema-check/SKILL.md)
2. [retrieval-source-quality-check](skills/retrieval-source-quality-check/SKILL.md)
