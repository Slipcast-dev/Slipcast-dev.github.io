# Выпуск и производительность сайта / Website release and performance · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Статический сайт, проверка сборки и бюджет производительности.

Static site release, build verification and performance budgets.

Рекомендуемый порядок / Suggested order:

1. [static-site-release-check](skills/static-site-release-check/SKILL.md)
2. [web-performance-budget-check](skills/web-performance-budget-check/SKILL.md)
