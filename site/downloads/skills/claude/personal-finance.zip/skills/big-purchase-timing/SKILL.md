---
name: big-purchase-timing
description: "Decide when to buy a big-ticket item to get the best price — the sales cycles, model-refresh timing, and 'buy now vs wait' math for the specific thing you want. Use when asked when's the best time to buy [item], should I wait for a sale, is now a good time to buy, or when do [products] go on sale. Produces the typical discount calendar for that category, whether a new model/version is due (and if the current one will drop), a buy-now-vs-wait recommendation for your timeline, and price-tracking tactics — flagging that timing is a guide, not a guarantee."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Opus 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Compare options, check edge cases, and state the remaining risks.
- Separate verified facts from assumptions. Flag questions that require review by a qualified professional.
<!-- slipcast-model-profile:end -->


# Big-Purchase Timing

The same TV, mattress, laptop, or appliance can swing hundreds in price depending on when you buy — around holiday sales, end-of-model-year clear-outs, or a new version's launch. This lays out the typical discount calendar for what you want, whether a refresh is coming, and gives a clear buy-now-or-wait call for your actual timeline — honest that these are patterns, not promises.

## What This Skill Produces

- **The discount calendar** — when this category typically goes on sale (seasonal events, holidays, end-of-quarter/model-year)
- **The refresh read** — whether a new model/version is likely due, and whether the current one will get discounted or discontinued
- **A buy-now-vs-wait call** — for your timeline and how much the saving is worth waiting for
- **Price-tracking tactics** — how to watch the price, set alerts, and recognize a genuine deal vs. a fake "sale"
- **A honest caveat** — timing is probabilistic; if you need it now or the saving is small, waiting may not be worth it

## Required Inputs

Ask for these if not provided:
- **The item** — category and, ideally, the specific model
- **Your timeline** — need it now, flexible, or purely opportunistic
- **Budget sensitivity** — how much a potential saving matters vs. convenience
- **New vs. any** — must-have latest model, or happy with last year's
- **Where you'd buy** — region/retailers (affects the sales calendar)

## Framework: Cycles, Refreshes, And Your Timeline

1. **Know the category's calendar.** Each product type has predictable sale windows (major shopping holidays, seasonal clear-outs, back-to-school, end-of-model-year) — map the item to its cycle.
2. **Check for a refresh.** If a new version is imminent, the current model often drops in price (great if you don't need the newest) or sells out — factor the release cadence in.
3. **Weigh the wait.** Compare the likely saving against how long you'd wait and how much you need it — a big saving in three weeks may beat buying today; a small one may not.
4. **Track the price.** Use price-history/alert tools to spot real drops and avoid inflated "was/now" fake sales.
5. **Be honest about uncertainty.** These are patterns, not guarantees — say so, and don't advise waiting months to save a little on something needed now.

## Output Format

### Buy timing: [item] · timeline: [now/flexible] · [region]

**Discount calendar:** best windows are [events/seasons] — typical saving ~[range].
**Refresh watch:** new model [likely when] → current one [drops/discontinues].
**Recommendation:** [buy now / wait until X] — because [saving vs. your timeline].
**Track the price:** [alerts/history tools] · spot fake "sales" by [checking price history].

> Timing is a guide, not a guarantee — prices vary. If you need it now or the saving is small, don't over-wait.

## Quality Checks
- [ ] Gives the category's actual typical sale windows
- [ ] Checks whether a model refresh affects timing/price
- [ ] Weighs the saving against the person's timeline
- [ ] Includes price-tracking and fake-sale detection
- [ ] Honestly caveats that timing isn't guaranteed

## Anti-Patterns
- **"Just wait for a sale"** with no calendar or timeframe.
- **Ignoring the person's actual timeline/need.**
- **Missing an imminent model refresh** that changes everything.
- **Trusting "was/now" pricing** without price history.
- **Advising a long wait** to save a trivial amount on something needed now.

## Example Trigger Phrases
- "When's the best time to buy a new TV?"
- "Should I buy this laptop now or wait for a sale?"
- "Is now a good time to buy a mattress, or is a sale coming?"
- "When do appliances usually go on sale?"
- "New phone's rumored soon — should I wait or buy the current one cheap?"
