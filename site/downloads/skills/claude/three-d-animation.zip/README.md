# 3D-анимация и рендер / 3D animation and rendering · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Блокинг сцен, ключевые кадры, материалы и приёмка рендера.

Scene blocking, keyframes, materials and render validation.

Рекомендуемый порядок / Suggested order:

1. [three-d-shot-blocking](skills/three-d-shot-blocking/SKILL.md)
2. [three-d-animation-render-qa](skills/three-d-animation-render-qa/SKILL.md)
