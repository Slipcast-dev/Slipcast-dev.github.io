# Модели / Models

Выберите модель в своей сессии. Доступ зависит от клиента, тарифа и организации.

Choose a model in your session. Availability depends on your client, plan, and organization.

| Задача / Work | Рекомендуемая модель / Suggested model |
| --- | --- |
| Короткий шаг / Focused task | Claude Haiku 5.5 |
| Обычная работа / Everyday work | Claude Sonnet 5.5 |
| Изображения и интерфейс / Images and UI | Claude Sonnet 5.5 |
| Глубокая проверка / In-depth review | Claude Opus 5.5 |
| Сложная задача / Flagship workflow | Claude Fable 5.2 |

Сверяй результат с референсом и целевым форматом. Отметь визуальные детали, которые не удалось проверить.

Compare the result with the reference and target format. Flag visual details you could not verify.

[Модели / Models](https://code.claude.com/docs/en/model-config) · [Скиллы / Skills](https://code.claude.com/docs/en/skills)
