---
name: discovery-call-prep
description: "Prepare a structured discovery call plan for any prospect. Use when asked to prepare for a sales call, discovery call, prospect meeting, or first call with a potential customer. Produces a call brief with research, hypotheses, questions, and success criteria."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Compare the result with the reference and target format. Flag visual details you could not verify.
<!-- slipcast-model-profile:end -->


# Discovery Call Prep Skill

Produces a complete discovery call brief — research summary, call hypothesis, structured questions, and success criteria — so every call starts with context and ends with a clear next step.

## Required Inputs
- **Prospect company name**
- **Contact name and role**
- **Any known context** (how they found you, prior interaction)
- **Your product/solution** (one line)
- **Call duration** (15 / 30 / 45 / 60 min)

## Output Structure

---

# Discovery Call Brief
**Prospect:** [Company] | **Contact:** [Name, Title] | **Duration:** [X min]

---

### Research Summary
- What they do: [Product/service, customer, business model]
- Size: [Headcount, revenue if public]
- Stage: [Startup / Scaleup / Enterprise]
- Recent news: [Funding, launches, leadership changes — last 90 days]
- Contact background: [Role tenure, previous companies, LinkedIn activity]
- Likely priorities for someone in this role: [Based on title and stage]

---

### Call Hypothesis
Before the call write your best guess:
- **Their most likely pain:** [What someone in this role at this company probably has]
- **Why they would care about us:** [Specific connection to your value]
- **Biggest risk to the deal:** [What might make this not a fit]

Write it down — then test it on the call.

---

### Call Agenda
"Here is what I was thinking for our [X] minutes:
- 2 min: Quick intros
- [X] min: Learn more about your situation
- [X] min: Share how we have helped similar companies
- 5 min: Next steps
Does that work? Anything specific you would like to cover?"

---

### Discovery Questions

Open with context (not a pitch):
- "What prompted you to take this call today?"
- "What does [relevant area] look like for you at the moment?"

Go deeper on pain:
- "How long has [problem] been an issue?"
- "What have you tried to solve it?"
- "What is the impact of not solving this?"

Understand buying context:
- "Who else would be involved in a decision like this?"
- "Have you looked at other solutions?"
- "Is there a reason you are exploring this now?"

Qualify on budget:
- "Have you set aside budget for this kind of initiative?"

Close discovery:
- "Based on what you have told me, it sounds like [summary]. Is that right?"

---

### Success Criteria
This call is successful if we leave with:
- Understanding of specific pain and business impact
- Knowledge of buying process and key stakeholders
- A clear agreed next step (demo / proposal / intro)
- Sense of timeline

This call is NOT successful if we only pitched and got "sounds interesting, send me some info."

---

### Suggested Next Step
"Based on what we discussed, the logical next step would be [specific]. Does [day/time] work?"

## Quality Checks

- [ ] Research summary includes recent news (last 90 days) — not just LinkedIn bio
- [ ] Call hypothesis is written before the call (not post-rationalised after)
- [ ] Discovery questions progress from context → pain → business impact → buying process
- [ ] Success criteria define what "not successful" looks like (not just the ideal outcome)
- [ ] A specific next step is proposed (not "let's stay in touch")

## Anti-Patterns

- [ ] Do not write the call hypothesis after the call — hypotheses written post-hoc are rationalisations, not testable predictions
- [ ] Do not open with a product pitch before establishing the prospect's problem — leading with pitch signals you are not there to learn, which closes discovery conversations
- [ ] Do not use closed questions in the discovery phase ("Do you have this problem?") — they produce yes/no answers that confirm bias rather than reveal pain
- [ ] Do not skip the "not successful" definition in success criteria — a call that ends with "send me more info" feels like progress but is not a qualified next step
- [ ] Do not treat all prospect research equally — recent news (last 90 days) is more relevant to call context than static company facts from LinkedIn

## Example Trigger Phrases
- "Prepare me for a discovery call with [company/contact]"
- "Build a call brief for my meeting with [name] at [company]"
- "What questions should I ask in a discovery call for [use case]?"
