# Задачи по расписанию / Scheduled jobs · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Резервное копирование, сбор отчётов и уведомления о сбоях.

Scheduled backups, report collection and failure alerts.

Выберите скилл под задачу / Choose a skill for your task:

- [scheduled-backup-verification](skills/scheduled-backup-verification/SKILL.md)
- [scheduled-job-failure-alerts](skills/scheduled-job-failure-alerts/SKILL.md)
- [scheduled-report-assembly](skills/scheduled-report-assembly/SKILL.md)
