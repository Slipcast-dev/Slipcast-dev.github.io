# Приёмка релиза и диагностика / Release acceptance and diagnostics · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Файлы релиза macOS и Windows, восстановление копий, диагностика Telegram-бота.

macOS and Windows release files, backup restores, Telegram bot diagnostics.

Выберите скилл под задачу / Choose a skill for your task:

- [backup-restore-verification](skills/backup-restore-verification/SKILL.md)
- [desktop-release-artifact-check](skills/desktop-release-artifact-check/SKILL.md)
- [telegram-bot-diagnostics](skills/telegram-bot-diagnostics/SKILL.md)
