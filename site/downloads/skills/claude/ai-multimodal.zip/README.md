# Мультимодальный анализ / Multimodal analysis · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Проверяемые выводы по изображениям, PDF и видео.

Evidence from images, PDFs and video.

Выберите скилл под задачу / Choose a skill for your task:

- [image-pdf-evidence](skills/image-pdf-evidence/SKILL.md)
- [video-evidence-timeline](skills/video-evidence-timeline/SKILL.md)
