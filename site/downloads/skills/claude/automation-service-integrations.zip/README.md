# Интеграции сервисов, API и вебхуки / Service integrations, APIs and webhooks · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Схемы событий, повторная доставка и журналы без чувствительных данных.

Event mapping, duplicate delivery and privacy-preserving logs.

Выберите скилл под задачу / Choose a skill for your task:

- [api-event-mapping](skills/api-event-mapping/SKILL.md)
- [webhook-delivery-reliability](skills/webhook-delivery-reliability/SKILL.md)
