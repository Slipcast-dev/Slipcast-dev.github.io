---
name: legal-brief
description: "Draft a structured legal brief, case summary, or legal argument outline. Use when asked to write a legal brief, case note, legal memo, argument outline, or position paper. Produces a structured document using IRAC format (Issue, Rule, Application, Conclusion)."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Opus 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Compare options, check edge cases, and state the remaining risks.
- Separate verified facts from assumptions. Flag questions that require review by a qualified professional.
<!-- slipcast-model-profile:end -->


# Legal Brief Skill

This skill drafts structured legal briefs and memos using IRAC format — the standard structure for legal writing.

## Required Inputs
- **Brief type** (legal memo / case summary / argument outline / position paper / letter before action)
- **Legal issue or question**
- **Jurisdiction** (England & Wales / US / EU / Other)
- **Relevant facts**
- **Relevant law or cases** (if known — otherwise flagged as [RESEARCH NEEDED])
- **Audience** (internal memo / court submission / client letter)

## Output Structure

### Header
- **To:** [Recipient]
- **From:** [Author]
- **Date:** [Date]
- **Re:** [Matter reference]
- **Confidential:** Subject to legal professional privilege

### Issue(s)
One sentence per legal question:
- Issue 1: Whether X constitutes Y under [law]

### Brief Answer
One sentence per issue — conclusion upfront before analysis.

### Facts
Concise relevant facts only. Flag disputed facts.

### Law (Rule)
- Relevant statute, regulation, or case law
- How the rule has been interpreted in key cases
- Flag [RESEARCH NEEDED] where law is not provided

### Application
- Arguments in favour
- Counter-arguments and responses
- Areas of uncertainty flagged explicitly

### Conclusion
- Clear answer to each issue
- Overall recommendation
- Suggested next steps

### Caveats
What this memo does not cover. What additional research would change the analysis.

---

WARNING: This draft requires review by a qualified legal professional. It does not constitute legal advice.

## Quality Checks

- [ ] Issue is stated as a specific legal question (not a general topic)
- [ ] Brief answer appears before the analysis (conclusion upfront)
- [ ] Disputed facts are explicitly flagged
- [ ] Areas of legal uncertainty are noted (not hidden in confident language)
- [ ] Caveats section lists what would change the analysis
- [ ] Disclaimer is included

## Anti-Patterns

- [ ] Do not present uncertain legal positions with confident language — areas of legal ambiguity must be flagged explicitly, not smoothed over
- [ ] Do not omit the disclaimer — every legal brief output must include the professional review caveat before the user treats it as advice
- [ ] Do not structure the brief chronologically — IRAC format (Issue, Rule, Application, Conclusion) must be used regardless of how the user framed the request
- [ ] Do not cite cases or statutes from memory without flagging them as [REQUIRES VERIFICATION] — hallucinated citations are worse than no citations
- [ ] Do not conflate jurisdiction — legal positions in England & Wales, US, and EU can differ materially; always confirm jurisdiction before stating the rule

## Example Trigger Phrases
- "Draft a legal memo on [issue]"
- "Write a legal brief arguing [position]"
- "Summarise the legal position on [topic]"
- "Write a letter before action for [situation]"
