---
name: desk-ergonomics-audit
description: "Audit your desk setup and fix what's hurting your neck, back, wrists, or eyes — with specific, mostly-free adjustments before you buy anything. Use when asked to check my desk setup, ergonomics help, my [wrists/neck/back] hurt from my desk, or how to set up my workstation. Produces a point-by-point setup check (chair, screen, keyboard, mouse, lighting), the specific fixes ranked free-first, cheap upgrades only if needed, and micro-break habits — with a 'see a professional for persistent pain/numbness' flag."
disable-model-invocation: true  # skill-optimizer
---

# Desk Ergonomics Audit

Most desk pain comes from a handful of misalignments you can fix for free by moving things a few inches — a screen too low, a chair too high, wrists bent at the keyboard. This audits your setup point by point, gives the specific adjustment for each, and only suggests buying something when a free fix won't do.

## What This Skill Produces

- **A point-by-point audit** — chair, desk height, monitor, keyboard, mouse, lighting, laptop use
- **The specific fix for each** — the exact adjustment (raise screen to eye level, elbows ~90°, feet supported)
- **Free-first ranking** — reposition and improvise before spending; books under a monitor beat a new stand
- **Targeted cheap upgrades** — only where a free fix can't solve it (e.g., external keyboard for laptop users)
- **Micro-break habits** — the movement cadence that matters more than any single tweak
- **A pain flag** — persistent pain, numbness, or tingling → see a professional

## Required Inputs

Ask for these if not provided:
- **The complaint** — neck, upper/lower back, wrists, shoulders, eyes — or a proactive check
- **Your setup** — desk, chair, monitor(s) or laptop, keyboard/mouse, lighting
- **Laptop or desktop** — laptop-only setups need specific fixes
- **Constraints** — budget, space, standing desk, dual monitors
- **Hours & symptoms** — time seated, and stiffness vs actual pain/numbness

## Framework: Align, Free-First, Move

1. **Set the neutral posture targets.** Eyes at the top third of the screen, elbows ~90°, wrists straight, feet supported, thighs level — audit against these.
2. **Fix with what's there first.** Raise the monitor on books, lower the chair, pull the keyboard closer — most fixes cost nothing.
3. **Solve laptop neck.** A laptop forces a choice between neck and wrists — the fix is almost always raise the screen + external keyboard/mouse.
4. **Buy only where needed.** Recommend a cushion, footrest, or keyboard only when repositioning can't solve it.
5. **Movement beats the perfect chair.** Build in micro-breaks and position changes — stillness is the real problem.

## Output Format

### Ergonomics audit: [complaint] · [setup] · [laptop/desktop]

| Area | Target | Your fix |
|---|---|---|
| Monitor | top ~third at eye level | [raise/lower] |
| Chair | thighs level, feet supported | [adjust] |
| Keyboard/mouse | elbows ~90°, wrists straight | [reposition] |
| Lighting | no glare, screen not brightest thing | [fix] |
| Laptop | screen up + external input | [if applicable] |

**Free fixes first:** [list]. **Worth buying (only if needed):** [item → why].
**Move:** micro-break every [x] — [cue].

> Persistent pain, numbness, or tingling isn't an ergonomics tweak — see a professional.

## Quality Checks
- [ ] Audits each area against a clear neutral-posture target
- [ ] Prioritizes free repositioning over purchases
- [ ] Gives the specific laptop fix (raise + external input) when relevant
- [ ] Recommends purchases only where a free fix won't work
- [ ] Includes a micro-break/movement habit
- [ ] Flags persistent pain/numbness for a professional

## Anti-Patterns
- **Leading with gear to buy** before free fixes.
- **Generic "sit properly"** with no specific targets.
- **Ignoring laptop-specific** neck/wrist tradeoffs.
- **No movement advice** — treating posture as static.
- **Dismissing pain/numbness** that needs a professional.

## Example Trigger Phrases
- "My wrists hurt at my desk — can you check my setup?"
- "Audit my home-office ergonomics, I work on a laptop all day."
- "Neck pain from my monitor — how should I set it up?"
- "Best free fixes for my desk before I buy anything?"
- "Set up my dual-monitor workstation ergonomically."
