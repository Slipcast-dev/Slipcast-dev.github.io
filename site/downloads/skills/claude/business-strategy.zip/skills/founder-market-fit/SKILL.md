---
name: founder-market-fit
description: "Articulate founder-market fit — the why-you and why-now story investors and accelerators (YC-style) probe hardest. Use when asked to write the founder story, answer 'why are you the right team', draft YC / accelerator application answers, or explain founder-market fit. Produces a sharp narrative connecting the founder's unfair insight and earned secrets to this specific opportunity — concrete, not a humble-brag."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Separate decisions from assumptions. State dependencies, decision criteria, and the next step.
<!-- slipcast-model-profile:end -->


# Founder-Market Fit Skill

The strongest founder stories aren't résumés — they show an *earned secret*: something this founder knows or can do that others can't, and why that makes them the right person to win this market now. This skill builds that narrative.

## Working from a brief

Given a thin bio, **draft the full narrative anyway**, drawing out the strongest plausible angle and marking inferred details *(assumed — confirm)*. Never refuse for "not impressive enough background"; find the genuine edge in what's there. No placeholders.

## Required Inputs

Ask for (if not already provided):
- **The founder(s)' background** — work, what they built, what they obsess over
- **The idea / market** and how they came to it
- **The earned secret** — what they learned the hard way that the market doesn't know
- **Target** (a VC pitch, a YC/accelerator application, a recruiting narrative)

## Output Format

### 1. The one-line founder-market fit
"[Founder] is the right person to build [this] because [earned insight]" — in a single, specific sentence.

### 2. The story (3 beats)
- **Origin** — how they collided with this problem (lived it, built near it, obsessed over it)
- **The secret** — what they learned that others haven't, stated as a concrete insight not a platitude
- **The proof** — evidence they can execute: what they've already built, shipped, or learned

### 3. Why now, why you
Tie the founder's timing and capability to the market's *why-now*. The reader should feel this is inevitable for *this* team.

### 4. Application-ready answers (if YC/accelerator)
Crisp answers to the classic prompts:
- *What's your unfair advantage / what do you understand that others don't?*
- *Why did you pick this idea? How do you know people want it?*
- *What have you built before / why will you out-execute?*

## Quality Checks

- [ ] The fit is shown through a specific earned secret, not a list of credentials
- [ ] Every claim is concrete (a thing built/shipped/learned), not adjectives ("passionate", "driven")
- [ ] Ties founder capability to the market's why-now
- [ ] Honest — strengthens a real background rather than inventing one

## Anti-Patterns

- A résumé in prose ("10 years at BigCo, then...")
- Vague passion claims with no evidence
- Borrowed secrets (industry truisms anyone could state)
- Overclaiming — investors discount stories that don't ring true

## Example Trigger Phrases

- "Write the founder story."
- "Draft YC / accelerator application answers."
- "Explain founder-market fit."
