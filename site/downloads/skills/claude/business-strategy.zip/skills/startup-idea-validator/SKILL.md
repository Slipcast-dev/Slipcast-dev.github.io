---
name: startup-idea-validator
description: "Pressure-test a startup idea the way a sharp investor or co-founder would — problem, market, wedge, moat, why-now, and the fastest cheap way to test it. Use when asked to validate a startup idea, evaluate a business idea, stress-test a concept, or decide whether something is worth building. Produces an honest assessment with the strongest case, the killer risks, and the next experiment to run — not cheerleading."
disable-model-invocation: true  # skill-optimizer
---

<!-- slipcast-model-profile:start -->
## Running this skill in Claude Code

- Suggested model: **Claude Sonnet 5.5**. For a more complex case, select **Claude Fable 5.2** in /model if available.
- Use the available Claude Code tools. Change models or permissions only at the user's request. Break the work into verifiable steps and report check results.
- Separate decisions from assumptions. State dependencies, decision criteria, and the next step.
<!-- slipcast-model-profile:end -->


# Startup Idea Validator Skill

Most ideas die from one fatal flaw the founder won't see. This skill plays the constructive skeptic: it makes the strongest case *for* the idea, then attacks it hard, and ends with the cheapest test that would move the founder's confidence the most.

## Working from a brief

Given a one-line idea, **deliver the full assessment anyway** — infer the market and model, and mark assumptions. Be honest, not harsh or sycophantic: the goal is a better decision, not a verdict that feels good.

## Required Inputs

Ask for (if not already provided):
- **The idea** — what it is and who it's for
- **The problem** it solves and how people cope today
- **Why the founder** is drawn to it (context for founder-market fit)
- **Stage** — just an idea, a prototype, early users?

## Output Format

### 1. Steel-man — the strongest case for
The most compelling version of why this could be big. Take it seriously.

### 2. Scorecard

| Dimension | Read | Notes |
|---|---|---|
| Problem (real & painful?) | 🟢/🟡/🔴 | |
| Market (big & reachable?) | 🟢/🟡/🔴 | |
| Wedge (sharp entry point?) | 🟢/🟡/🔴 | |
| Why-now (what changed?) | 🟢/🟡/🔴 | |
| Moat (defensible over time?) | 🟢/🟡/🔴 | |
| Distribution (can you reach buyers cheaply?) | 🟢/🟡/🔴 | |

### 3. The killer risks
The 2–3 things most likely to kill this. Be specific — name the assumption that, if false, ends it.

### 4. Closest competitors / why-not-already
Who's near this, and the honest answer to "if this is a good idea, why doesn't it exist / why hasn't [incumbent] done it?"

### 5. The next experiment
The single cheapest, fastest test that would most change your confidence — what to do this week, and what result would be a green vs red light.

### 6. Verdict
*Promising / Promising-with-conditions / Reconsider* — with the one sentence that decides it.

## Quality Checks

- [ ] Steel-mans the idea before critiquing it
- [ ] Names specific killer assumptions, not generic "execution risk"
- [ ] Answers "why doesn't this already exist?"
- [ ] Ends with a concrete, cheap, this-week experiment

## Anti-Patterns

- Cheerleading (validating because the founder wants a yes)
- Generic critique that applies to any startup
- Recommending a 6-month build as the "test"
- A verdict with no path forward

## Example Trigger Phrases

- "Validate a startup idea."
- "Evaluate a business idea."
- "Stress-test a concept."
- "Decide whether something is worth building."
