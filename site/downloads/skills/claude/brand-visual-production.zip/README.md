# Айдентика и визуальные материалы / Brand identity and visual production · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Арт-дирекция, форматы и приёмка визуальных материалов.

Art direction, formats and visual quality checks.

Выберите скилл под задачу / Choose a skill for your task:

- [brand-art-direction](skills/brand-art-direction/SKILL.md)
- [visual-format-qa](skills/visual-format-qa/SKILL.md)
