# Выбор и резервирование ИИ-моделей / AI model selection and fallback · Claude Code

Перенесите нужные папки из skills/ в .claude/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .claude/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Качество, стоимость, задержка и проверка резервной модели.

Quality, cost, latency and fallback checks.

Выберите скилл под задачу / Choose a skill for your task:

- [model-budget-fit](skills/model-budget-fit/SKILL.md)
- [model-fallback-policy](skills/model-fallback-policy/SKILL.md)
