---
name: drug-interaction-intervention
description: "Document a pharmacist's clinical intervention — the interaction or error spotted, what was done, what the prescriber decided, and the outcome — so the record shows the catch and the care that followed. Use when asked to document a clinical intervention, record a prescriber call about an interaction, log a near-miss, or build an intervention record for audit or remuneration. A documentation framework for a licensed pharmacist; every interaction and severity judgement must be verified against current references."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# drug-interaction-intervention

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the intervention record with severity and evidence, the prescriber-call script, the outcome and follow-up, and the aggregate reporting fields.
