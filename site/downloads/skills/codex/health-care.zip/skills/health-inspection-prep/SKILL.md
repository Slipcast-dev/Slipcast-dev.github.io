---
name: health-inspection-prep
description: "Run a self-audit of a food establishment before the health inspector arrives, focused on the violations that actually close kitchens. Use when asked to prep for a health inspection, do a food-safety self-audit, avoid critical violations, or get ready for the health department."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# health-inspection-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a prioritized checklist organized by risk (critical/priority vs. non-critical), the temperature and hygiene fundamentals, a fix list with owners, and how to handle the inspector on the day.
