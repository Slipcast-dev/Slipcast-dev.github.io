---
name: caregiver-burnout-check
description: "Check whether you're burning out as a caregiver — and get a realistic plan to protect yourself before you can't keep going. Use when asked I'm exhausted from caregiving, am I burning out caring for my parent, caregiver stress help, or I have nothing left to give. Not medical or mental-health treatment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# caregiver-burnout-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest read on your burnout signs and how depleted you are, permission and reasons to accept help (which caregivers resist), specific ways to get support and respite, the guilt and identity traps to address, and a realistic self-care plan that fits a caregiver's actual life — because a caregiver who collapses can't care for anyone.
