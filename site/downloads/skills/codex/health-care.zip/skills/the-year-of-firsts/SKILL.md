---
name: the-year-of-firsts
description: "Get through the first year after losing someone — the birthdays, holidays, and ordinary triggers that ambush you — with a gentle plan for the hard days instead of being blindsided. Use when asked how do I get through the holidays after a death, the first birthday without them, grief is hitting me in waves, or coping with the first year of loss. Not therapy; points to grief counseling and support groups."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-year-of-firsts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a map of the anticipated hard days, keep/change/skip options for each, grounding for the ambush waves, ways to include their memory, and gentle markers for when grief needs more support.
