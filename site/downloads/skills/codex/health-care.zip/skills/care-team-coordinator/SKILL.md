---
name: care-team-coordinator
description: "Organize the people and information involved in caring for someone — family, doctors, helpers — so care doesn't fall through the cracks or all land on one person. Use when asked help me coordinate care for, organize caregiving for my parent, set up a care system, or I'm drowning coordinating everyone."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# care-team-coordinator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a map of who does what (medical, daily, financial, emotional), a shared-information system so everyone's on the same page, a way to divide tasks fairly among family, a communication rhythm, and how to keep the key information (meds, contacts, wishes) in one accessible place — turning caregiving chaos into a coordinated effort.
