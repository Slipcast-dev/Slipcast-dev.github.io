---
name: burnout-recovery-plan
description: "Build a realistic recovery plan for burnout — address the causes, not just the symptoms — with changes you can actually make at work and outside it. Use when asked to help with burnout, I'm burnt out, how to recover from burnout, or I'm exhausted and dread work. Not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# burnout-recovery-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on what's driving the burnout (load, control, reward, fairness, values, community), immediate relief steps, the boundary and workload changes that address the root, a recovery timeline with realistic expectations, and a flag that severe or persistent burnout/depression warrants a professional.
