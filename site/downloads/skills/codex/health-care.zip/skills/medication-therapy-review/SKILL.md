---
name: medication-therapy-review
description: "Structure a pharmacist's medication therapy review so it finds the problems worth escalating and documents them in a form a prescriber will act on. Use when asked to conduct a medication review, run an MTM or MUR, deprescribing review, or polypharmacy assessment, or to prepare a review for a patient on many medicines. A documentation and reasoning framework for a licensed pharmacist; it makes no clinical determination and recommends no specific drug or dose."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# medication-therapy-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the medication list reconciled, the drug-therapy-problem list classified and prioritised, the patient-goal alignment, the prescriber recommendations with rationale, and the follow-up plan.
