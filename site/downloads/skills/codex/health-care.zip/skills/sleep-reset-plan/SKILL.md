---
name: sleep-reset-plan
description: "Build a realistic plan to fix bad sleep — a wind-down routine, a consistent schedule, and the daytime and environment fixes that actually move the needle. Use when asked to fix my sleep, I can't sleep, help me sleep better, or build a bedtime routine."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sleep-reset-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the likely disruptors, a wind-down sequence, schedule and light/caffeine timing, environment tweaks, and a 'what to do when you can't fall asleep' rule — flagging that persistent insomnia or symptoms like snoring/apnea warrant a doctor.
