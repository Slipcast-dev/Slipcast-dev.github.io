---
name: wellness-plan
description: "Build a preventive-care (wellness) plan for a pet by species, breed, and life stage. Use when asked to create a wellness plan, plan preventive care, set up a vaccination/parasite schedule, or advise an owner on routine care for a puppy/kitten/adult/senior pet."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wellness-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a life-stage-appropriate schedule — vaccinations, parasite prevention, dental, nutrition, screening diagnostics, and behavioral guidance — with the rationale, so an owner sees preventive care as a plan, not a series of surprise visits.
