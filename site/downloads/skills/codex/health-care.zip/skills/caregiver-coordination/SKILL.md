---
name: caregiver-coordination
description: "Organize care for an aging or ill family member across multiple helpers — the shared care map, a fair rotation with backup rules, the information binder, and family-meeting agendas that prevent the one-sibling-does-everything spiral. Use when asked help me coordinate care for my mom, my siblings and I need to split caregiving, organize care for a sick family member, or set up a care schedule."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# caregiver-coordination

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the care map of needs and coverage, the rotation schedule with escalation rules, the binder outline, and the family meeting agenda.
