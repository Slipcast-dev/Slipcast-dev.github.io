---
name: behavior-intervention-plan
description: "Build a tiered classroom behavior intervention plan (BIP) for a K-12 student, grounded in the function of the behavior. Use when asked to plan a behavior intervention, address a disruptive or off-task pattern, write a BIP, or set up positive behavior supports."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# behavior-intervention-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a function hypothesis, prevention/antecedent strategies, teaching of a replacement behavior, a response plan for when it happens, and a simple data-tracking method — positive and skill-building, not punitive.
