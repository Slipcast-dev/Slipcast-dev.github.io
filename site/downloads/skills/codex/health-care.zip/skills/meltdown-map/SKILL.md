---
name: meltdown-map
description: "Build your personal early-warning system for meltdowns or shutdowns — your specific rising signs, the triggers that stack, what actually helps at each stage, and a plain plan you can hand to the people around you. Use when someone says 'my meltdowns come out of nowhere', 'help me not shut down', 'I need a plan for when I'm overwhelmed', or supports someone who melts down or shuts down. A self-management tool — not a clinical or crisis service."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# meltdown-map

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a staged warning map, a per-stage response plan, and a shareable one-pager.
