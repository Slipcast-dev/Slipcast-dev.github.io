---
name: patient-education-explainer
description: "Explain a condition, a scan result, or why movement helps, in language that reduces fear instead of adding to it — the reframe, the honest uncertainty, and the analogy that does not accidentally frighten. Use when asked to explain a diagnosis to a patient, explain scan findings, reassure someone who is afraid to move, or write patient-facing education material. A communication framework for a licensed clinician; the clinical content is theirs."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# patient-education-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the explanation in plain language, the reframe of frightening terminology, the honest uncertainty statement, the what-you-can-do section, and a teach-back check.
