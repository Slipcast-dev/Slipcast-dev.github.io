---
name: sibling-care-summit
description: "Get siblings onto one team about aging parents before the crisis does it for them — a structured family meeting with an agenda that prevents old-roles regression, a fair-not-equal division of care work (money, time, and proximity counted honestly), decision rules for when parents can't decide, and the written summary that prevents six months of 'nobody told me'. Use when someone says 'my siblings and I need to talk about mum', 'my brother does nothing', 'we keep fighting about dad's care', or before a parent's health forces it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sibling-care-summit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the summit agenda, the care-share worksheet, and the family memo.
