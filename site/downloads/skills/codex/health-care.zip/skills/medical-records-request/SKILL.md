---
name: medical-records-request
description: "Request your medical records and actually get them — what to ask for, the request letter that can't be shuffled aside, the timelines and fee rules to cite (jurisdiction-flagged), and the escalation path for stonewalls. Use when asked how do I get my medical records, write a records request, my doctor's office won't send my records, or what records should I collect."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# medical-records-request

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the itemized request letter, the delivery and format choices decoded, the follow-up ladder, and the personal health-file structure for keeping them.
