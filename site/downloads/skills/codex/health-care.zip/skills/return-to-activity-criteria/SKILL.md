---
name: return-to-activity-criteria
description: "Set criteria-based return-to-activity milestones so the decision rests on what the patient can demonstrate rather than on how long it has been — the test battery, the thresholds, the graded reintroduction, and the honest conversation about residual risk. Use when asked to plan a return to sport or work, set return-to-play criteria, decide whether someone is ready to return, or handle pressure to clear someone early. The clearance decision is the treating clinician's, made with the patient and the relevant medical team."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# return-to-activity-criteria

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the criteria by stage, the test battery with thresholds, the graded exposure plan, the residual-risk discussion, and the decision record.
