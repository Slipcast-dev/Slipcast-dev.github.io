---
name: prior-authorization-letter
description: "Write a persuasive prior-authorization / medical-necessity letter to an insurer. Use when asked to write a prior authorization letter, a letter of medical necessity, or to appeal a denied treatment/medication/procedure."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# prior-authorization-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured letter — patient and request, clinical justification tied to guidelines, treatments tried, and the specific approval asked for — ready for clinician review and signature.
