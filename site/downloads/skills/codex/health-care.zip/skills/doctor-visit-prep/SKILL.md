---
name: doctor-visit-prep
description: "Prepare for a doctor's appointment so the 12 minutes actually get used — the symptom timeline in the format clinicians think in, the prioritized question list, and the advocacy scripts for being heard. Use when asked help me prepare for my doctor appointment, what should I tell my doctor, organize my symptoms, or I always forget what to ask."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# doctor-visit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the one-page visit sheet: symptom history with timeline, medications, the top-3 questions, and the phrases that get concerns taken seriously.
