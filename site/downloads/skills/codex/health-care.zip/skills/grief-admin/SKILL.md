---
name: grief-admin
description: "Get through the brutal logistics after a death — who to notify, what accounts and services to close, in what order, and what genuinely can't wait vs what can wait months — with explicit permission to do it slowly and in pieces. Use when someone says 'my [person] died and I don't know where to start', 'what do I need to do after a death', 'help me handle the admin', or is drowning in the paperwork of loss. Not legal or tax advice — the humane logistics, with pointers to the professional bits."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# grief-admin

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a triaged task list (urgent / soon / whenever), notification scripts, and a gentle sequence.
