---
name: recovery-day-planner
description: "Plan a real rest day — active recovery, genuine downtime, and a reset — instead of either grinding through or collapsing into a guilt-scroll. Use when asked how to spend a rest day, plan a recovery day, I'm burnt out and need to recharge, or what should I do on my day off."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# recovery-day-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a recovery plan matched to what you're recovering from (physical, mental, or both), gentle active-recovery options, restorative downtime that actually restores, light admin to reduce next-week stress, and permission to do less.
