---
name: treatment-plan-estimate
description: "Build a veterinary treatment plan with tiered options and a cost estimate to discuss with a pet owner. Use when asked to prepare a treatment plan, create an estimate for an owner, present diagnostic/treatment options, or have the cost conversation in a vet practice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# treatment-plan-estimate

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clear plan (recommended vs. acceptable-alternative vs. minimum), line-item cost ranges, the medical rationale in plain language, and how to frame the money conversation with empathy so the owner can make an informed, unpressured decision.
