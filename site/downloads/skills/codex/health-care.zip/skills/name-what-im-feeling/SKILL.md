---
name: name-what-im-feeling
description: "Turn a vague bad mood or 'off' feeling into a precisely-named emotion and its likely cause — because naming it is what starts to defuse it. Use when asked I feel off and don't know why, help me figure out what I'm feeling, I'm in a weird mood, or why am I upset."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# name-what-im-feeling

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a short, gentle inquiry that distinguishes the actual emotion from the fog (anxious vs frustrated vs lonely vs overwhelmed), its most likely trigger, what the feeling might be pointing at, and one small thing that tends to help that specific state — never diagnosing, just helping you locate yourself.
