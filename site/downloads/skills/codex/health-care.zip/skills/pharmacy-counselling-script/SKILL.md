---
name: pharmacy-counselling-script
description: "Write the counselling a patient will actually follow when collecting a new or changed medicine — what it is for, how to take it, what to expect, and the one thing that would make them stop. Use when asked to write patient counselling, counsel on a new prescription, explain a medicine to a patient, or improve adherence at the counter. A communication framework for a licensed pharmacist; it makes no clinical determination and substitutes for no product-specific information."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pharmacy-counselling-script

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the counselling script in plain language, the teach-back questions, the red-flag advice, the adherence anticipation, and the documentation line.
