---
name: patient-communication
description: "Write clear, plain-English patient communications for any healthcare context. Use when asked to write a patient letter, patient information leaflet, appointment letter, test-results letter, discharge summary for patients, or health education content."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# patient-communication

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an accessible patient communication at an appropriate reading level with clear next steps.
