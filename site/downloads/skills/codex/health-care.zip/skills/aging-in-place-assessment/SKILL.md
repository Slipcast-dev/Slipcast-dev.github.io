---
name: aging-in-place-assessment
description: "Assess whether and how someone can safely stay in their own home as they age — the home hazards, the support gaps, and the modifications and services that make it work. Use when asked can my parent stay in their home safely, aging in place assessment, is it safe for them to live alone, or what do we need for them to stay home. Not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# aging-in-place-assessment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a room-by-room safety read (fall hazards, accessibility), an honest look at the daily-living and support gaps, the modifications and services that could close them, warning signs that home may no longer be safe, and how to raise it respectfully — helping a family make a clear-eyed, dignity-preserving decision.
