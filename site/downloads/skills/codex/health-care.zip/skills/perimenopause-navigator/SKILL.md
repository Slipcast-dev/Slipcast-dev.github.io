---
name: perimenopause-navigator
description: "Make sense of perimenopause symptoms nobody warned you about and prepare the GP conversation that actually helps — a symptom tracker mapped to what's likely hormonal, the prioritized list to raise, the HRT and treatment questions to ask, and how to push back on dismissal. Use when someone says 'is this perimenopause?', 'my doctor won't take my symptoms seriously', 'help me prepare for a menopause appointment', or is 40-55 and blindsided by symptoms. Not medical advice — it organizes your experience for the clinician who prescribes."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# perimenopause-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a symptom map, a GP-visit brief, and a treatment-questions list.
