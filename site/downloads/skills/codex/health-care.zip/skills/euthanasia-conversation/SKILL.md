---
name: euthanasia-conversation
description: "Guide a veterinary team through a compassionate end-of-life conversation with a pet owner — quality-of-life assessment, the recommendation, and the logistics. Use when asked to help discuss euthanasia, assess quality of life, prepare for a difficult end-of-life conversation, or support an owner facing the decision."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# euthanasia-conversation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a quality-of-life framework, empathetic language for the conversation, how to answer the hard questions (is it time, will it hurt, should the kids be there), and the practical steps (the process, aftercare options, grief support).
