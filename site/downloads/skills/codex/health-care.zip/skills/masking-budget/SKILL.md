---
name: masking-budget
description: "Treat neurodivergent masking as a daily energy budget — audit what passing as neurotypical actually costs you, where the spend is worth it, where you can safely drop the mask, and how to plan a heavy-masking day so you don't crash after. Use when someone says 'I'm exhausted from masking', 'work drains me and I don't know why', 'how do I unmask safely', or is autistic/AuDHD/ADHD and burning out socially. A self-knowledge tool, not a diagnosis or therapy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# masking-budget

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a mask-cost audit, a spend/drop map, and a recovery plan.
