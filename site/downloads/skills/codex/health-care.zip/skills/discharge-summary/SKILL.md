---
name: discharge-summary
description: "Turn a hospital stay into a complete, well-structured discharge summary. Use when asked to write a discharge summary, a hospital discharge note, or to document a patient's admission-to-discharge course for handoff."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# discharge-summary

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a standard discharge summary — admission reason, hospital course, diagnoses, procedures, discharge medications, condition, and follow-up/return precautions — from the provided details.
