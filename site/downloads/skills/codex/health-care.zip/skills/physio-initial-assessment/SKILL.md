---
name: physio-initial-assessment
description: "Structure a physiotherapy initial assessment so the subjective drives the objective and the plan follows from both — the history that localises the problem, the red and yellow flags screened deliberately, and goals set in the patient's own terms. Use when asked to structure a physio initial assessment, write an assessment template, document a first appointment, or improve subjective examination. A documentation framework for a licensed clinician."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# physio-initial-assessment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the subjective structure, the flag screen, the objective examination plan, the working hypothesis with competing explanations, and patient-centred goals.
