---
name: physio-progress-note
description: "Write a physiotherapy progress note that shows clinical reasoning rather than attendance — what changed against the reassessment markers, what that means for the hypothesis, and what the plan does next. Use when asked to write a progress note, document a follow-up appointment, justify continued treatment to a funder, or when notes read as a list of what was done. A documentation framework for a licensed clinician; the clinical content remains theirs."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# physio-progress-note

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the reassessment against markers, the interpretation, the plan change with its reason, the objective-measure trend, and the discharge trajectory.
