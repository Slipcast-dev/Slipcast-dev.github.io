---
name: long-term-care-options
description: "Understand the long-term care options for an older or ill loved one — from in-home care to assisted living to nursing care. Use when asked what are the care options for my parent, in-home care vs assisted living vs nursing home, help me choose a care option, or explain long-term care. Not medical or financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# long-term-care-options

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-English explainer of the main care levels and what each is for, a match to the person's needs (care level, budget, preferences), the key questions and red flags when evaluating providers, cost and funding considerations to research, and how to involve the person in the decision — a map for one of the hardest, most emotional decisions a family makes.
