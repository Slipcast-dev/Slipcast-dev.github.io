---
name: desk-ergonomics-audit
description: "Audit your desk setup and fix what's hurting your neck, back, wrists, or eyes — with specific, mostly-free adjustments before you buy anything. Use when asked to check my desk setup, ergonomics help, my [wrists/neck/back] hurt from my desk, or how to set up my workstation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# desk-ergonomics-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a point-by-point setup check (chair, screen, keyboard, mouse, lighting), the specific fixes ranked free-first, cheap upgrades only if needed, and micro-break habits — with a 'see a professional for persistent pain/numbness' flag.
