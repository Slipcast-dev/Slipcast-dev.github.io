---
name: hydration-and-energy-plan
description: "Beat the afternoon crash with a realistic hydration, food-timing, and movement plan — not a caffeine-and-sugar band-aid. Use when asked how to stop the afternoon slump, I'm always tired after lunch, boost my energy, or a hydration routine."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hydration-and-energy-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on likely crash causes, hydration targets tied to your day, food and caffeine timing that avoids the spike-crash, movement and light micro-fixes, and a flag that persistent fatigue is worth a doctor's check.
