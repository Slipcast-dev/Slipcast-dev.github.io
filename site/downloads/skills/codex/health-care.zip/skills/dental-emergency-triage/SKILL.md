---
name: dental-emergency-triage
description: "Triage a dental emergency call so the right patient is seen today and the rest are safely scheduled — the red flags that are medical rather than dental, the questions that sort urgency, and the interim advice a receptionist can safely give. Use when asked to triage a dental emergency, decide who to fit in today, write phone triage guidance for front desk, or when a patient calls with swelling, trauma, or severe pain. Triage support only; never a diagnosis, and airway or spreading-infection signs go to emergency care immediately."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dental-emergency-triage

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the urgency banding, the question script, the red-flag escalation list, interim self-care within scope, and the documentation line.
