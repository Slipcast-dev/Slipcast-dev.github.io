---
name: respite-care-plan
description: "Plan a genuine break from caregiving — arrange the coverage, hand off the essentials, and actually rest — because respite is what lets you keep going. Use when asked I need a break from caregiving, how do I arrange respite care, I can't leave them alone, or help me get time off from caring. Not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# respite-care-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the coverage options for your situation (family, paid respite, day programs, short-stay), a handoff pack so whoever covers has what they need, how to overcome the barriers (guilt, trust, cost, logistics), and a plan to actually rest during the break rather than worry — turning 'I can never get away' into a real, repeatable break.
