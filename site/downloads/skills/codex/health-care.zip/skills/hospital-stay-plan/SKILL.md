---
name: hospital-stay-plan
description: "Navigate a hospital stay — for yourself or someone you care for — from admission through a safe discharge, so nothing critical falls through the cracks. Use when asked help me through a hospital stay, my parent is in the hospital, prepare for a hospital admission, or what do I need to know for the hospital. Not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hospital-stay-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces what to bring and organize, how to stay informed and involved with the care team, the questions to ask daily, the discharge planning to start early (not at the last minute), and the home-readiness checklist for after — reducing the chaos and the dangerous gaps, especially at discharge.
