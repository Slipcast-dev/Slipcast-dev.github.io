---
name: support-the-bereaved
description: "Know what to actually say and do for someone who's grieving — the real help instead of the empty 'let me know if you need anything.' Use when asked what do I say to someone whose parent died, how do I support a grieving friend, what to write in a condolence, or how to help without making it worse. Points to grief resources when the person needs more than a friend can give."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# support-the-bereaved

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces words that land (and the phrases to avoid), specific concrete help to offer instead of vague availability, a condolence message in your voice, guidance on showing up over the long haul (not just week one), and how to support without centering yourself — so your care actually reaches them.
