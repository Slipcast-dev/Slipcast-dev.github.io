---
name: dental-referral-letter
description: "Write a dental referral letter a specialist can act on without ringing you back — the question you are actually asking, the findings and images that support it, and what you have already tried. Use when asked to write a referral to an endodontist, oral surgeon, periodontist or orthodontist, refer a patient to a specialist, or when a referral was returned for more information. Communication support only; the clinical assessment and the decision to refer are the referring clinician's."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dental-referral-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the referral letter, the attachment list, the urgency marker, and the patient-facing explanation.
