---
name: client-discharge-notes
description: "Write clear at-home care instructions for a pet owner after a veterinary visit, procedure, or hospitalization. Use when asked to write discharge instructions, go-home notes, post-op care, or medication instructions for a pet owner."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# client-discharge-notes

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces plain-language home-care instructions: medications (what/how much/when/how), activity restrictions, what to watch for, warning signs that mean call-now, the recheck plan, and emergency contacts — written so a worried owner can actually follow them.
