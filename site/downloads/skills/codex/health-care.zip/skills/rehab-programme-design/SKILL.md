---
name: rehab-programme-design
description: "Design a rehabilitation programme the patient will actually do — dosed and progressed against stated criteria, built around their week rather than an ideal one, and with the progression rule written down so it does not depend on being remembered. Use when asked to design a rehab programme, prescribe exercises, progress a rehabilitation plan, or when a patient is not doing their exercises. A structuring framework for a licensed clinician; it prescribes nothing for any individual patient."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rehab-programme-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the programme by phase, the dosage and progression criteria, the adherence design, the reassessment schedule, and the patient-facing version.
