---
name: physio-discharge-summary
description: "Write a physiotherapy discharge summary that closes the episode properly — outcomes against the goals that were set, what the patient is leaving with, what would bring them back, and what the referrer actually needs to know. Use when asked to write a discharge summary, close an episode of care, write to a referrer at discharge, or discharge a patient who has not fully recovered. A documentation framework for a licensed clinician."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# physio-discharge-summary

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the outcome summary against baseline, the self-management plan, the flare-up and return criteria, the referrer letter, and the record of incomplete goals.
