---
name: medical-appointment-advocate
description: "Prepare to get the most out of a medical appointment — for yourself or someone you care for — with the right questions, the information to bring, and how to make sure you're heard. Use when asked help me prepare for a doctor's appointment, questions to ask the doctor, advocate for my parent at the doctor, or how do I get the most from this appointment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# medical-appointment-advocate

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a focused list of what to raise and ask (prioritized, since time is short), the history and info to bring, note-taking and 'teach-back' tactics so you actually understand, how to speak up if dismissed, and what to confirm before leaving — not medical advice, but better navigation of care.
