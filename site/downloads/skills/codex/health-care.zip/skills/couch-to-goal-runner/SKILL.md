---
name: couch-to-goal-runner
description: "Build a beginner running plan from wherever you are to a real goal — first nonstop mile, 5K, or 10K — that builds up slowly enough to avoid injury. Use when asked for a couch to 5k plan, help me start running, train for a [distance], or a running plan for beginners."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# couch-to-goal-runner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a week-by-week walk/run progression to the goal, session detail, pacing and form basics, rest and cross-training, and an injury-prevention note — with a 'check with a doctor if you have health conditions' flag.
