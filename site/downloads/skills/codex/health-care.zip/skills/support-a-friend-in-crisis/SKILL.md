---
name: support-a-friend-in-crisis
description: "Show up well for someone going through something hard — loss, illness, a breakup, a crisis — with the right words, the right presence, and concrete help, instead of freezing or saying the wrong thing. Use when asked how do I support a friend going through, what do I say to someone who's struggling, my friend is in crisis, or how can I help someone grieving."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# support-a-friend-in-crisis

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces what to actually say (and the clichés to avoid), how to be present rather than fix, specific concrete help to offer, how to keep showing up over time, and how to look after yourself — with a clear flag to steer them to professional/crisis help when it's beyond a friend.
