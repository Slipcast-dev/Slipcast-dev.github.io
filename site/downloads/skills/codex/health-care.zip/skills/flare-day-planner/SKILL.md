---
name: flare-day-planner
description: "Plan around flare days before they ambush you — spot your early warning signs, pre-build the reduced 'flare mode' version of your life, prepare the cancellation and support scripts in advance, and set up your space so a bad day needs no decisions. Use when someone says 'my flares blindside me', 'I fall apart when a bad day hits', 'help me prepare for flare-ups', or has a relapsing condition (autoimmune, migraine, mental health, chronic pain). A self-management tool, not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# flare-day-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a flare early-warning list, a flare-mode plan, and the pre-written scripts.
