---
name: sensory-audit
description: "Walk a space — home, office, commute, classroom — and find the sensory landmines quietly draining or overloading you, with fixes ranked by cost and impact. Use when someone says 'my office wrecks me and I don't know why', 'I'm overstimulated all the time', 'make my home autism/ADHD-friendly', or lives with SPD, autism, migraine, or misophonia. A self-help audit, not a clinical assessment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sensory-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a room-by-room sensory map, a ranked fix list (free → cheap → invest), and a portable kit for spaces you can't change.
