---
name: dental-clinical-note
description: "Write a dental chart note that survives an insurance audit, a recall years later, and a colleague picking up the case cold — the finding, the justification, the consent conversation, and the materials, in the order a reviewer looks for them. Use when asked to write a chart note, document a procedure, improve clinical documentation, or when a claim was denied for insufficient documentation. Documentation support only; the clinical content is the treating clinician's."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dental-clinical-note

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured note with subjective, objective, assessment and plan, the medical necessity justification, consent documented, materials and lot numbers, and the next-visit plan.
