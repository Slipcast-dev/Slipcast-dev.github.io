---
name: clinical-case-summary
description: "Write a structured clinical case summary or case presentation. Use when asked to write a clinical case summary, case presentation, patient case report, or clinical handover. For educational and documentation purposes only — not a substitute for clinical judgement."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# clinical-case-summary

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured summary using SBAR or SOAP format.
