---
name: reconnect-after-time-away
description: "Rebuild relationships with family, kids, and friends after incarceration or a long absence — how to reach out, repair trust at the other person's pace, and handle the hard first conversations. Use when asked how do I reconnect with my kids after prison, rebuild trust with family after being away, or the first conversation after a long absence. Centers the other person's pace; points to family therapy and reentry family services."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# reconnect-after-time-away

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a paced reconnection plan (who to reach first and how), opening messages that don't demand forgiveness, a way to rebuild trust through consistency rather than words, scripts for the hard conversations, and realistic expectations about time and rejection.
