---
name: end-of-life-wishes-conversation
description: "Have the conversation about someone's end-of-life wishes — before a crisis forces it — gently, respectfully, and thoroughly enough to actually guide decisions later. Use when asked how do I talk about end-of-life wishes, discuss my parent's wishes, advance care planning conversation, or ask about their medical and final wishes. Not legal or medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# end-of-life-wishes-conversation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a way to open this hard conversation without it feeling morbid or forced, the areas to cover (medical wishes, care preferences, where they want to be, what matters to them, practical/legal), how to listen rather than impose, and how to document and share what's decided — so their wishes are known and honored.
