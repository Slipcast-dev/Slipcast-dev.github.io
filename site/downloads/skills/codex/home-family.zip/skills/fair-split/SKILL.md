---
name: fair-split
description: "Divide things that cannot be divided — an inherited house, a dissolved partnership, the furniture after a breakup — using sealed-bid fair division (Knaster), computed by the bundled script so everyone ends provably above their own fair share. Use when asked to split an estate fairly, divide assets between siblings or ex-partners, who gets the house and what do they owe the others, or handle unequal shares. Math for the family meeting; not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# fair-split

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sealed-bid procedure, the computed allocation with exact cash transfers, the per-person fairness proof, and the presentation script.
