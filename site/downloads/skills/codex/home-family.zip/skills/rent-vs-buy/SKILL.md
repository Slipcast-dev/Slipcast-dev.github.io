---
name: rent-vs-buy
description: "Model rent-vs-buy honestly — year-by-year net position for both paths including the assumption everyone drops (the renter invests the difference), with a breakeven horizon instead of a verdict. Use when asked should I rent or buy, does buying beat renting in my city, when does buying break even, or run the rent-vs-buy numbers."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rent-vs-buy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the year-by-year comparison table, the breakeven year, the assumption list with defaults labeled, and the not-modeled list.
