---
name: cn-extracurricular-plan
description: "Use when asked 兴趣班怎么选, 孩子报几个兴趣班合适, 课外班规划, 双减后还能报什么班, 寒暑假怎么安排, 预付费培训退费, or plan a child's out-of-school activities in mainland China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# cn-extracurricular-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a weekly timetable that protects sleep, homework and free play, a choice framework (the child's interest, purpose, cost, travel), a term budget, a check of each class against the 双减 rules on academic training and prepaid fees, contract questions to ask a provider, and a review point to drop what is not working, with rules marked to confirm locally.
