---
name: hoa-violation-response
description: "Respond to an HOA or condo-association violation notice or fine — decide whether to comply, cure, or dispute, and do it on the record. Use when asked to respond to an HOA violation, my HOA fined me, is this HOA rule enforceable, or fight an HOA notice. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hoa-violation-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on whether the citation likely holds (against the governing documents and consistent enforcement), a comply-vs-dispute recommendation, a measured response/appeal letter, the evidence and record-keeping to keep, and escalation options — flagging that HOA rules and rights are governed by your documents and local law.
