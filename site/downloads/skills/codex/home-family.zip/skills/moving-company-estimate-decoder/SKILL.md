---
name: moving-company-estimate-decoder
description: "Decode a moving company estimate — binding vs non-binding, the weight and cubic-feet games, valuation vs insurance, and the red flags that precede hostage-load stories. Use when someone asks 'is this moving quote legit', 'decode my moving estimate', 'binding vs non-binding estimate', or 'how do I avoid moving scams'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# moving-company-estimate-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an estimate-type decode with what-you'll-actually-pay scenarios, ranked red flags, the valuation decode, and the questions that separate real movers from brokers.
