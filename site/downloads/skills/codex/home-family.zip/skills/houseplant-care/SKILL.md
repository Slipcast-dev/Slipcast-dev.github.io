---
name: houseplant-care
description: "Diagnose why a houseplant is struggling and set a care routine it'll actually thrive on — matched to your light, home, and how much attention you'll realistically give. Use when asked why is my plant dying, how do I care for a [plant], my plant's leaves are [yellow/brown/drooping], or help me keep this plant alive."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# houseplant-care

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a likely-cause diagnosis from the symptoms, the specific fix, a simple ongoing care routine (water/light/feed), and honest 'is this the right plant for your space' guidance.
