---
name: dating-profile-doctor
description: "Rewrite a dating profile so it sounds like you on a good day — mined from how you actually talk, specific instead of generic, with photo order feedback and first-message craft — under one hard rule: nothing you can't back up in person. Use when someone says 'fix my dating profile', 'why am I getting no matches', 'what do I say first', or 'roast my Hinge prompts'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dating-profile-doctor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces rewritten bio and prompts, a photo lineup critique, and three first-message templates that reference, not flatter.
