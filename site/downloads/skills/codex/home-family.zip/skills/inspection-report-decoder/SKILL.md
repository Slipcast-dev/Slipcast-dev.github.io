---
name: inspection-report-decoder
description: "Decode a home inspection report into what's cosmetic, what's expensive, and what kills deals — with repair-cost ranges and the negotiation list. Use when asked to decode my inspection report, is this inspection bad, what should I ask the seller to fix, or should I walk after inspection."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# inspection-report-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a findings triage (walk-risk / negotiate / cosmetic), cost ranges per item, the ask-the-seller list, and the questions for your inspector before the objection deadline.
