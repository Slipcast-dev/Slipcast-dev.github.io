---
name: make-friends-as-an-adult
description: "Build a real plan to make friends as an adult — where to meet people you'd actually click with, how to turn acquaintances into friends, and past the awkwardness. Use when asked how do I make friends as an adult, I'm lonely and want more friends, help me build a social life, or I have no friends here."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# make-friends-as-an-adult

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on where to meet the right people for you (shared interests + repeated exposure), the specific move that converts acquaintances to friends (initiate + consistency + vulnerability), a low-pressure action plan, and reassurance that the awkwardness is normal — because adult friendship doesn't happen by accident, it's built.
