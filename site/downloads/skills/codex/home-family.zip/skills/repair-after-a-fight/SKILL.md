---
name: repair-after-a-fight
description: "Repair a relationship after an argument — reconnect, own your part, and rebuild trust — instead of the cold silence that lets damage set. Use when asked how do I make up after a fight, repair things after an argument, reconnect after we fought, or fix things with someone I hurt."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# repair-after-a-fight

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on what actually needs repairing (the incident vs the deeper hurt), a genuine repair approach (own your part specifically, acknowledge their hurt, no fake apology), the words to reopen, and how to rebuild rather than just move on — because unrepaired fights compound, and the repair matters more than never fighting.
