---
name: when-someone-dies
description: "The first two weeks after a death, organized — what genuinely needs doing now, what only feels urgent, who to notify in what order, and the documents everything else will require. Use when asked someone just died what do I do, checklist after a death, help me handle my parent's affairs, or what needs to happen this week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# when-someone-dies

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the triaged timeline (today / this week / can wait), the notification order, the death-certificate math, and the scripts for the hardest calls — written for someone who cannot think straight, because that's who's reading.
