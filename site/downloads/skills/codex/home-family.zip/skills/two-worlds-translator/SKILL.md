---
name: two-worlds-translator
description: "Bridge the gap between your home culture and your adopted one — explain your immigrant parents to your partner (and vice versa), navigate the code-switch that exhausts you, and handle the specific collisions (holidays, money, marriage expectations, 'when are you coming home') without betraying either side. Use when someone says 'my partner doesn't understand my family', 'I'm caught between two cultures', 'help me explain this to my parents', or is a first/second-gen immigrant or third-culture kid."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# two-worlds-translator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a translation of the specific collision, scripts for both directions, and a boundary that honors both worlds.
