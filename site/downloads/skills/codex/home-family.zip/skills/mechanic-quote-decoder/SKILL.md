---
name: mechanic-quote-decoder
description: "Read a garage quote or invoice like someone who can't be padded — which line items connect to your actual symptom, which are while-we're-in-there additions, the questions that make soft lines disappear, when a second opinion pays for itself, and the scripts for declining work without souring the relationship. Use when someone says 'is this mechanic quote fair', 'the garage called and now it's £900', 'do I really need all this', or before authorizing repairs. Not a diagnosis — it's the interrogation of one."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# mechanic-quote-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a line-by-line decode, the callback questions, and the authorize/decline/second-opinion sort.
