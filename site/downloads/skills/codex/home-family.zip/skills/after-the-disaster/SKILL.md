---
name: after-the-disaster
description: "Work through the first hours and days after a disaster — a fire, flood, storm, or evacuation — in the right order: safety and people first, then documenting for insurance and aid, then the immediate recovery steps, without missing the things that cost money or health later. Use when someone says 'my house flooded/burned', 'what do I do after the disaster', 'we just evacuated, now what', or 'the storm damaged everything'. Not legal advice; routes to emergency services and official aid."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# after-the-disaster

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a triaged action plan (safety → document → claim → recover), the do-not-miss list, and where to get help.
