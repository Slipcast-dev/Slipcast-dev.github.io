---
name: saying-no-kindly
description: "Decline requests without damaging relationships or your standing — the fast-clear-warm formula, the alternative-attached no, the no-to-the-boss version (tradeoffs, not refusal), and scripts for the asks that recur. Use when asked how do I say no to this, turn down a request, decline extra work politely, I say yes to everything and drown, push back on my manager, or protect the roadmap from a pet feature."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# saying-no-kindly

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the decline scripts by relationship, the tradeoff framing, and the exact wording tuned to who is asking.
