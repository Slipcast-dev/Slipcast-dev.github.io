---
name: family-cookbook-archivist
description: "Rescue the recipes that exist only in someone's hands — the interview that converts a handful of this and cook until it looks right into measurements, the cook-along session that captures what paper cannot, and the cookbook format that keeps the stories attached to the food. Use when asked to write down grandma's recipes, preserve family recipes, how much is some flour, or make a family cookbook. A cousin of oral-history-kit, aimed at the kitchen."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# family-cookbook-archivist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the recipe-extraction interview, the calibration tricks for unmeasured cooking, the cook-along protocol, the story capture per dish, and the cookbook assembly plan.
