---
name: moving-house-checklist
description: "Turn a move date into a calm, timed plan — every address change, utility switch, deposit-recovery step, and packing wave scheduled so nothing gets missed at the worst possible moment. Use when asked to plan a house move, I'm moving and don't know where to start, make a moving checklist, or what do I need to do before I move."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6 Luna**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Выполни один ограниченный шаг и сверяй результат с ожидаемым форматом.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# moving-house-checklist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a countdown checklist by week, the address-change and utilities list, a deposit/deposit-recovery track for renters, a room-by-room packing plan, and a moving-day and first-night essentials kit — tuned to your situation.
