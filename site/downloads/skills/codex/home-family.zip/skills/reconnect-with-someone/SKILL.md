---
name: reconnect-with-someone
description: "Reach back out to a friend or person you've lost touch with — past the awkwardness of the gap — with a message that reopens the door warmly. Use when asked how do I reconnect with an old friend, it's been too long and it's awkward, reach out to someone I drifted from, or message someone I lost touch with."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# reconnect-with-someone

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on why the awkwardness is smaller than it feels, a warm reach-out message that acknowledges the gap without over-apologizing, a specific hook (a memory, a reason, a simple 'you crossed my mind'), and how to move from message to actually reconnecting — because most drifted friendships just needed one person to text first.
