---
name: moving-quote-decoder
description: "Decode a moving-company quote and spot the lowball, the padding, and the outright scam before you book. Use when asked to check a moving quote, is this mover legit, compare moving estimates, or avoid moving scams."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# moving-quote-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the quote type (binding vs non-binding vs 'not to exceed') and what it really means, the red flags of moving scams (big deposits, no in-home/video survey, low-then-hostage pricing), the questions to ask and credentials to verify, an apples-to-apples comparison, and how to protect yourself on moving day.
