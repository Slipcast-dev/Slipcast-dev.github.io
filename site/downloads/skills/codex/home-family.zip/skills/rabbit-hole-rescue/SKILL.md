---
name: rabbit-hole-rescue
description: "Talk to a family member or friend who's gone down a conspiracy, misinformation, or extremism rabbit hole — without blowing up the relationship or entrenching them further — using connection-first techniques that actually work instead of the facts-and-arguments that don't. Use when someone says 'my dad believes X now', 'my friend's gone down a conspiracy hole', 'how do I talk to them without a fight', or is losing someone to a belief spiral. Connection over winning — and it names when to step back for your own wellbeing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# rabbit-hole-rescue

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- В исходном наборе не разрешён ресурс ../../plugins/pm-digital-safety/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.

## Требования к результату

Produces a conversation approach, what-not-to-do list, and a realistic goal.
