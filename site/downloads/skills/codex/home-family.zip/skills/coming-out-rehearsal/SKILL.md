---
name: coming-out-rehearsal
description: "Prepare and rehearse a coming-out conversation, tuned to the specific person and the real risk — what to say, how to open, how to handle the likely reactions, and a safety-first plan if it could go badly. Use when someone says 'I want to come out to my parents/boss/friend', 'help me tell them I'm [gay/trans/bi/etc.]', 'rehearse this conversation with me', or is planning any identity disclosure. Safety and the user's autonomy come first — it never pushes anyone to come out."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# coming-out-rehearsal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an opener, a rehearsal against realistic reactions, and a safety plan.
