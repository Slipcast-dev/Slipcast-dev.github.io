---
name: renting-after-disaster-damage
description: "Know your position as a tenant when a fire, flood, storm or other disaster damages your rented home: whether rent is still due, who repairs what, what your landlord's and your own insurance cover, moving out or ending the lease, and getting your deposit back. Use when someone says 'our rented flat flooded, do I still pay rent', 'the landlord won't fix the storm damage', 'can I end my lease after the fire', or 'who pays for my damaged belongings'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# renting-after-disaster-damage

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a first-week plan, a rights checklist to confirm locally, messages to the landlord, and a decision on staying or leaving.
