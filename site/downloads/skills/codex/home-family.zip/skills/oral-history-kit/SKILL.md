---
name: oral-history-kit
description: "Record a parent's or grandparent's life while they can still tell it — the question arcs that unlock real stories instead of resume facts, the session logistics that keep it sustainable, the follow-up probes that get the texture, and the pipeline from recordings to a book the family keeps. Use when asked to interview my grandmother about her life, record dad's stories before it is too late, questions to ask an elderly parent, or make a family history book. Warm, unhurried, and honest that later never comes on schedule."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# oral-history-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the session plan with question arcs, the interviewer technique guide, the consent and boundaries conversation, and the transcript-to-book pipeline.
