---
name: home-inspection-decoder
description: "Make sense of a home-inspection report before you buy — what's serious vs cosmetic, what to negotiate, and what to investigate further. Use when asked to explain my home inspection, is this inspection finding serious, what should I negotiate after inspection, or decode my inspection report."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# home-inspection-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a triage of findings by severity (safety/structural/expensive vs minor/cosmetic), plain-English translations, the items worth a repair credit or price negotiation, what warrants a specialist follow-up, and a walk-vs-proceed read — flagging that the inspector and specialists are the authority.
