---
name: family-emergency-plan
description: "Build a family emergency plan — contacts, meeting points, key documents, and 'if something happens to me' info — so your household isn't scrambling in a crisis. Use when asked to make a family emergency plan, be prepared for an emergency, what if something happens to me, or organize our important info."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# family-emergency-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a household plan covering communication and meeting points, an emergency contact/ICE setup, a key-documents and info location list, a basic go-bag/supplies checklist, and a 'someone needs to find this' plan — tailored to your household and likely local risks.
