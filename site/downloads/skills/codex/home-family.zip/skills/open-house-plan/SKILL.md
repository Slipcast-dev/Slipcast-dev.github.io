---
name: open-house-plan
description: "Plan and promote an open house that draws buyers and generates leads. Use when asked to plan an open house, market an open house, or create an open-house checklist."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# open-house-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plan — timing and promotion across channels, prep and staging checklist, a day-of run sheet, lead capture, and follow-up — so the event drives real interest and the agent leaves with leads, not just foot traffic.
