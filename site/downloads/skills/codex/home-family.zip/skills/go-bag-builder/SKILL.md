---
name: go-bag-builder
description: "Build an emergency go-bag tailored to your actual household and your most likely local hazards — not a generic list — covering the people, pets, medications, documents, and hazard-specific items you'd need to grab and leave in minutes. Use when someone says 'build an emergency kit', 'what goes in a go-bag', 'prepare for evacuation', or 'emergency preparedness for my family'. Points to official preparedness sources for your region."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# go-bag-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a personalised packing list, a grab-in-2-minutes core, storage and maintenance guidance, and per-person/per-pet additions.
