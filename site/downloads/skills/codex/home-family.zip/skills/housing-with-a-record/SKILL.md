---
name: housing-with-a-record
description: "Find and land a place to live when a criminal record keeps triggering rejections — where to apply, how to present the record, and the rights that limit how it's used against you. Use when asked how do I rent with a criminal record, landlord denied me for my background, second-chance housing, or explain my record to a landlord. Not legal advice; points to housing counselors and legal aid."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# housing-with-a-record

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a target list of record-tolerant housing (private landlords, second-chance programs, certain nonprofits), a short honest explanation letter, the documents that build trust (references, income proof, rehabilitation evidence), and the fair-housing rights that limit blanket record bans.
