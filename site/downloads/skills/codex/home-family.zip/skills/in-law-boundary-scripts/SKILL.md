---
name: in-law-boundary-scripts
description: "Set a boundary with in-laws or extended family kindly and clearly — the words to say, a united-front approach with your partner, and a plan for the pushback. Use when asked how to set a boundary with my in-laws, my mother-in-law keeps [X], deal with overbearing family, or what to say to my partner's family."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# in-law-boundary-scripts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the actual issue, a warm-but-firm script for the specific situation, a partner-alignment plan (the couple presents together), how to hold the line when they push back, and de-escalation so it protects the relationships rather than blowing them up.
