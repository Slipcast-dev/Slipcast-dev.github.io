---
name: roommate-agreement
description: "Write the flat's constitution before the first passive-aggressive note — money, chores, guests, noise, food, and the exit plan, decided while everyone still likes each other, in language that's firm without being corporate. Use when moving in with roommates, when the dishes cold-war has started, when a partner basically lives there rent-free, or when someone's moving out mid-lease."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# roommate-agreement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a signed-feeling one-page agreement plus the house meeting script to agree it.
