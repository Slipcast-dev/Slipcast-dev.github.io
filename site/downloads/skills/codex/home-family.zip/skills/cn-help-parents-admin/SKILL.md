---
name: cn-help-parents-admin
description: "Use when asked 帮爸妈办医保, 帮父母办养老金认证, 爸妈异地就医备案, 帮老人办银行业务, 父母被诈骗了怎么办, 教爸妈用手机办事, 代办委托书, or help an adult child handle 医保, 社保, 养老金, banking or scam protection for ageing parents in mainland China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-help-parents-admin

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a task list for this errand, what the adult child can do remotely versus what needs the parent in person, the documents and authorisation needed, a step list for the parent in very plain large-step language (长辈版) with a call-for-help line, and an anti-scam card, with every local rule marked to confirm.
