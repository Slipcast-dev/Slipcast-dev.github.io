---
name: notify-everyone-of-a-death
description: "Work through who and what has to be notified after someone dies — the people, agencies, banks, and accounts — in a sane order, so nothing critical is missed while grieving. Use when asked who do I need to notify when someone dies, what to do after a death checklist, or how do I handle my parent's accounts after they died. Not legal or financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# notify-everyone-of-a-death

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an ordered notification checklist (immediate people, then government/SSA, then financial, then subscriptions/digital), what each notification needs (death certificates, account numbers), how many death certificates to order, what to stop vs. transfer vs. close, and the scams that target the newly bereaved.
