---
name: solar-breakeven
description: "Model whether solar panels pay for themselves for your roof — net cost after incentives, bill offset with degradation, electricity inflation, the inverter replacement, and the breakeven year, plus the policy risk no calculator controls. Use when asked are solar panels worth it, when does solar break even, check this solar quote's payback claim, or model solar for my bill."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# solar-breakeven

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the year-by-year table from the script, the breakeven year, the quote-vs-model comparison, and the not-modeled list led by net-metering risk.
