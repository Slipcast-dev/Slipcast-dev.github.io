---
name: blended-family-plan
description: "Plan the merging of two families thoughtfully — roles, rules, routines, and relationships — so a blended household starts on the right foot instead of a collision. Use when asked to help blend our families, moving in with my partner and their kids, step-parenting help, or how to merge two households. Not therapy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# blended-family-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the situation and its sensitivities, an approach to step-parent roles and discipline, a plan to align house rules and routines across homes, ways to build relationships at each child's pace, and how to handle exes and loyalty binds — realistic, not idealized.
