---
name: childcare-comparison
description: "Compare childcare options — nursery/daycare, childminder, nanny, family, or a mix — for your family's real needs, budget, and values. Use when asked to compare childcare options, nursery vs nanny, how to choose childcare, or find the right childcare."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# childcare-comparison

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a needs-and-values profile, a side-by-side of the realistic options on cost/flexibility/socialization/control, the questions to ask and red flags to check on visits, a total-cost read (including subsidies), and a decision that fits your priorities — not a generic ranking.
