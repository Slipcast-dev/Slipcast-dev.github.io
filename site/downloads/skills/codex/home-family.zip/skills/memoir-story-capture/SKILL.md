---
name: memoir-story-capture
description: "Capture a life story — your own or a parent's/grandparent's — into a keepsake, using good interview questions and a structure that turns memories into readable stories. Use when asked to help write a memoir, capture my parent's/grandparent's story, record family history, or preserve someone's life story."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# memoir-story-capture

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a question set that unlocks real memories (not just dates), a session plan for interviewing over time, a structure to organize stories into chapters or themes, prompts to draw out detail and emotion, and options for the final form — so the stories are saved before they're lost.
