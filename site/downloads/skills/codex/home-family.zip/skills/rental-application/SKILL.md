---
name: rental-application
description: "Write a standout rental application / cover letter to a landlord or letting agent. Use when asked to write a rental application, a letter to a landlord, a renter cover letter, or to strengthen an application for a competitive rental."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rental-application

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a concise renter profile and cover letter — who you are, why you're a reliable tenant, your evidence, and a clear ask — that helps a landlord choose you.
