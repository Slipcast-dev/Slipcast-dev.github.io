---
name: property-listing
description: "Write a compelling, accurate real-estate listing description. Use when asked to write a property listing, an MLS/Zillow description, a real-estate listing, or to make a property description more appealing. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# property-listing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a listing — a hook headline, a flowing description that sells the lifestyle and key features, a highlights list, and neighbourhood notes — accurate and Fair-Housing-compliant.
