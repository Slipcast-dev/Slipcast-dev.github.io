---
name: new-baby-logistics
description: "Turn 'we're having a baby' into a calm, timed logistics plan — the admin, leave, registrations, and prep that has to happen, sequenced so nothing critical is left to the newborn haze. Use when asked to plan for a new baby, what do I need to do before the baby comes, new baby checklist, or help me prepare for a newborn."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# new-baby-logistics

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a trimester/countdown checklist of the non-obvious admin (leave, benefits, insurance, registration, pediatrician, essentials), what to set up before vs after birth, and a lean 'actually need it' gear list — not a fear-driven mega-list.
