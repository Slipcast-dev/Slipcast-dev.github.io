---
name: digital-legacy-planner
description: "Plan what happens to your digital life — the account inventory, the access plan that doesn't violate terms or law, platform legacy settings, and the memorialize/delete/preserve decisions, written down while it's easy. Use when asked what happens to my accounts when I die, set up a digital legacy plan, help an executor deal with online accounts, or how does my family get into my stuff."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# digital-legacy-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the tiered inventory, the legal-access setup (password-manager emergency access + platform legacy tools), the wishes document, and the executor's digital checklist.
