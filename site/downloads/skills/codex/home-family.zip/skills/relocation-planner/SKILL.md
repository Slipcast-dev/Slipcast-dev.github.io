---
name: relocation-planner
description: "Plan a move — across town or across a border — as a dependency-ordered project: the lease/housing chain, address-change cascade, utilities cutover, movers, and the go-bag for the gap days. Use when asked help me plan my move, relocation checklist, I'm moving in six weeks what do I do, or moving to another country logistics."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# relocation-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the dependency-ordered timeline, the address-change cascade list, the cutover schedule for both homes, and the moving-day run sheet.
