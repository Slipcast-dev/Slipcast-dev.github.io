---
name: permit-navigator
description: "Work out which permits a project actually needs and the order to get them — building/renovation, business licensing, events, signage, home businesses — so you don't build first and discover the permit later. Use when someone says 'do I need a permit for this', 'what permits for my renovation/business/event', 'help me apply for a permit', or 'the council flagged my project'. Not legal/code advice — it orients and routes to the authority."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# permit-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a permit checklist with the likely permits, their sequence and dependencies, and the official offices to confirm each.
