---
name: home-maintenance-calendar
description: "Build a seasonal home-maintenance calendar so the small upkeep gets done before it becomes an expensive repair. Use when asked for a home maintenance schedule, what should I do to maintain my house, seasonal home checklist, or home upkeep plan."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# home-maintenance-calendar

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a month-by-month/seasonal task list tuned to your home type and climate, grouped by system (roof, HVAC, plumbing, exterior, safety), a note of what's DIY vs pro, the highest-consequence tasks not to skip, and a simple way to track it — so upkeep is routine, not reactive.
