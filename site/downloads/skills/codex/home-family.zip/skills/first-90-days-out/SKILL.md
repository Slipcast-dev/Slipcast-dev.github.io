---
name: first-90-days-out
description: "Build a concrete plan for the first 90 days after release from incarceration — the ID, benefits, housing, check-ins, and money moves that have to happen in order, before they cascade into a crisis. Use when asked I'm getting out of prison what do I do first, reentry plan, just got released and I'm overwhelmed, or first steps after incarceration. Not legal advice; points to reentry services."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# first-90-days-out

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sequenced week-by-week plan for the highest-priority setup (ID and documents, parole/probation compliance, benefits, housing, phone, bank, health/meds), the deadlines that carry real consequences, a triage of what's urgent vs. what can wait, and where to get reentry support.
