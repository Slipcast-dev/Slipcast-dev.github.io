---
name: utility-switch-advisor
description: "Decide whether to switch energy, broadband, or mobile providers — compare the real total cost, dodge the traps, and time it right. Use when asked should I switch energy/broadband/mobile providers, compare utility deals, is this a good energy tariff, or help me switch and save."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# utility-switch-advisor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an apples-to-apples comparison (total annual cost, not headline rate), the traps to check (intro-then-jump pricing, exit fees, contract length), a switch/stay recommendation, the switching steps, and reminders to verify current prices on a comparison source.
