---
name: rent-increase-response
description: "Respond to a rent increase strategically — check its validity first, price your alternatives honestly, then negotiate with the leverage tenants forget they have (turnover costs the landlord more than a compromise). Use when asked my rent is going up what can I do, negotiate my rent increase, is this increase even legal, or should I stay or move."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rent-increase-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the validity checklist, the stay-vs-move math, the negotiation letter with its trade menu, and the decision timeline against the notice period.
