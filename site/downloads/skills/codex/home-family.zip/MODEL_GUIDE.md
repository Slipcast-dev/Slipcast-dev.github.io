# Модели / Models

Выберите модель в своей сессии. Доступ зависит от клиента, тарифа и организации.

Choose a model in your session. Availability depends on your client, plan, and organization.

| Задача / Work | Рекомендуемая модель / Suggested model |
| --- | --- |
| Короткий шаг / Focused task | GPT-6 Luna |
| Обычная работа / Everyday work | GPT-6.2 Sol |
| Изображения и интерфейс / Images and UI | GPT-6.1 Terra |
| Глубокая проверка / In-depth review | GPT-6.2 Astra |
| Сложная задача / Flagship workflow | GPT-6.2 Astra |

Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.

Keep the stated constraints. Give a concrete next step and identify missing inputs.

[Модели / Models](https://learn.chatgpt.com/docs/models) · [Скиллы / Skills](https://learn.chatgpt.com/docs/build-skills)
