---
name: ui-design-pipeline
description: "Run a five-stage UI design pipeline (direction, system, motion, critique, verification) so the result does not look like generic AI output. Use when asked to design or restyle a page, landing page, dashboard or app screen, to make a UI look less AI-generated, or to run the design pipeline. Detects which specialist design skills are installed, hands off to one per stage, and falls back to built-in guidance with the install command when one is missing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ui-design-pipeline

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.

## Требования к результату

Produces a committed direction, a persisted design system file, a motion spec, a critique with fixes, and browser screenshots at mobile and desktop widths.
