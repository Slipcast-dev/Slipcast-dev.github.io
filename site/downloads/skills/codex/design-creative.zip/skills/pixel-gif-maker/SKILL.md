---
name: pixel-gif-maker
description: "Generate retro pixel-text animated GIFs for Slack, Teams, or a PR comment — scrolling marquees, heartbeat pulses, confetti parties, twinkling sparkles — from a bundled pure-stdlib Python script (no PIL, no dependencies, byte-exact deterministic). Use when someone wants a celebration GIF, a 'ship it' GIF, a custom Slack GIF, a launch-day animation, or to make a team win feel like one."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pixel-gif-maker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ready-to-drag .gif file.
