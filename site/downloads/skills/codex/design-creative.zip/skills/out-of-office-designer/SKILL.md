---
name: out-of-office-designer
description: "Design an out-of-office that actually protects the time off — the auto-reply that routes instead of apologizes, the coverage map behind it, and the pre-departure handoff that prevents the beach laptop. Use when asked write my out of office message, going on vacation what do I set up, cover my work while I'm out, or I always come back to chaos."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# out-of-office-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the OOO message with routing, the coverage assignments confirmed, the pre-departure checklist, and the re-entry buffer plan.
