---
name: ux-researcher-designer
description: UX research and design toolkit for Senior UX Designer/Researcher including
  data-driven persona generation, journey mapping, usability testing frameworks, and
  research synthesis. Use when conducting user research, creating personas, mapping
  user journeys, planning usability tests, or validating designs.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ux-researcher-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

