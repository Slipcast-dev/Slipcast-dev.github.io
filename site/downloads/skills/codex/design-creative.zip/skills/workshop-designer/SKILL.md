---
name: workshop-designer
description: "Design working sessions that produce artifacts, not vibes — the outcome-backwards agenda, the activity formats that beat open discussion (silent writing, dot voting, structured rounds), the energy arc, and the output-capture that survives the room. Use when asked design a workshop for X, plan our planning session, facilitate a half-day working session, or our workshops are fun but nothing comes out."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# workshop-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the workshop design: the artifact goal, the activity sequence with timings, the facilitation notes, and the capture plan.
