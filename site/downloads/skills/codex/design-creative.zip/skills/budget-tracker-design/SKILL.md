---
name: budget-tracker-design
description: "Design a budget-vs-actuals tracker that stays alive past February — the category grain that matches real statements, the variance view that answers 'are we okay', the update ritual small enough to survive, and the honest handling of irregular expenses. Use when asked build me a budget spreadsheet, track team spend against budget, why do we always blow the budget invisibly, or design a household/project budget tracker."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сверяй результат с референсом и целевым форматом. Отметь визуальные детали, которые не удалось проверить.
<!-- slipcast-model-profile:end -->


# budget-tracker-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the tracker structure, the variance logic, the irregulars ledger, and the monthly fifteen-minute ritual.
