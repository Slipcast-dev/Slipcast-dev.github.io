---
name: photo-library-rescue
description: "Rescue a photo library drowning in duplicates, screenshots, and 40,000 unsorted items — the triage order that shrinks first (screenshots, bursts, dupes), the album-vs-search philosophy that ends over-organizing, and the backup rule that comes before any deleting. Use when asked organize my photo library, 40k photos help, delete duplicate photos safely, or set up a photo system that lasts."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# photo-library-rescue

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the backup-first step, the shrink passes in order, the light organizing layer, and the monthly habit.
