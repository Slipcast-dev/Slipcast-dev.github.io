---
name: quote-card
description: "Pull the single most shareable quote out of a testimonial, review, interview, or long text and format it as a clean quote card. Use when asked to make a pull-quote, testimonial graphic, or 'quote card' for social/marketing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# quote-card

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tightly-edited quote with attribution and 2-3 alternates, structured to look great exported as a PNG from the playground.
