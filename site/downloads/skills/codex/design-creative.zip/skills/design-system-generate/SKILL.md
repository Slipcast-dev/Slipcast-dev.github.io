---
name: design-system-generate
description: Generate a complete, accessibility-checked design system from scratch
  — colour ramps, type scale, spacing, elevation, and exports for CSS, Tailwind, design
  tokens, Figma, VS Code and PowerPoint. Use when asked to create a design system,
  pick a colour palette, build a starter theme, produce design tokens for a new product,
  or apply an existing brand colour to a full system. For auditing a system that already
  exists use design-system-audit; for extracting one from a live site use brand-guidelines.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# design-system-generate

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

