---
name: replica-design
description: 'Rebuilds an app''s design system for a clone: colour roles, type scale,
  spacing, radius, shadows and every component with its states, as design tokens plus
  component specs, with original assets instead of the target''s logos, icons, illustrations
  or licensed fonts. Includes a WCAG contrast checker. Use when the user says "match
  the design", "rebuild the design system", "get the colours and fonts", "make it
  look like X", "design tokens for my clone", or after /replica-architect.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сверяй результат с референсом и целевым форматом. Отметь визуальные детали, которые не удалось проверить.
<!-- slipcast-model-profile:end -->


# replica-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

