---
name: expense-sheet-design
description: "Design an expense-tracking sheet that survives real receipts — the capture-at-spend habit, the category set that matches reimbursement or tax rules, the receipt-link discipline, and the month-end close that takes minutes because the work happened at spend-time. Use when asked track my business expenses, build an expense sheet for the team, get ready for reimbursement/tax season, or my shoebox of receipts needs a system."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# expense-sheet-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sheet structure, the capture ritual, the category mapping to the real downstream rules, and the month-end close.
