---
name: ui-ux-pro-max-pointer
description: "Point to the ui-ux-pro-max skill by nextlevelbuilder and explain when to use it. Use when asked how to install ui-ux-pro-max, which skill generates and persists a design system, or what handles the system stage of the design pipeline. Contains no upstream skill content."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ui-ux-pro-max-pointer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Справка об отдельном стороннем навыке; сам пакет не включён.

## Требования к результату

Produces the install commands, the Python 3 prerequisite check, guidance on when it fits and when it does not, and credit to the author with a link.
