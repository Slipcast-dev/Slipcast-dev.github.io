---
name: cn-shuzhi-deck
description: "Use when asked 帮我做述职 PPT, 述职 PPT 大纲, 年终述职怎么讲, 10 分钟述职讲稿, 述职 PPT 每页写什么, or turn a written year-end review into a 述职 presentation. For writing the review itself use cn-year-end-review; for a promotion to the next level use cn-promotion-defence."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-shuzhi-deck

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a slide-by-slide 述职 PPT outline with a conclusion-first headline per slide (结论先行), the chart or visual for each, a timed speaking script (讲稿) that fits the slot, a one-slide version for a short slot, and a rehearsal and Q&A checklist.
