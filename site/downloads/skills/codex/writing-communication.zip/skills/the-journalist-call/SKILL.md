---
name: the-journalist-call
description: "Simulate a hostile-but-fair journalist interview about your company or announcement — the questions you fear, live follow-ups on every dodge, then the story they'd file. Use when asked to media-train me, simulate a press interview, prep me for a journalist call, or how will this announcement be covered."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-journalist-call

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the interview transcript with your likely stumbles, the article they would write from it, and a debrief with bridge lines and the quotes to prepare.
