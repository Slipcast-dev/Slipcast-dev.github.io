---
name: plain-language-rewrite
description: "Rewrite jargon-dense text into plain language without losing precision — the translation pass that keeps every fact and qualifier, the jargon triage (terms to replace, terms to keep-and-define), and the reading-level honesty for the actual audience. Use when asked make this readable, translate this for non-experts, de-jargon this announcement, or rewrite this so my parents/customers/new hires understand it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# plain-language-rewrite

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the rewrite with a fidelity check, the jargon ledger, and the kept-terms glossary line.
