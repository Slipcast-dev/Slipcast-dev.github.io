---
name: explain-simply
description: "Explain anything in plain language — a contract clause, a medical term, a tax rule, a tech acronym, a news story — layered from a one-liner to as much depth as you want. Use when asked to explain like I'm 5, explain this simply, break this down in plain English, or what does this even mean."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# explain-simply

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the one-sentence version, a plain-language explanation with a concrete analogy, the 'why it matters to you,' and an honest note on anything genuinely uncertain or oversimplified.
