---
name: version-chaos-untangler
description: "Untangle a document that exists in six copies across email, drives, and desktops — establish the canonical version defensibly, merge the divergent edits, and install the single-source rule that prevents the rematch. Use when asked which version is the real one, merge these document copies, we've been editing different files, or stop the version chaos on this doc."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# version-chaos-untangler

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the version census with the canonical verdict, the divergence merge plan, the announce-and-redirect step, and the single-source going-forward rules.
