---
name: wecom-announcement
description: "Write an internal announcement for WeCom (企业微信) or a company group chat: policy changes, office notices, system outages, holiday arrangements and organisational updates, in the clear, polite register Chinese staff expect. Use when asked 写一则企业微信公告, 帮我写内部通知, 放假通知, 系统维护通知, 组织架构调整公告, or write a staff announcement in Chinese."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wecom-announcement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the announcement with a 标题, the one-line 要点, details by audience, actions and deadlines, a contact, plus a short version for group chats and a pinned-message version.
