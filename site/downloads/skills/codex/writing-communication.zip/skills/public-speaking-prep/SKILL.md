---
name: public-speaking-prep
description: "Prepare for a specific talk, presentation, or speech — a clear structure, a strong open and close, delivery and nerves handling, and a rehearsal plan — so you land it. Use when asked to help me prepare a talk/presentation/speech, prep for public speaking, I have to give a presentation, or calm my speaking nerves."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# public-speaking-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a message-first structure built on your core point and audience, a memorable opening and closing, delivery guidance (pace, pauses, notes vs script), a nerves-management plan, a rehearsal approach, and Q&A prep — tuned to the occasion and your experience.
