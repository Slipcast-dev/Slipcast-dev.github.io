---
name: elected-rep-letter
description: "Write to an elected representative in a way that actually gets action — a specific ask, your local stake, why it's in their interest to respond, and the follow-up — instead of an angry email that gets auto-filed. Use when someone says 'write to my MP/congressperson/councillor', 'contact my representative about X', 'how do I get my rep to act', or 'my letter to the council got ignored'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# elected-rep-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a targeted letter (or call script), tuned to the right representative and level of government, plus a follow-up plan.
