---
name: press-kit-epk
description: "Build an electronic press kit that bookers and blogs actually read — the three-sentence bio that isn't 'genre-defying', a one-page layout with streaming numbers presented honestly, the photo and live-video requirements, and pitch emails tuned per target (venue, blog, radio, festival). Use when a musician says 'I need an EPK', 'venues keep ignoring my emails', 'write my band bio', or 'what do I send festivals'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# press-kit-epk

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the EPK content, the one-page layout spec, and four pitch email templates.
