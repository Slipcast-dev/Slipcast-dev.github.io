---
name: vendor-breakup-email
description: "End a vendor, freelancer, or service relationship cleanly — the notice email that cites the contract, the transition asks that protect your data and continuity, and the door-open close that costs nothing. Use when asked write a cancellation email to our vendor, we're not renewing how do I tell them, end this contractor relationship professionally, or switch providers without drama."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# vendor-breakup-email

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the notice-period check, the breakup email with transition terms, the retention-offer response plan, and the offboarding checklist.
