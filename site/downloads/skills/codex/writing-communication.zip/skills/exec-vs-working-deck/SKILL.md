---
name: exec-vs-working-deck
description: "Stop presenting the working deck to executives — the two-deck split (answer-first exec cut vs. exploration-rich working deck), the compression rules from 40 slides to 8, and the appendix strategy that keeps the depth one click away. Use when asked turn this analysis into an exec version, my leadership readout went badly, how do I compress 40 slides to 10 minutes, or what do execs actually want in a deck."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# exec-vs-working-deck

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the exec cut with the answer-first order, the compression map (what survived, where the rest went), and the Q&A appendix plan.
