---
name: deck-outline-first
description: "Outline a deck as headline sentences before opening the slide tool — each slide a claim that reads as an argument top to bottom, the audience-and-ask header, and the skim test that catches broken decks while they're still bullet points. Use when asked start this presentation, structure my deck, why does my deck feel like a data tour, or get sign-off before I build slides."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# deck-outline-first

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the headline outline, the per-slide evidence notes, the skim test result, and the build rules.
