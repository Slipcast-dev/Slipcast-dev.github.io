---
name: readme-benefit-writer
description: Use when asked to rewrite a README so strangers understand why they should
  care, turn a feature list into benefits, make a side project's README convincing,
  or explain what users get rather than what the code does. Rewrites an existing README
  so every feature is stated as a user benefit in plain sentences, and produces a
  one-line pitch, a Why section, a benefit-led feature list, a quick start, a Your
  data section and a contribution pointer. For a README written from scratch with
  badges, usage and install sections, use readme-writer.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# readme-benefit-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

