---
name: summarize-anything
description: "Turn a long article, email thread, document, or transcript into a tight summary you can act on — the gist, the key points, and what it means for you. Use when asked for a TL;DR, to summarize this, give me the gist, or the key takeaways."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# summarize-anything

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-line TL;DR, the key points as scannable bullets, any decisions/action items with owners, and open questions — faithful to the source, with nothing invented and important caveats kept.
