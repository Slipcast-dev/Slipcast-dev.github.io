---
name: presenter-notes
description: "Write presenter notes that actually help mid-talk — cue-grain phrases instead of scripts, the transitions and numbers that deserve verbatim capture, the timing marks that keep the talk on schedule, and the Q&A crib built in. Use when asked write my speaker notes, I either script everything or wing it, what goes in the notes pane, or I keep running over time."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# presenter-notes

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the notes at cue grain, the verbatim-worthy lines, the timing marks, and the Q&A crib.
