---
name: price-increase-announcement
description: "Announce a price increase without triggering a churn spike — the rationale, grandfathering, effective dates, the FAQ, and the internal brief so support isn't blindsided. Use when asked to announce a price increase, write pricing change comms, raise prices to customers, or communicate new pricing. A pricing-comms craft, not a discount."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# price-increase-announcement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the customer email, the FAQ with objection handling, the grandfathering/transition terms, and the internal enablement brief.
