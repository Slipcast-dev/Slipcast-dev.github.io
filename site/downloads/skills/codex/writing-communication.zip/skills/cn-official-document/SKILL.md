---
name: cn-official-document
description: "Use when asked 帮我写公文, 写一份请示, 写通知 / 报告 / 函 / 纪要, 公文格式怎么排, check this document against GB/T 9704, or draft an official document for a Chinese government body, public institution or state-owned enterprise."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-official-document

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a 公文 in the right document type with every required element in the order GB/T 9704-2012 sets, heading levels and numbering, a layout specification for Word or WPS, and a check of the type-specific rules such as one matter per 请示.
