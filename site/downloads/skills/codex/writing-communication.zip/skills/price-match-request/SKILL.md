---
name: price-match-request
description: "Get a retailer to match a lower price you found — or refund the difference when the price drops right after you bought — with the request written and the exact proof to show. Use when asked for a price match, I found it cheaper somewhere else, the price dropped after I bought it, or can I get a price adjustment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# price-match-request

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the policy-aware request, the evidence that qualifies, the eligibility read (what usually counts vs excludes), and a fallback if they won't match.
