---
name: wechat-article
description: "Write a WeChat Official Account (公众号) article: a headline that earns the open, a digest line, a structure built for reading on a phone, and an ending that drives a share or follow, without clickbait the article does not deliver. Use when asked 帮我写公众号文章, 公众号标题, 推文怎么写, 写一篇公众号推送, or write a WeChat article."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wechat-article

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces three headline options, the digest (摘要), the full article with sub-headings and short paragraphs, cover image guidance, a closing call to action, and a check of claims and sources.
