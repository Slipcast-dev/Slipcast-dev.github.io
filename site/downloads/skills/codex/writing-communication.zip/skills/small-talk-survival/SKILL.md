---
name: small-talk-survival
description: "Survive (and even enjoy) small talk — how to start it, keep it going past the weather, and exit gracefully — for people who find it painful. Use when asked I'm bad at small talk, help me with small talk, what do I say at [event], or how do I make conversation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# small-talk-survival

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces conversation openers that fit the setting, the technique for keeping it flowing (curiosity, follow-up questions, the little disclosures that deepen it), how to get past surface topics toward something real, graceful exit lines, and the reframe that small talk is a bridge, not the destination — tuned to the specific situation you're dreading.
