---
name: outline-before-prose
description: "Outline documents before drafting them — the argument skeleton that gets alignment cheaply, the one-line-per-section discipline, and the review-the-outline step that saves rewriting the prose. Use when asked help me start this document, outline before I write, why do my docs get rewritten from scratch in review, or get sign-off before drafting."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# outline-before-prose

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the outline with each section's claim (not topic), the reader-and-decision header, the outline review step, and the expansion rules.
