---
name: ship-or-slip
description: "Turn a release-readiness argument into one typed decision — ship, ship reduced, or slip — with a defined state, defined options, and a probability for each. Use when asked should we ship Friday, are we ready to release, do we slip the date, go/no-go for the release, or when a launch checklist is done and someone still has to call it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ship-or-slip

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a filled release state, the three-way decision with probabilities and confidence, the act-or-hold verdict against the thresholds, and the one fact that would flip it.
