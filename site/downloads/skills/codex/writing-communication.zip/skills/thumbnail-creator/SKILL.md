---
name: thumbnail-creator
description: Generate article or newsletter thumbnail candidates using the Gemini
  API from inside Claude Code. Claude reads article copy, proposes composition concepts,
  writes image generation prompts incorporating brand specs, calls Gemini to generate
  the images, evaluates the results via computer vision, and returns ranked candidates
  with rationale. Use when asked to create thumbnails, generate cover images, or produce
  visual candidates for an article or newsletter.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# thumbnail-creator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

