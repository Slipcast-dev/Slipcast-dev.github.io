---
name: awkward-message-helper
description: "Draft the hard personal message you keep putting off — chasing money a friend owes, backing out of plans, checking in after a fight, following up on an unanswered text. Use when asked to help send an awkward text, how to say something uncomfortable to a friend, word a difficult personal message, or bring up something touchy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# awkward-message-helper

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a couple of calibrated options, the one line to open with, and the send/wait/call judgement call — warm, honest, and not a doormat.
