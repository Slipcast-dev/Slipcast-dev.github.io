---
name: hook-writer
description: "Generate scroll-stopping hooks — the first line of a post, thread, video, or email that decides whether anyone keeps reading. Use when asked to write a hook, an opener, a first line, a thread starter, a video cold-open, or to make something more clickable."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hook-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces multiple distinct hook options across proven angles (curiosity, contrarian, result, story, stakes), each labelled with why it works and which platform it fits.
