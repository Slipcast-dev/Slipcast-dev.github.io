---
name: the-ruthless-editor
description: "Run any draft through the editor who owes you nothing — the buried lede surfaced, the throat-clearing cut, the hedges un-stacked, every paragraph made to answer so what — with a target of 30% shorter and the voice intact. Use when asked to edit this ruthlessly, cut my draft down, why is this piece flabby, tighten this up, or as the second half of a drafting duet: run any writing skill, then run this against its output. Adversarial to the prose, loyal to the point."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-ruthless-editor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the edited draft, the cut list with reasons, the survived-on-merit list, and the patterns-to-stop diagnosis for the writer.
