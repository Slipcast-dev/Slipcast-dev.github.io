---
name: working-agreements
description: "Write a team's working agreements — the small set of explicit norms (communication, meetings, decisions, conflict) that replace the assumptions people were silently violating, built from the team's actual frictions and revisited on a cadence. Use when asked create team working agreements, set norms for our new team, we keep clashing over how we work, or onboard people into how this team operates."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# working-agreements

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the friction-derived agreement set, the specific-behavior phrasing, the disagreement protocol, and the review cadence.
