---
name: eulogy-and-obituary-writer
description: "Write a eulogy or obituary for someone you loved when you're grieving and the words won't come — a true, warm piece that sounds like them and like you. Use when asked help me write a eulogy for my father, write an obituary, I have to speak at the funeral, or I don't know what to say about them. Gentle process, no interrogation, nothing invented."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# eulogy-and-obituary-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a 3-5 minute eulogy or an obituary drafted from your memories rather than cliches, the right structure and length for the setting, and a delivery copy formatted for shaking hands.
