---
name: kr-work-report
description: "Use when asked 보고서 써 줘, 주간보고 작성해 줘, 개조식으로 정리해 줘, 팀장님께 보고할 내용 정리, 1페이지 보고서, 업무 보고서 양식, or write a Korean business report or weekly report."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# kr-work-report

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a Korean workplace report in 개조식 and 두괄식 style: a one-line conclusion, then 현황, 문제점, 대안 비교, 건의사항 and 향후 계획 for a 보고서, or 금주 실적, 차주 계획 and 이슈 및 협조 요청 for a 주간보고, with consistent noun-form endings, numbers and owners, plus a short verbal briefing version.
