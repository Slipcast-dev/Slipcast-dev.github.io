---
name: escalation-email
description: "Escalate an issue up the chain without burning the person you're escalating past — the facts-first structure, the tried-already section that earns the escalation, and the specific ask that makes action easy. Use when asked I need to escalate this, write an email to my boss's boss, this vendor issue needs to go up, or how do I go over someone's head professionally."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# escalation-email

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the escalation email with its evidence spine, the pre-escalation courtesy step, and the relationship-preserving framing.
