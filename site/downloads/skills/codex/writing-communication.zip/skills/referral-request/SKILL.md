---
name: referral-request
description: "Write a short message asking someone at a target company for a referral or a conversation, sized to how well the person knows them, with an easy way to say no. Use when asked how do I ask for a referral, message someone at Google about a job, ask a former colleague to refer me, or write a LinkedIn message to an employee. For general networking, see networking-outreach."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# referral-request

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the message for the right channel and relationship strength, a ready-to-forward blurb the referrer can paste, and a single follow-up.
