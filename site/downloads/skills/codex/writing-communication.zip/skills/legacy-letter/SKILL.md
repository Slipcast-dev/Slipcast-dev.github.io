---
name: legacy-letter
description: "Write a letter to the people you love, to be read later — the things you'd want them to know, the stories only you hold, the permission and the love that outlive you. Use when someone says 'help me write a letter to my kids/partner', 'legacy letter', 'ethical will', 'something for them to have when I'm gone', or is facing illness, aging, deployment, or simply wants to. An emotional-legacy tool, not legal (it is not a will)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# legacy-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a warm, true letter in the writer's own voice — one to each person, or one to all — plus a light plan for when and how it's found.
