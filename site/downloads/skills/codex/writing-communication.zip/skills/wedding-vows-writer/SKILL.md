---
name: wedding-vows-writer
description: "Write personal wedding vows that sound like you — specific, heartfelt, and the right length — instead of generic or cheesy. Use when asked to write my wedding vows, help me with vows, what should I say at my wedding, or vows that aren't cliché."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wedding-vows-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces vows built from your real story and specifics, a structure (who you are together, a promise or few, a look forward), the right tone and length for your ceremony, coordination notes with your partner, and a version you can actually deliver out loud without crying through the whole thing.
