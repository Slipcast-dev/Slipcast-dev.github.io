---
name: witness-statement-writer
description: "Write a clear, factual witness statement or account of an incident — for an insurance claim, small claims, a workplace matter, or the police — that sticks to what you saw and holds up. Use when asked to write a witness statement, an account of what happened, a statement for [insurance/court/HR], or document an incident I witnessed. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# witness-statement-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured, chronological statement of facts (who, what, when, where), a clean separation of observation from opinion, the details that matter, and formatting/sign-off basics — flagging that for legal proceedings you should follow the required format.
