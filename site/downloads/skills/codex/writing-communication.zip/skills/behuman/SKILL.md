---
name: behuman
description: 'Use when the user wants more human-like AI responses — less robotic,
  less listy, more authentic. Triggers: ''behuman'', ''be real'', ''like a human'',
  ''more human'', ''less AI'', ''talk like a person'', ''mirror mode'', ''stop being
  so AI'', or when conversations are emotionally charged (grief, job loss, relationship
  advice, fear). NOT for technical questions, code generation, or factual lookups.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# behuman

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

