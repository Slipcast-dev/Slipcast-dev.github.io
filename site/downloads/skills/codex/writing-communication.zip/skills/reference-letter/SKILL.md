---
name: reference-letter
description: "Write a credible, specific letter of recommendation or reference. Use when asked to write a reference letter, a letter of recommendation, a character reference, or to recommend someone for a job, school, or tenancy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# reference-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured reference — your relationship, specific evidence of their strengths, a comparative endorsement, and a clear recommendation — tailored to what the reader is deciding.
