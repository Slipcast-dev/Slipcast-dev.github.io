---
name: fact-check-pass
description: "Run a claim-by-claim fact-check pass on a draft article, script, or report before publication. Use when asked to fact-check a piece, verify claims before publishing, or do editorial verification."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# fact-check-pass

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a claim inventory (every checkable assertion pulled out), a verification status and source for each (confirmed / needs sourcing / unverifiable / wrong), the fixes, and a flag on the high-risk claims (numbers, quotes, names, legal/defamatory statements) that must not go out unverified.
