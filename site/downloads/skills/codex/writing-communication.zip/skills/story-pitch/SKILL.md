---
name: story-pitch
description: "Pitch a news or feature story to an editor — the angle, why now, and how you'll report it. Use when a reporter or freelancer needs to pitch a story, sell an editor on an angle, or write a query letter to a publication. Distinct from media-pitch (PR pitching a story TO journalists)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# story-pitch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tight pitch: the hook and angle, why it matters and why now, the reporting plan and sources, your access/credibility, and the format/length fit.
