---
name: message-for-the-moment
description: "Write the short message you freeze on — a thank-you, condolence, congratulations, apology, or a graceful 'no' to an invite — warm, specific, and in your own voice. Use when asked to write a thank-you note, a sympathy/condolence message, a congratulations, a quick apology, or how to politely decline."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# message-for-the-moment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces two or three ready-to-send options at the right length for the channel, plus the one line that carries the message, never generic filler.
