---
name: reference-request-kit
description: "Secure strong references after a departure — who to ask, the ask messages, the briefing sheet that makes their reference specific, and the LinkedIn recommendation swap. Use when asked to help me get references, write a reference request, prep my referee, or ask my old manager for a recommendation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# reference-request-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the referee shortlist with rationale, tailored ask messages, a one-page referee briefing sheet, and the follow-up etiquette.
