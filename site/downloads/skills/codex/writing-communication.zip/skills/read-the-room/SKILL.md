---
name: read-the-room
description: "Figure out the real social dynamics of a situation — the unspoken mood, who holds influence, what's actually going on beneath the surface — so you respond to what's real, not just what's said. Use when asked help me read this situation, what's really going on here, how should I play this socially, or I can't tell the vibe."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# read-the-room

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an interpretation of the likely dynamics from your description (the mood, the power/influence, the unspoken tensions, what people actually want), how to check your read, and how to adjust your approach — with a caution against over-reading and a nudge to verify rather than assume.
