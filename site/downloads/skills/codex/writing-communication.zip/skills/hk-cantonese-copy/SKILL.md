---
name: hk-cantonese-copy
description: "Use when asked 幫我寫廣東話文案, 寫香港 IG post, 改成港式口語, Facebook 專頁帖文點寫, Threads 文案, 寫粵語廣告, or write marketing copy and social posts for a Hong Kong audience."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# hk-cantonese-copy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces copy in Traditional Chinese with Hong Kong usage at the chosen register (書面語, 口語化書面語, or full written Cantonese), natural English code-mixing, versions per platform (Instagram, Facebook, Threads, and a caution note for LIHKG), hashtags, and a checklist that catches Simplified characters, mainland vocabulary and claims that need evidence.
