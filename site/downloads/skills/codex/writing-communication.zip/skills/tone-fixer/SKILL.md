---
name: tone-fixer
description: "Rewrite a message to the tone you actually want — less harsh, more confident, warmer, firmer, or shorter — without losing your point. Use when asked to make this sound less rude, soften this email, make me sound more confident, make this nicer/firmer, or fix the tone of a message."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tone-fixer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces two or three rewrites at the target tone, a note on exactly what was changed and why, and a flag if the original's tone was fine as-is.
