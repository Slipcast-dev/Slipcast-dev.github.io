---
name: speak-at-the-council
description: "Turn three minutes at a council or community meeting into the version that actually moves the decision — a public comment built as ask-story-evidence-ask, timed to the real decision process, with a neighbor coalition plan and the written follow-up officials can act on. Use when someone says 'I want to speak at the council meeting', 'they're planning X on our street', 'how do I fight this decision', or 'write my public comment'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# speak-at-the-council

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the 3-minute speech, the one-page leave-behind, and the campaign timeline.
