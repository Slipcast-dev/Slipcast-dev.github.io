---
name: conference-talk-proposal
description: "Write a conference talk proposal / CFP submission for a tech or developer conference. Use when asked to submit to a CFP, propose a talk, or write a session abstract."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# conference-talk-proposal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a compelling title, abstract, audience takeaways, an outline, and the speaker pitch — tuned to what selection committees actually look for.
