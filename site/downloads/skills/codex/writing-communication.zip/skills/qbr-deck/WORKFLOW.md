# QBR Deck Skill

Produce a complete Quarterly Business Review deck — structured, data-backed, and customer-focused. A good QBR demonstrates value delivered, aligns on goals for the next quarter, and strengthens the executive relationship. It should never feel like a product demo or a vendor update.

## Required Inputs

Ask for these if not already provided:
- **Account name**, CSM name, and customer stakeholders attending
- **Contract details** — ARR, contract start date, renewal date
- **Last quarter's goals** (from previous QBR or kickoff)
- **Usage and adoption data** — key metrics for the quarter
- **Support summary** — tickets raised, resolution time, any escalations
- **Business outcomes the customer cares about** — what success looks like for them
- **Product updates or new features** relevant to this customer
- **Goals for next quarter**
- **Any open commercial conversations** (expansion, renewal, at-risk signals)

## QBR Principles

- Lead with customer outcomes, not product features
- Every metric should connect to a business result the customer cares about
- The agenda is a conversation, not a presentation — build in time for customer input at every stage
- Close with mutual commitments, not just vendor actions

## Output Format

---

# QBR: [Account Name] × [Your Company]
**[Quarter] [Year] Business Review**

**Date:** [Date] | **Location / Call link:** [TBC]
**Customer attendees:** [Names and roles]
**[Your company] attendees:** [Names and roles]

---

## Slide 1: Agenda (5 min)

| Time | Topic | Owner |
|---|---|---|
| 0:00 | Welcome and introductions | CSM |
| 0:05 | [Last quarter] — how did we do? | CSM + Customer |
| 0:20 | Value delivered — business impact | CSM |
| 0:35 | What's coming — roadmap preview | CSM / Product |
| 0:45 | [Next quarter] — goals and priorities | Customer |
| 0:55 | Actions and mutual commitments | CSM |
| 1:00 | Close | |

*Talking point: "We've kept today to 60 minutes. We want as much of this to be a conversation as possible — please push back, redirect, and ask questions throughout."*

---

## Slide 2: Where We Are Together (2 min)

**Partnership snapshot:**
- **Customer since:** [Date]
- **Contract value:** £/$/€[ARR]/year
- **Renewal date:** [Date]
- **Active users:** [N] of [N] licensed seats ([X]% adoption)
- **Products / modules active:** [List]

*Talking point: "Before we dive in — a quick picture of where we are. [X] months in, [Y] active users, and this is our [Nth] QBR together."*

---

## Slide 3: Last Quarter — Goals We Set Together (5 min)

| Goal | Set in [Last QBR / Kickoff] | Status |
|---|---|---|
| [Goal 1] | [What we committed to] | ✅ Achieved / ⚠️ Partial / ❌ Missed |
| [Goal 2] | [What we committed to] | ✅ Achieved / ⚠️ Partial / ❌ Missed |
| [Goal 3] | [What we committed to] | ✅ Achieved / ⚠️ Partial / ❌ Missed |

For any partial or missed goal: state what happened and what changes next quarter.

*Talking point: "Let's start with accountability. Here's what we said we'd achieve last quarter — let's be honest about where we landed."*

---

## Slide 4: Usage and Adoption (5 min)

**Quarter-over-quarter trend:**

| Metric | [Q-1] | [Q] | Change |
|---|---|---|---|
| Monthly active users | [N] | [N] | +/-X% |
| Sessions per user per week | [N] | [N] | +/-X% |
| [Key feature 1] adoption | [X]% | [X]% | +/-X% |
| [Key feature 2] adoption | [X]% | [X]% | +/-X% |

**Highlights:**
- [Positive adoption trend to call out]
- [Feature or workflow with strongest engagement]

**Opportunity:**
- [Feature with low adoption that could drive more value — link to their goals]

*Talking point: "Usage is [up / stable / something we want to talk about]. The area I'd like to focus on is [feature] — we're not seeing the adoption we'd expect given [their goal], and I want to understand why."*

---

## Slide 5: Business Impact — Value Delivered (10 min)

Lead with outcomes, not activity.

**[Outcome 1: customer's primary success metric]**
- Before: [baseline]
- Now: [current state]
- Impact: [quantified business result — time saved, revenue influenced, cost reduced, risk mitigated]

**[Outcome 2]**
- [Same structure]

**[Outcome 3]**
- [Same structure]

**Customer evidence** (use if available):
> "[Quote from champion or user about value experienced]"

*Talking point: "This is the section I most want your input on. Are these the outcomes that matter to your business? Are there other ways you're measuring success that we should be tracking?"*

---

## Slide 6: Support Summary (3 min)

| Metric | This quarter | Last quarter | Trend |
|---|---|---|---|
| Tickets raised | [N] | [N] | ↑ / → / ↓ |
| Average resolution time | [X hrs] | [X hrs] | ↑ / → / ↓ |
| P1 / critical issues | [N] | [N] | ↑ / → / ↓ |
| CSAT score | [X/10] | [X/10] | ↑ / → / ↓ |

**Notable issues this quarter:**
- [Any escalation or major ticket — brief summary and resolution]

**What we're doing differently:**
- [Any process change or improvement based on support patterns]

---

## Slide 7: What's Coming — Roadmap Preview (5 min)

Focus only on what's relevant to this customer's goals. Do not dump the full roadmap.

| Feature / Improvement | Expected | Why it matters to [Account Name] |
|---|---|---|
| [Feature 1] | [Q+1] | [Direct link to their goal or pain point] |
| [Feature 2] | [Q+1 / Q+2] | [Direct link] |
| [Feature 3] | [H2] | [Direct link] |

*Talking point: "I've filtered the roadmap to what I think matters most to your team. I'd love your reaction — are these the right priorities from your perspective?"*

---

## Slide 8: Next Quarter — Your Goals (10 min)

**Customer input section — facilitate, don't present.**

Prompt questions:
- "What does success look like for your team in [next quarter]?"
- "What's the biggest challenge you're trying to solve in the next 90 days?"
- "Is there anything about the way you're using [product] you want to change?"

**Capture live:**

| Goal for next quarter | Owner (customer) | How we'll support it | How we'll measure it |
|---|---|---|---|
| [Goal 1] | [Name] | [CSM / product action] | [Metric] |
| [Goal 2] | [Name] | [CSM / product action] | [Metric] |

---

## Slide 9: Mutual Commitments (5 min)

**[Your company] commits to:**
1. [Specific action — owner — by when]
2. [Specific action — owner — by when]
3. [Specific action — owner — by when]

**[Account Name] commits to:**
1. [Specific action — owner — by when]
2. [Specific action — owner — by when]

**Next touchpoint:** [Date of next check-in or mid-quarter review]

---

## Slide 10: Thank You + Open Q&A (5 min)

- Recap the one headline from today: [The single most important thing you want them to remember]
- Confirm actions are captured and shared after the call
- Ask: "Is there anything we didn't cover today that you wanted to raise?"

---

## Preparation Checklist

- [ ] Usage data pulled and QoQ comparison calculated
- [ ] Last QBR goals reviewed — status confirmed before the meeting
- [ ] Business outcomes framed in customer language (not product language)
- [ ] Roadmap filtered to this account's specific use cases
- [ ] Customer's goals for next quarter researched or pre-confirmed with champion
- [ ] Executive sponsor briefed on any sensitive topics before the call
- [ ] Actions from previous QBR reviewed — any outstanding items addressed

## Deeper Materials

This skill ships with support files — use them when they are available:

- **`references/value-narrative.md`** — The QBR Value Narrative: Their Numbers, Not Your Features. Apply it while producing the output; it carries the calibration and judgment calls the method summary above compresses.
- **`templates/qbr-outline.md`** — a fill-in version of the deliverable with the quality gates inline. Offer it when the user wants to work the document themselves rather than have it generated.

## Scoring Rubric (0–40)

Score any output of this skill before handing it over; 32+ is ship-quality.

| Dimension | 0 | 5 | 10 |
|---|---|---|---|
| Outcome framing | Value slide is product activity (logins, sessions, features shipped) dressed as impact | Business outcomes present but unquantified, or quantified in vendor units rather than the customer's own metrics and currency | Every value claim is a before/after in the customer's units (hours, spend, attrition, £/$), and shaky attribution is disclosed rather than claimed |
| Accountability honesty | Last quarter's goals missing, or every goal quietly marked achieved; problems and escalations omitted | Goals graded but misses lack a cause and a changed plan; support issues mentioned only in passing | Every goal graded ✅/⚠️/❌ with cause and corrective plan for misses, and the quarter's worst moment (outage, escalation, disputed number) gets its own airtime with what changes next |
| Customer airtime & facilitation | Deck is a one-way vendor presentation; no customer input sections | Agenda nominally includes customer slots but talking points don't actually hand over the floor, or airtime totals under 20 minutes | Customer holds 20+ minutes by the agenda, the goals slide is pure facilitation with prompts and a live-capture table, and multiple talking points explicitly invite pushback |
| Commitments & relevance | No mutual commitments; roadmap is a full product dump | Commitments exist but are vendor-only or undated; some roadmap items lack a link to this customer's goals | Both sides own named, dated commitments, every roadmap row states why it matters to this account, and a next touchpoint is booked before the deck ends |

## Quality Checks

- [ ] Every slide has a talking point, not just a title
- [ ] Value slide leads with business outcomes, not product activity
- [ ] Roadmap preview links each item to a customer goal
- [ ] Mutual commitments section has real owners on both sides
- [ ] Customer has at least 20 minutes of airtime in the agenda

## Anti-Patterns

- [ ] Do not fill the QBR with product activity metrics — lead with business outcomes the customer cares about
- [ ] Do not present a roadmap without linking each item to a customer goal — vendor priorities are not a QBR agenda
- [ ] Do not run a QBR as a one-sided presentation — it must include structured time for the customer to speak
- [ ] Do not close a QBR without documented mutual commitments with named owners on both sides
- [ ] Do not skip the "what's not working" slide — suppressing problems erodes trust and misses renewal risks

## Example Trigger Phrases

- "Prepare a QBR."
- "Build the business review deck for this customer."
- "Prepare the executive review."
- "Plan the quarterly check-in with this account."
