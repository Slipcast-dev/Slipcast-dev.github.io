---
name: professional-translator
description: "Translate text professionally — preserving tone, register, and meaning, not word-for-word. Use when asked to translate a document, email, or content between languages, or to improve a literal/machine translation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# professional-translator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a natural, register-appropriate translation plus translator's notes on choices, untranslatable terms, and anything that needs localization rather than translation.
