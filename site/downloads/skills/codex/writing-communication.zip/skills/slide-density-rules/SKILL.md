---
name: slide-density-rules
description: "Fix slides that are documents in landscape mode — the one-point-per-slide rule, the projection-vs-reading fork that decides density, the text diet (headlines and evidence, prose to notes), and the glance test. Use when asked my slides are too busy, how much text per slide, fix this wall-of-bullets deck, or make this readable from the back of the room."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# slide-density-rules

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the density diagnosis, the per-slide fixes (split, strip, or move-to-notes), the projection/document fork decision, and the glance-test results.
