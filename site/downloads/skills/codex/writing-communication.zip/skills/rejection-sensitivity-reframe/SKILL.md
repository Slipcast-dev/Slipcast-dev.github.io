---
name: rejection-sensitivity-reframe
description: "Reread a harsh message, criticism, or perceived slight without the emotional spike — separate what was actually said from what your brain is amplifying. Use when asked this message really stung, am I overreacting to this, help me not spiral over this feedback, or did they mean it that way."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rejection-sensitivity-reframe

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a calm read of what was literally said vs the story you've layered on, a check on the most likely (usually more neutral) intent, whether any action is actually warranted, and a grounded response option — easing the disproportionate sting that rejection-sensitive brains feel.
