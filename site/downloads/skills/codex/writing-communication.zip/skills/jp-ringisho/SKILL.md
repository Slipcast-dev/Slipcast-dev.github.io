---
name: jp-ringisho
description: "Use when asked 稟議書の書き方, write a ringi approval request in Japanese, 稟議書を作って, how to get a purchase or project approved in a Japanese company, or 帮我写一份日本公司的稟議書."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jp-ringisho

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a finished 稟議書 in standard Japanese corporate structure and polite register: purpose, background, proposal, cost and its basis, alternatives compared, expected effect, risks, approval route, and attachments, plus the questions approvers are likely to ask.
