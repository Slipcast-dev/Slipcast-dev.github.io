---
name: review-response
description: "Write the right reply to a customer review — positive, negative, or mixed. Use when asked to respond to a review, reply to a bad/1-star review, handle online reviews, or write review-response templates."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# review-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces tailored, on-brand responses that thank advocates, de-escalate and resolve complaints, and read well to the *future* shopper who's reading them — plus reusable templates.
