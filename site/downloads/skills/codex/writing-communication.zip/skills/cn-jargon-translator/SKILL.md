---
name: cn-jargon-translator
description: "Use when asked 把这段黑话翻译成人话, 这句话到底什么意思, 帮我把周报去黑话, 用大厂黑话改写这段, 互联网黑话词典, 对齐抓手闭环是什么意思, or translate Chinese internet-company jargon (互联网黑话) into plain words and back."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# cn-jargon-translator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a line-by-line translation of 黑话 into plain Chinese with what each sentence actually commits to (who, what, by when), a rewrite at the chosen tone (白话, 得体职场, or 满分大厂味 parody), a 40-plus term glossary with plain meanings, and a 周报去黑话 mode that turns a jargon-heavy weekly report into one a reader can act on.
