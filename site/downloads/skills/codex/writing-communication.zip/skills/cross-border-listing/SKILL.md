---
name: cross-border-listing
description: "Write a product listing for an overseas marketplace or store, localised for the buyer rather than translated from Chinese: title, bullet points, description, search terms and the compliance claims that must or must not appear. Use when asked 帮我写亚马逊 listing, 跨境电商标题, write a product listing for Amazon, TikTok Shop, Shopee, Lazada, Etsy or Shopify, or localise my listing for the US, UK, Germany or Japan."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# cross-border-listing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the listing in the target language within the platform's field limits, a keyword map, a compliance check of every claim, and a list of images the listing needs.
