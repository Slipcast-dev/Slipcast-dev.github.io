---
name: email-template-builder
description: 'Build complete transactional email systems: React Email templates, provider
  integration (Resend, Postmark, SendGrid, AWS SES), preview server, i18n support,
  dark mode, spam optimization, analytics tracking. Use when adding transactional
  email to a new product, migrating between email providers, refactoring legacy email
  templates for accessibility, or adding internationalization to existing templates.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# email-template-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

