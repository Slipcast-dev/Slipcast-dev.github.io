---
name: doc-restructure-live
description: Restructure the user's REAL Google Doc — open it, tighten and reorganise
  it, and return a clean version — not advice on how to edit it. Use when asked to
  clean up this doc, restructure my draft in Drive, make this readable, or tighten
  the doc for review in Cowork. Reads the document via the Google Drive/Docs connector,
  applies a structure-and-concision pass (BLUF, one idea per section, cut the filler),
  and produces a restructured-document artifact plus a change summary — as a new copy,
  never overwriting the original.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# doc-restructure-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

