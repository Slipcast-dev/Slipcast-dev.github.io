---
name: help-center-article
description: "Write a help-center / knowledge-base article that actually resolves the issue and deflects tickets. Use when asked to write a help doc, KB article, FAQ entry, how-to, or support documentation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# help-center-article

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a findable, skimmable article — task-based title, the answer up front, numbered steps, screenshots-to-add markers, troubleshooting, and related links — written so users self-serve instead of contacting support.
