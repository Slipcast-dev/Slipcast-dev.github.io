---
name: huawen-business-writing
description: "Use when asked to write a business email, notice, proposal or WhatsApp message in Chinese for Singapore or Malaysia, 帮我写一封新加坡的中文商务邮件, 马来西亚华文公司通知, or adapt mainland Chinese business writing for 新马 readers."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# huawen-business-writing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces finished 华文 business writing in the register Singapore and Malaysian Chinese readers expect, with local terms, currency, dates and names handled correctly, and an English or Malay version where the reader needs one.
