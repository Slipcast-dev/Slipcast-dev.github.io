---
name: property-offer-letter
description: "Write a buyer's offer cover letter to a seller to strengthen a real-estate bid. Use when asked to write a real-estate offer letter, a buyer's 'love letter' to a seller, an offer cover note, or to make a home offer stand out. Not the legal offer/contract; not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# property-offer-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a warm, genuine letter — who the buyers are, why they love the home, the strength of their offer, and a respectful close — while avoiding fair-housing risk.
