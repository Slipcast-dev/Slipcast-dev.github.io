---
name: should-i-send-this
description: "Gut-check a message before you send it — is it going to land the way you intend, or will you regret it in an hour? Use when asked should I send this, is this message okay to send, check this before I hit send, or will I regret this text/email."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# should-i-send-this

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on how the message will actually land for its recipient, the parts that could be misread or that you're sending from emotion, whether now is the right time to send it at all, and a calmer rewrite if needed — catching the hot, snippy, or oversharing message before it does damage you can't undo.
