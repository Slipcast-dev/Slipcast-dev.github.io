---
name: brag-doc
description: "Keep a running brag document of your accomplishments so reviews and promo cases write themselves. Use when asked to start or update a brag doc, log a win, track accomplishments, or prep evidence for a review/promotion."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# brag-doc

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured, dated accomplishment log — impact-first entries with metrics, scope, and the evidence link — grouped so it drops straight into a self-review or promo packet.
