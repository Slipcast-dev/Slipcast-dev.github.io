---
name: headline-options
description: "Generate and pressure-test headline options across proven formulas. Use when asked for headlines, a title, a subject line, a hook, or to improve a weak headline for a page, post, email, or ad."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# headline-options

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces 10–15 headline options grouped by formula (benefit, how-to, number, question, curiosity, social proof), each scored for clarity and specificity, with the top 3 recommended and why.
