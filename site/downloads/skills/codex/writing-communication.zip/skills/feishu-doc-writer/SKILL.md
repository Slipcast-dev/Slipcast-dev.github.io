---
name: feishu-doc-writer
description: "Write a document for Feishu / Lark Docs (飞书文档) in the shape Feishu readers expect: a summary callout at the top, headed sections that work with the outline panel, task lists with @owners and dates, and tables that survive paste. Use when asked 写一份飞书文档, 帮我整理成飞书文档格式, 飞书方案文档, write this up for Feishu or Lark, or turn my notes into a Feishu doc."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# feishu-doc-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces paste-ready Markdown that Feishu converts on import, a 高亮块 summary, an owner-and-date task list, and a short message to share the doc in a Feishu group.
