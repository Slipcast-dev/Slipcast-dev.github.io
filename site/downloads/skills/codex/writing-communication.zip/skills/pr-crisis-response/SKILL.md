---
name: pr-crisis-response
description: "Build a crisis communications plan to respond fast and credibly when something goes wrong. Use when asked to handle a PR crisis, draft a crisis comms plan, respond to a public backlash/scandal/incident, or prepare holding statements."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pr-crisis-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a crisis comms plan — situation assessment, stakeholder map, a message house, channel-by-channel statements, a holding statement, an internal brief, and a follow-up timeline.
