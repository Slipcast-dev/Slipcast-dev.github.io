---
name: parent-communication
description: "Draft clear, warm, professional messages to parents or guardians — progress notes, concerns, positive news, behaviour issues, or meeting requests. Use when asked to email a parent, write home about a student, raise a concern with a guardian, or share an update."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# parent-communication

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ready-to-send message that is specific, partnership-oriented, and constructive — never accusatory — with the tone matched to the situation.
