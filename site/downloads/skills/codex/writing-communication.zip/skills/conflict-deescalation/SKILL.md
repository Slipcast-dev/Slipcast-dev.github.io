---
name: conflict-deescalation
description: "Calm a heated conflict — in person or in writing — before it does damage, by lowering the temperature instead of winning the point. Use when asked help me de-escalate this, this argument is getting heated, calm this situation down, or how do I respond without making it worse."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# conflict-deescalation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on what's actually driving the heat (often an unmet need under the surface argument), the de-escalation moves (acknowledge, slow down, find the shared ground), what to say and what to avoid, and how to steer toward resolution once the temperature drops — because you can't solve anything while everyone's activated.
