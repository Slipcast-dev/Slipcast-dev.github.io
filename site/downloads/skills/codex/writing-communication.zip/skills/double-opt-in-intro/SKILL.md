---
name: double-opt-in-intro
description: "Make introductions that respect both sides — the double-opt-in flow (ask each party privately before connecting them), the forwardable blurb that makes saying yes easy, and the connecting email that sets both up to succeed. Use when asked introduce me to someone, can you connect us, write an intro email, or someone asked me for an intro."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# double-opt-in-intro

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the opt-in asks for both sides, the forwardable blurb, the intro email itself, and the graceful decline path.
