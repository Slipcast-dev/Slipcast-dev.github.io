---
name: treatment-plan-presentation
description: "Present a dental treatment plan the patient actually understands and accepts — sequenced by clinical priority, costed with their coverage applied, and explained in the order that answers what-is-wrong before what-it-costs. Use when asked to present a treatment plan, improve case acceptance, explain treatment to a patient, or handle a patient who says they want to think about it. Clinical decisions remain the treating clinician's; this shapes the conversation, not the diagnosis."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# treatment-plan-presentation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the phased plan, the plain-language explanation per phase, the cost and coverage breakdown, the consequences-of-delay framing, and responses to the four common objections.
