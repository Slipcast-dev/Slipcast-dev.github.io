---
name: review-comments-resolver
description: "Resolve a document's forty review comments systematically — triage by type (accept, push back, conflict, out-of-scope), batch the mechanical fixes, draft the disagreement replies, and reconcile reviewers who contradict each other. Use when asked work through these review comments, two reviewers want opposite things, close out the feedback on this doc, or which comments do I actually have to take."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# review-comments-resolver

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the comment triage, the batched fixes, the push-back replies, the conflict reconciliations, and the closure sweep.
