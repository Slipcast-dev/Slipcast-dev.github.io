---
name: deck-from-doc
description: Turn the user's REAL doc into a slide deck — open the source, structure
  the narrative, and build the actual .pptx — not slide-writing tips. Use when asked
  to make a deck from this doc, turn my brief into slides, build the presentation
  from my Drive doc, or deckify this in Cowork. Reads the document via the Google
  Drive/Docs connector, maps it to a one-idea-per-slide narrative, and produces a
  real presentation artifact (.pptx) with speaker notes plus a slide-by-slide outline.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# deck-from-doc

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

