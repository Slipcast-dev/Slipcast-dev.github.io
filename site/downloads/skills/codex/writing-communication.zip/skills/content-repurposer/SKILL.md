---
name: content-repurposer
description: "Turn one piece of content into a full multi-platform pack — X/Twitter thread, LinkedIn post, newsletter section, Instagram carousel, and a short-form video script — each rewritten natively for its platform, not copy-pasted. Use when asked to repurpose content, atomize a blog post or video, turn one idea into many posts, or get more mileage from a piece."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# content-repurposer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready-to-post drafts per platform with hooks, formatting, and CTAs tuned to each.
