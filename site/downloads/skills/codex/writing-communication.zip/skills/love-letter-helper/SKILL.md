---
name: love-letter-helper
description: "Help you write a heartfelt letter to someone you love — for an anniversary, a hard time, a birthday, or just because — that sounds like you and says what you actually mean. Use when asked to help me write a love letter, say how I feel to my partner, a heartfelt note for [occasion], or I'm not good with words."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# love-letter-helper

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a letter built from your real feelings and specifics, a structure that carries emotion without cheese, the right tone for your relationship and occasion, and phrasing in your own voice — with prompts to draw out what you want to say if you're stuck.
