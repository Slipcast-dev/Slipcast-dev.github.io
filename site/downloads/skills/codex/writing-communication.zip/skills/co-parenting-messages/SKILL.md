---
name: co-parenting-messages
description: "Write calm, businesslike co-parenting messages that keep the focus on the kids and stay out of the old conflict — for scheduling, expenses, decisions, and hard topics. Use when asked to write a message to my co-parent, respond to my ex about the kids, co-parenting communication help, or how to reply without a fight. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# co-parenting-messages

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a message drafted in a neutral, child-centered tone (the 'BIFF'-style brief/informative/friendly/firm approach), the bait removed, a clear ask or answer, and a note on documentation — steering away from anything that escalates.
