---
name: form-explainer
description: "Explain an official form field by field (tax, benefits, immigration, employment, school, health, vehicle or court forms) from a photo, PDF, pasted text or just its name and number: what it is for, what each field means and what to put, the documents needed, the deadline, and where to send it. Use when someone says 'what is this form', 'help me understand form P45 / W-4 / Form 16', 'what do I write in this box', or 'I got this form in the post'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# form-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-line purpose, a field-by-field guide, a documents checklist, common mistakes, and what happens next.
