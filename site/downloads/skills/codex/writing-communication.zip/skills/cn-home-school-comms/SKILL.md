---
name: cn-home-school-comms
description: "Use when asked 怎么给老师发消息, 跟班主任沟通, 孩子在学校被欺负怎么跟老师说, 对老师的做法有意见, 请假怎么写, 家长群里怎么说话, or write a message from a parent to a teacher in China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-home-school-comms

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ready-to-send WeChat or note message in Chinese, polite and specific, for the situation (asking, leave, a concern, a disagreement, bullying, thanks), a calmer version if the parent is upset, what to say if the teacher calls back, the escalation path if it is not resolved, and 家长群 etiquette.
