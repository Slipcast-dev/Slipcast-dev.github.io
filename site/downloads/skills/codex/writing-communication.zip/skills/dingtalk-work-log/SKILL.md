---
name: dingtalk-work-log
description: "Write a DingTalk work log (钉钉日志): the daily report (日报), weekly report (周报) or monthly report (月报) in the fields DingTalk's built-in log templates use, so it can be filled in directly. Use when asked 帮我写钉钉日报, 钉钉日志怎么写, 今日完成工作, 写日报, fill in my DingTalk daily report, or turn today's notes into a 日报."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dingtalk-work-log

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the log field by field (今日完成工作, 未完成工作, 需协调工作, 备注 or the weekly and monthly equivalents), each short enough for the mobile form, plus a one-line version for the team group.
