# Тексты, документы и коммуникация / Writing, Documents and Communication · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
