---
name: regulatory-affairs-head
description: Senior Regulatory Affairs Manager for HealthTech and MedTech companies.
  Prepares FDA 510(k), De Novo, and PMA submission packages; analyzes regulatory pathways
  for new medical devices; drafts responses to FDA deficiency letters and Notified
  Body queries; develops CE marking technical documentation under EU MDR 2017/745;
  coordinates multi-market approval strategies across FDA, EU, Health Canada, PMDA,
  and NMPA; and maintains regulatory intelligence on evolving standards. Use when
  users need to plan or execute FDA submissions, navigate 510(k) or PMA approval processes,
  achieve CE marking, prepare pre-submission meeting materials, write regulatory strategy
  documents, respond to agency queries, or manage compliance documentation for medical
  device market access.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# regulatory-affairs-head

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

