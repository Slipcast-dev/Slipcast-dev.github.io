---
name: gdpr-audit-prep
description: /compliance-os:gdpr-audit-prep [scope] — GDPR audit 6-question Article-cited
  forcing interrogation. Use before annual internal GDPR review, post-breach internal
  audit, DPA investigation readiness, or acquisition due diligence.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# gdpr-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
