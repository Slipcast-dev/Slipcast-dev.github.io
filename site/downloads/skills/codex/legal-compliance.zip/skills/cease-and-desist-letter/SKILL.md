---
name: cease-and-desist-letter
description: "Draft a firm, professional cease-and-desist letter to stop harassment, defamation, IP misuse, or unwanted contact — clear about what must stop and what happens if it doesn't. Use when asked to write a cease and desist, make someone stop [harassing/using my work/defaming me], or send a formal letter to stop. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cease-and-desist-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured letter stating the conduct, why it's wrongful, the specific demand and deadline, and the consequence, plus guidance on delivery and records — flagging when the matter needs a real lawyer.
