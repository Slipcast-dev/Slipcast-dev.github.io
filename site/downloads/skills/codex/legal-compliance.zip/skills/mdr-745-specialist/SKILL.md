---
name: mdr-745-specialist
description: EU MDR 2017/745 compliance specialist for medical device classification,
  technical documentation, clinical evidence, and post-market surveillance. Covers
  Annex VIII classification rules, Annex II/III technical files, Annex XIV clinical
  evaluation, Art. 86 PSUR schedules, and EUDAMED integration. Use when classifying
  a medical device under MDR, building or gap-checking a technical file, planning
  clinical evaluation or PMS/PSUR cadence, or preparing for notified body review (e.g.,
  'what class is my device under MDR', 'review my PSUR schedule').
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# mdr-745-specialist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

