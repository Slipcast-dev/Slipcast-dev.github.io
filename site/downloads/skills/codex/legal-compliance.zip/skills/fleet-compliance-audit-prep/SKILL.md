---
name: fleet-compliance-audit-prep
description: "Prepare a transport operation for a regulatory audit — the records an auditor asks for in order, the findings your own file will produce, and the gaps closed before the visit rather than during it. Use when asked to prepare for a DOT or FMCSA audit, a traffic commissioner or operator licence review, a fleet compliance inspection, or to run an internal transport compliance audit. Requirements are jurisdiction-specific and must be verified against the current regulation and your licence conditions."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# fleet-compliance-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the records inventory, the self-audit findings by severity, the gap-closure plan, the audit-day logistics, and the evidence pack.
