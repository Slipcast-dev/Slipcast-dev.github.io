---
name: chargeback-dispute-response
description: "Win a chargeback dispute — read the reason code, assemble the evidence packet, and write the rebuttal that actually persuades the bank. Use when asked to fight a chargeback, respond to a payment dispute, write a chargeback rebuttal, or contest a customer chargeback. For merchants."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# chargeback-dispute-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the reason-code decode, the required-evidence checklist for that code, the structured rebuttal letter, and an honest read on whether this one is winnable — so you fight the right disputes and concede the rest.
