---
name: capa-officer
description: CAPA system management for medical device QMS. Covers root cause analysis,
  corrective action planning, effectiveness verification, and CAPA metrics. Use when
  running CAPA investigations, 5-Why analysis, fishbone diagrams, root cause determination,
  corrective action tracking, effectiveness verification, or CAPA program optimization.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# capa-officer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

