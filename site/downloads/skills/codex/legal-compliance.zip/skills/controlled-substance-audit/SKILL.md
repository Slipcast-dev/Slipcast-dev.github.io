---
name: controlled-substance-audit
description: "Reconcile controlled-substance records and prepare for an inspection — the count against the register, the discrepancy investigation, the documentation an inspector asks for, and the reporting obligations a shortfall triggers. Use when asked to reconcile controlled drugs, prepare for a DEA or controlled-drug inspection, investigate a discrepancy or suspected diversion, or audit the CD register. A process framework only; reporting thresholds, timelines and obligations are set by law in your jurisdiction and must be verified there."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# controlled-substance-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the reconciliation, the discrepancy investigation record, the inspection-readiness checklist, and the escalation and reporting decision tree.
