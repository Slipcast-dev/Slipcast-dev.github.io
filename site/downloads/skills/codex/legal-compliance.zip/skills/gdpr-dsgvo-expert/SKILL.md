---
name: gdpr-dsgvo-expert
description: GDPR and German DSGVO compliance automation. Scans codebases for privacy
  risks, generates DPIA documentation, tracks data subject rights requests with Art.
  12(3) one-month deadlines. Use when running GDPR compliance assessments, privacy
  audits, data protection planning, DPIA generation, or data subject rights (DSAR)
  management (e.g., 'check this service for GDPR risks', 'track an access request
  deadline'). Final compliance determinations route to the DPO or legal counsel.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# gdpr-dsgvo-expert

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

