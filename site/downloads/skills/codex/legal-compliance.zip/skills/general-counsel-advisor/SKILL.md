---
name: general-counsel-advisor
description: 'General Counsel advisory for startups: contract review (MSA, SaaS, NDA,
  DPA, employment), IP strategy, term sheet decoding, and regulatory landscape mapping.
  Use when reviewing any contract or term sheet, deciding when to engage outside counsel,
  defining IP strategy, evaluating regulatory exposure (HIPAA, GDPR, FDA, fintech),
  or when user mentions general counsel, GC, legal review, contract risk, term sheet,
  IP assignment, or regulatory exposure. NOT a substitute for licensed counsel — surfaces
  questions to bring to qualified attorneys.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# general-counsel-advisor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

