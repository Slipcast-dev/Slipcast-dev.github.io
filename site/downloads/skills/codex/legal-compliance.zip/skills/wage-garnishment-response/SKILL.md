---
name: wage-garnishment-response
description: "Respond fast when your wages are being garnished or about to be — the deadlines, the exemptions that can reduce or stop it, and the steps that protect your paycheck. Use when asked they're garnishing my wages, how do I stop wage garnishment, I got a garnishment notice, or can they take my whole paycheck. Not legal advice; centers fast legal-aid help."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wage-garnishment-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the urgent-deadline map, the exemptions that may reduce or stop it (income caps, protected funds like benefits, head-of-household), how to file a claim of exemption, options to resolve the underlying debt, and where to get legal aid immediately.
