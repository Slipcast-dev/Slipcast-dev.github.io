---
name: hazard-risk-map
description: "Figure out which disasters and emergencies your specific location actually faces — and the concrete prep each one demands — so your readiness targets real risks instead of generic ones. Use when someone says 'what disasters should I prepare for', 'am I in a flood/wildfire/quake zone', 'what emergencies are likely where I live', or 'where do I start with preparedness'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hazard-risk-map

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ranked local-hazard list, the specific prep each demands, warning-signal and alert setup, and where to verify official risk data for your area.
