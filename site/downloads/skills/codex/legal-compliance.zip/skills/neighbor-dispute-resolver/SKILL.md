---
name: neighbor-dispute-resolver
description: "Handle a neighbor conflict — noise, boundaries, parking, shared costs, pets — with a measured approach that de-escalates first and keeps a paper trail if it has to go formal. Use when asked to deal with a neighbor dispute, my neighbor is [too loud / over the boundary / blocking me], how do I talk to my neighbor about, or write a letter to my neighbor."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# neighbor-dispute-resolver

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the situation, a calm first conversation or friendly note, a firmer written follow-up if that fails, the documentation habit for escalation, and the right next step (mediation / landlord / HOA / council) — steering away from making it worse.
