---
name: cn-data-export-assessment
description: "Use when asked 数据出境要申报吗, 数据出境安全评估还是标准合同, 个人信息出境标准合同怎么备案, 我们把数据传到海外总部合规吗, or decide how to transfer data out of mainland China lawfully."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-data-export-assessment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a data map of what leaves China, the route that applies (an exemption, the personal information export standard contract, certification, or a CAC security assessment) with the thresholds to confirm, the filing steps, and the documents to prepare, including the personal information protection impact assessment.
