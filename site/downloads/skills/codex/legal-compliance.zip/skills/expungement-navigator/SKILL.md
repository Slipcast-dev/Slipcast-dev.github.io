---
name: expungement-navigator
description: "Figure out whether your record can be sealed or expunged, and map the steps to do it — eligibility, waiting periods, forms, and where to get help. Use when asked can I get my record expunged, how do I seal my criminal record, clear my background, or am I eligible for expungement. Not legal advice; expungement law is highly jurisdiction-specific and this points you to the right help."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# expungement-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-language read on likely eligibility (offense type, dispositions, waiting periods), the document and step sequence to petition, the costs and fee-waiver options, the realistic timeline, and where to get free or low-cost legal help — so a record that can be cleared actually gets cleared.
