---
name: jury-duty-guide
description: "Understand a jury-duty summons and handle it right — what's required, whether you can defer or be excused, and what to expect on the day. Use when asked what do I do about jury duty, can I get out of jury duty, jury summons help, or how does jury service work. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jury-duty-guide

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-English read of the summons and obligations, the legitimate deferral/excusal/hardship options and how to request them, what to expect at selection and service, practical prep (work, pay, logistics), and a clear warning that ignoring a summons has consequences.
