---
name: voting-navigator
description: "Work out how to actually vote in a specific election — am I registered, what's the deadline, how do I vote (in person / mail / early), what ID do I need, and what's on my ballot — with everything routed to the official source to verify. Use when someone says 'how do I vote', 'am I registered', 'what's the deadline to register', 'help me vote by mail', or 'what's on my ballot'. Non-partisan; procedure only, never who to vote for."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# voting-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a personal voting plan with dates, steps, and the official links to confirm each one.
