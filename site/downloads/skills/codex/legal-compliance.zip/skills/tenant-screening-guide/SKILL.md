---
name: tenant-screening-guide
description: "Design a fair, consistent tenant screening process for a rental. Use when asked how to screen tenants, set rental criteria, evaluate rental applicants, or build a tenant screening process. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tenant-screening-guide

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a screening framework — written objective criteria, the application & checks, a consistent evaluation method, and applicant communication — built to be fair and Fair-Housing-compliant.
