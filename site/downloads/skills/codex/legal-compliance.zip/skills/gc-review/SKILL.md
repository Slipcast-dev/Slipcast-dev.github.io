---
name: gc-review
description: /c-level-agents:gc-review [plan] — General Counsel interrogation of contracts,
  IP, regulatory, term sheets, and employment-law surface. Use when reviewing a term
  sheet before signing, redlining a customer MSA, or checking IP assignment and regulatory
  exposure on a new product.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# gc-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
