---
name: fda-qsr-audit-prep
description: /compliance-os:fda-qsr-audit-prep [scope] — FDA 21 CFR 820 (QSR / QMSR)
  audit 6-question forcing interrogation. Post-Feb 2026 substantially harmonized with
  ISO 13485. Use before annual internal QSR audit, pre-FDA-inspection readiness, or
  Form 483 response.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# fda-qsr-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
