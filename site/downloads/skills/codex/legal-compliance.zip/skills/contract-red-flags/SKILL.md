---
name: contract-red-flags
description: "Scan a contract you're about to sign in plain language — surface the clauses that could bite you, what they mean, and what to question or renegotiate. Use when asked to check this contract before I sign, what am I agreeing to, are there red flags in this agreement, or explain this contract's risky bits. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# contract-red-flags

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-English flag list of the risky/unusual clauses (auto-renewal, lock-in, liability, IP, termination, fees), what each means for you, questions to ask, and suggested changes — flagging when it's important enough for a lawyer.
