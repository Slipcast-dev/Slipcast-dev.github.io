---
name: estate-planning-kit
description: "Get your affairs in order before you need to — a will/beneficiary/healthcare-directive checklist and the 'what my family needs to find' document, in the right order. Use when asked to help with estate planning, make a will checklist, get my affairs in order, or prepare what my family needs if something happens to me. Complements the estate/after-death pack."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# estate-planning-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the estate-planning checklist ranked by priority, the document-locator sheet, the key decisions to make, and the professional-help flags — for the living, not the executor.
