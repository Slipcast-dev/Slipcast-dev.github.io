---
name: dpa-review
description: "Read a Data Processing Agreement before you sign it — sub-processors, transfer mechanism, breach-notice window, deletion, audit rights — in plain language with 🔴🟡🟢 risk. Use when asked to review a DPA, check a data processing agreement, is this DPA safe to sign, or what am I agreeing to on data."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dpa-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the plain-English summary, the risk-ranked findings, the missing-clause checklist, and the questions to send back before signature.
