---
name: home-contractor-quote-decoder
description: "Decode a home renovation or repair quote — allowances that aren't prices, exclusions that become change orders, payment schedules that shift risk, and what a comparable-bids check should cover. Use when someone asks 'is this contractor quote fair', 'decode this renovation bid', 'what should be in a contractor contract', or 'why do these three bids differ so much'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# home-contractor-quote-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a section-by-section decode, the allowance and exclusion audit, payment-schedule risk analysis, and the questions that make bids comparable.
