---
name: hours-of-service-check
description: "Audit driver hours records for the violations that actually get cited — the falsification patterns, the edit trails, and the scheduling that makes compliance impossible — and fix the causes rather than the logs. Use when asked to audit hours of service, review driver logs, check tachograph or ELD records, prepare for an hours compliance review, or reduce hours violations. Rules and limits are jurisdiction-specific and must be verified against current regulation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hours-of-service-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the violation summary by type and severity, the falsification-pattern review, the scheduling root-cause analysis, the driver-level and systemic actions, and the audit trail.
