---
name: flight-delay-compensation
description: "Work out whether a delayed, cancelled, or overbooked flight likely owes you compensation — and draft the claim with the right rule cited. Use when asked about flight delay compensation, my flight was cancelled/delayed/overbooked, am I owed money for this flight, or how do I claim EU261."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# flight-delay-compensation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an eligibility read against the likely-applicable regime (EU261/UK261/US DOT-style and airline duty-of-care), the amount band, the claim letter with flight details, and the evidence to attach — flagging what to verify because rules and thresholds change.
