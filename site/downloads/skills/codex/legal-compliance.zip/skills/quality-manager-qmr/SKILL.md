---
name: quality-manager-qmr
description: Senior Quality Manager Responsible Person (QMR) for HealthTech and MedTech
  companies. Provides quality system governance, management review leadership, regulatory
  compliance oversight, and quality performance monitoring per ISO 13485 Clause 5.5.2.
  Use when leading management reviews, setting quality policy and objectives, monitoring
  quality KPIs and cost of quality, or exercising QMR governance and regulatory oversight
  responsibilities.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# quality-manager-qmr

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

