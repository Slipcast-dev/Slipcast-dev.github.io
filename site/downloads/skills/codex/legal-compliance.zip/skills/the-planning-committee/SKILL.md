---
name: the-planning-committee
description: "Simulate defending your planning application before the committee that decides it — the neighbour objections read into the record, the character-of-the-area catch-all, the parking pile-on, the councillor with a pet issue — run against your actual scheme, inside a three-minute speaking slot. Use when asked to prepare for a planning committee, my application goes to committee, rehearse my three minutes, or how do I answer the objectors. Pairs with planning-application-statement. Not planning or legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# the-planning-committee

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the hearing transcript with member reactions, the objection-by-objection answer map grounded in material considerations, and the three-minute statement rebuilt.
