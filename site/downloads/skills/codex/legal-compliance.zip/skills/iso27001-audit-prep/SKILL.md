---
name: iso27001-audit-prep
description: /compliance-os:iso27001-audit-prep [scope] — ISO 27001 ISMS audit readiness
  6-question forcing interrogation. Use before annual Clause 9.2 internal audit, surveillance
  audit prep, or stage 1 certification readiness.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# iso27001-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
