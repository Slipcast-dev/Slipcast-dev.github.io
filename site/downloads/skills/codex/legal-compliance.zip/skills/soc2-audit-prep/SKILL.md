---
name: soc2-audit-prep
description: /compliance-os:soc2-audit-prep [scope] — SOC 2 Type II readiness 6-question
  forcing interrogation. Observation-period focused. Use before Type II observation
  begins, mid-period checkpoint, or pre-field-test month-10 readiness.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# soc2-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
