---
name: tenant-rights-explainer
description: "Understand your rights as a renter in a specific situation — repairs ignored, a rent increase, an eviction notice, deposit disputes, or entry without notice — and what to do next. Use when asked what are my tenant rights, my landlord won't fix [X], is this eviction/rent increase legal, or can my landlord [do something]."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tenant-rights-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-English read of the likely rights at play, the practical next steps (in writing, on the record), the evidence to keep, and where to get authoritative help — flagging strongly that tenancy law is local and this isn't legal advice.
