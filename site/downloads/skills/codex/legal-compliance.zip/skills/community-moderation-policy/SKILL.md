---
name: community-moderation-policy
description: "Write a fair, enforceable community moderation policy. Use when standing up or overhauling moderation for a forum, Discord, Slack, subreddit, or any user community. Governs member conduct in a user community — distinct from [[community-management-playbook]], which manages a brand's own social-media channels (comments, DMs, tone, response templates)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# community-moderation-policy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clear code of conduct with examples, a graduated enforcement ladder tied to specific triggers, an appeals process, moderator guidelines, and the handling for the severe cases (threats, doxxing, brigading) that need immediate action.
