---
name: contractor-dispute
description: "Handle a dispute with a contractor — unfinished work, poor quality, overcharging, or a no-show — with a path that protects your money and your options. Use when asked to deal with a contractor dispute, my contractor did bad work / won't finish / overcharged, or how to get a builder to fix their work."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# contractor-dispute

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on your position (contract, payments, evidence), a firm-but-professional communication and demand path, documentation and payment-leverage guidance, and escalation options (mediation, licensing board, chargeback, small claims) — flagging that it's not legal advice.
