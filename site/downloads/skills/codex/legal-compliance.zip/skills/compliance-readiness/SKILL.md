---
name: compliance-readiness
description: /compliance-os:compliance-readiness [program] — Multi-framework compliance
  officer 6-question forcing interrogation of any compliance program. Use before starting
  a new framework, planning the annual audit calendar, or preparing for certification
  stage 1.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# compliance-readiness

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
