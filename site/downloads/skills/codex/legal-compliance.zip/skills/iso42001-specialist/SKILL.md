---
name: iso42001-specialist
description: 'ISO/IEC 42001:2023 AI Management System (AIMS) specialist for compliance
  teams running internal audits. Three decisions: (1) Where are the gaps against Clauses
  4-10 and what do we close first? (2) What goes in the AI risk register and which
  Annex A controls treat each risk? (3) What''s the 12-month internal audit plan that
  satisfies Clause 9.2? Use when preparing for certification, scoping internal audit
  cycles, or onboarding AI systems into an existing ISMS (27001) / QMS (13485) program.
  NOT an executive AI strategy skill (see chief-ai-officer-advisor). NOT EU AI Act
  compliance (see compliance-team-eu-ai-act).'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# iso42001-specialist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

