---
name: lemon-law-check
description: "Figure out whether your problem car might qualify for a refund or replacement under lemon law or warranty — and build the paper trail to claim it. Use when asked is my car a lemon, my new car keeps breaking, lemon law help, or can I return a defective car. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# lemon-law-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plausibility read against typical lemon-law criteria (repeated same defect, repair attempts, time out of service, warranty window), the records to gather, the manufacturer-claim and escalation steps, and a strong flag that lemon laws are jurisdiction-specific.
