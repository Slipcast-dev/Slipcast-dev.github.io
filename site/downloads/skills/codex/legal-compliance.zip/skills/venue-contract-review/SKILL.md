---
name: venue-contract-review
description: "Read a venue contract for the clauses that actually cost money — the minimum spend, the cancellation ladder, the attrition clause, and everything the hire fee does not include. Use when asked to review a venue contract, check a venue agreement before signing, negotiate venue terms, or understand a cancellation or minimum-spend clause. Not legal advice; have a lawyer review before signing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# venue-contract-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the commercial summary, the flagged clauses ranked by exposure, the what-is-not-included list, the negotiation asks in priority order, and the questions to put in writing.
