---
name: class-action-claim-finder
description: "Work out whether you're eligible for a class-action settlement or refund program — and actually file the claim before the deadline. Use when asked am I owed money from a settlement, is there a class action for [product/company], how do I claim a settlement, or did I qualify for that refund. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# class-action-claim-finder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a way to check for relevant settlements, an eligibility read against the class definition, the proof you need and how to file, deadline tracking, and honest expectations on payout size — plus how to avoid fake-settlement scams.
