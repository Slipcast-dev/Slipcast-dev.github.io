---
name: jury-duty-navigator
description: "Handle a jury summons calmly — confirm it's real, understand what's actually required, request a deferral or excusal the right way if you genuinely need one, arrange work and pay, and know what to expect at selection and on the day. Use when someone says I got a jury summons, can I get out of jury duty, how do I defer jury service, or what happens at jury duty. Not legal advice; routes to the court for anything binding and never coaches dodging a legal obligation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jury-duty-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a response plan, a deferral/excusal request if warranted, and a what-to-expect brief, with a clear warning that ignoring a summons has consequences.
