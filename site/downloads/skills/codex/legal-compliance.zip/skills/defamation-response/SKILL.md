---
name: defamation-response
description: "Respond to false, damaging statements about you or your business — decide what actually counts as defamation, preserve evidence, and choose the right response from correction to takedown to legal action. Use when asked someone posted lies about me, respond to a false review/statement, is this defamation, or protect my reputation online. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# defamation-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on whether it likely crosses from opinion into actionable falsehood, evidence-preservation steps, a tiered response (platform report, correction/retraction request, cease-and-desist, legal), and a caution against reactions that make it worse.
