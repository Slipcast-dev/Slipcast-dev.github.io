---
name: care-home-contract-decoder
description: "Decode a care-home contract before a parent moves in — the fee-escalation clause with no cap, the needs-can-no-longer-be-met eviction trigger, the guarantor line that quietly makes you personally liable, and the after-death charges nobody mentions on the tour. Use when asked to review a care-home or nursing-home contract, what does this admission agreement mean, can they raise the fees, or can they make my parent leave. Pairs with long-term-care-options for choosing the home; this is for the contract. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# care-home-contract-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clause-by-clause decode ranked by financial and eviction risk, the questions to put in writing before signing, and the negotiate-or-verify list.
