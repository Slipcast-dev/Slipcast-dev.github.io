---
name: clause-explainer
description: "Explain a contract clause in plain English — what it means, who it favours, the realistic risk, and what to negotiate. Use when asked what a clause means, to decode legal language, explain a term in a contract, or assess whether a provision is standard or aggressive. Not legal advice; confirm with counsel."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# clause-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-language translation, a who-does-this-favour read, a risk rating, and concrete redline suggestions.
