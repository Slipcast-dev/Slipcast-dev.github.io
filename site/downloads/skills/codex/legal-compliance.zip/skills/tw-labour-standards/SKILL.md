---
name: tw-labour-standards
description: "Use when asked 加班費怎麼算, 特休有幾天, 被資遣可以拿多少, 預告期間是多久, 勞退 6% 雇主有沒有提繳, 這樣合法嗎 勞基法, or check work terms against Taiwan's Labor Standards Act (勞動基準法)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tw-labour-standards

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a check of the person's situation against the Act (wages and the minimum wage, working hours and overtime pay, annual leave, notice and severance under the new pension system, pension contributions), worked calculations from their own figures, what to ask the employer, and where to complain (地方勞工局 and 1955), each figure marked to confirm.
