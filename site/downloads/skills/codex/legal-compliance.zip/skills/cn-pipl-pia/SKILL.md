---
name: cn-pipl-pia
description: "Use when asked 个人信息保护影响评估怎么做, 写一份 PIA, 处理敏感个人信息要评估吗, 自动化决策评估, PIPL 第五十五条, or assess a processing activity under China's Personal Information Protection Law."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-pipl-pia

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a personal information protection impact assessment (个人信息保护影响评估) covering the PIPL Article 55 triggers, the Article 56 questions (lawful, legitimate and necessary; impact and risk; adequacy of protection), a risk register with mitigations and owners, and a record kept for at least three years.
