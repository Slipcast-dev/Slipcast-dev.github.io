---
name: name-change-navigator
description: "Get through the 40-institution slog of changing your name — after marriage, divorce, transition, or just because — in the right order, so one update doesn't block the next, with nothing important forgotten. Use when someone says 'I changed my name and don't know where to start', 'update my name everywhere', 'name change checklist', or is planning any legal name change. Not legal advice — the logistics; the legal deed/court step is flagged, not performed."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# name-change-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an ordered update checklist (what unlocks what), a personalized institution list, and templates.
