---
name: qms-audit-expert
description: ISO 13485 internal audit expertise for medical device QMS. Covers audit
  planning, execution, nonconformity classification, and CAPA verification. Use when
  planning internal audits, executing audits, classifying findings, preparing for
  external audits, or managing an audit program.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# qms-audit-expert

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

