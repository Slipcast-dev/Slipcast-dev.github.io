---
name: complaint-letter
description: "Write a firm, effective complaint letter that gets a resolution. Use when asked to write a complaint letter, complain to a company about a product/service, escalate poor service, or demand a refund/replacement."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# complaint-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured complaint — the facts, the impact, the specific resolution you want, and a deadline — in a firm, professional tone that's hard to ignore and easy to act on.
