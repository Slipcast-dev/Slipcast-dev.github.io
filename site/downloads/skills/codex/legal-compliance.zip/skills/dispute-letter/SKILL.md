---
name: dispute-letter
description: "Write a letter to dispute an incorrect charge, bill, or record. Use when asked to dispute a credit-card charge, contest a bill or invoice, challenge a credit-report error, or formally dispute a fee."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dispute-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clear dispute letter — what's being disputed, why it's wrong, the evidence, and the correction requested — in the firm, paper-trail tone these situations need.
