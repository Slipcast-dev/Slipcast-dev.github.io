---
name: immigration-document-checklist
description: "Organise the document pile for a visa, work-permit, or residency application — what to gather, in what order, and the common rejection triggers to avoid. Use when asked to help with a visa application, build an immigration document checklist, prepare paperwork for a work permit or green card, or organise what an application needs. Organises the paperwork; complements the visa-interview simulator."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# immigration-document-checklist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the categorised document checklist, the gather-in-this-order plan, the common-mistake/rejection-trigger list, and the professional-help flags.
