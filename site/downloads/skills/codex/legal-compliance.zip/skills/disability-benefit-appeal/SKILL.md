---
name: disability-benefit-appeal
description: "Appeal a denied disability benefit (SSDI/SSI, PIP, DLA, ESA and similar) — decode the denial reason, build the evidence-backed case that answers it, hit the deadline, and prepare for the hearing. Use when someone says 'my disability benefit was denied', 'appeal my PIP/SSDI decision', 'they said I don't qualify', or 'how do I challenge a benefits decision'. Not legal advice — it organizes YOUR case and routes to free specialist advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# disability-benefit-appeal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a decoded denial, an appeal strategy mapped to the criteria, an evidence checklist, and a statement draft.
