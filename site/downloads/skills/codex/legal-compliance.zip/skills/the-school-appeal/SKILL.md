---
name: the-school-appeal
description: "Simulate a school-place appeal panel before you face the real one — the two questions the panel is actually deciding, the probe that separates grounds from feelings, the prejudice balance your case must tip — run against your actual reasons, with a debrief on which answers built a case and which only expressed one. Use when asked to prepare a school appeal, we did not get our school place, rehearse the appeal hearing, or what does the panel ask. Jurisdiction-varying; verify your local process. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# the-school-appeal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the hearing transcript with the panel's deliberation notes, your case restructured into grounds with evidence, and the questions to put to the admission authority.
