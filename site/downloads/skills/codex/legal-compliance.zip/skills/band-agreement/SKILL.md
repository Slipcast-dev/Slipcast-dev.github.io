---
name: band-agreement
description: "Write the band agreement before the money or the breakup arrives — who owns the songs, how money splits (writing vs performing distinguished), who owns the name, what happens when someone quits, and the decision rules for offers — decided while everyone still shares a van. Use when a band asks 'how should we split money', 'who owns our songs', 'our drummer quit, what happens', or is about to record/release/sign anything. Not legal advice — it's the conversation that makes the lawyer cheap later."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# band-agreement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-language band agreement and the meeting script to agree it.
