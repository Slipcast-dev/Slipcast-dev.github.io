---
name: licence-notice-auditor
description: "Use when asked to check a project's licences, audit dependencies before open-sourcing or selling, write a NOTICE file, find licence conflicts, or check whether bundled fonts, images or datasets can be shipped."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# licence-notice-auditor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an inventory of code, data and media dependencies with their licences, flags for conflicts and unclear ownership, and a draft NOTICE.md, with a clear statement that the output is not legal advice.
