---
name: wedding-vendor-contract-decoder
description: "Decode a wedding vendor contract — venue, photographer, caterer, band — before signing: deposits and their refundability, cancellation and postponement terms, the substitute-performer and force-majeure clauses, and overtime math. Use when someone asks review this venue contract, is this photographer contract normal, what if we have to postpone, or decode this caterer agreement."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wedding-vendor-contract-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clause decode with 🔴🟡🟢 severity, the cancellation-cost timeline, the questions to ask this vendor, and what's actually negotiable.
