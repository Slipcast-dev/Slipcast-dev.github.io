---
name: pipl-gdpr-crosswalk
description: "Compare China's Personal Information Protection Law (PIPL) with the EU GDPR for a specific data flow, and produce the gap list and cross-border transfer path for a company operating in both. Use when asked PIPL vs GDPR, 个人信息保护法和 GDPR 的区别, how do we transfer personal data out of China, our app serves users in China and Europe, or 数据出境 compliance. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pipl-gdpr-crosswalk

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a requirement crosswalk for the described processing, the transfer mechanism that likely applies in each direction, a prioritised gap list, and the questions to take to counsel.
