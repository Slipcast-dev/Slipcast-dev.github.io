---
name: iso13485-audit-prep
description: /compliance-os:iso13485-audit-prep [scope] — ISO 13485 QMS audit 6-question
  forcing interrogation. Design controls + CAPA + post-market focused. Use before
  Clause 8.2.4 internal audit, MDR / FDA QSR alignment review, or product-launch DHF
  closure audit.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# iso13485-audit-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
