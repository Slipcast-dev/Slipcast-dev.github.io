---
name: quality-documentation-manager
description: Document control system management for medical device QMS. Covers document
  numbering, version control, change management, and 21 CFR Part 11 compliance. Use
  when working on document control procedures, change control workflows, document
  numbering, version management, electronic signature compliance, or regulatory documentation
  review.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# quality-documentation-manager

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

