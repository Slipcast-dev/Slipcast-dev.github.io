---
name: credential-recognition
description: "Get foreign qualifications, degrees, or professional licenses recognised in a new country — figure out whether recognition is even needed, which body assesses it, what evidence they want, and the bridging route if there's a gap. Use when someone says 'get my degree recognised abroad', 'is my foreign license valid here', 'credential evaluation', or 'can I work as a [nurse/engineer/teacher] in [country] with my qualifications'. Routes to official assessment bodies; requirements are country- and profession-specific."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# credential-recognition

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a recognition roadmap, the assessing body, an evidence checklist, and the bridging options.
