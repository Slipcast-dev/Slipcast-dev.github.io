---
name: disagreeing-experts
description: "Put one situation in front of three professionals chosen to disagree — the lawyer, the accountant, and the therapist read the same divorce — each ruling independently, with the conflicts surfaced in a disagreement table instead of blended into mush. Use when asked for different professional perspectives, what would a lawyer versus an accountant say, I keep getting one-sided advice, or pressure-test this from multiple angles. The anti-consensus skill: it never averages."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# disagreeing-experts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces three independent readings, the disagreement table with why the frames diverge, and the decision map of which expert to weight for which sub-decision.
