---
name: cn-genai-filing
description: "Use when asked 大模型备案怎么做, 生成式人工智能服务备案还是登记, 算法备案流程, AI 生成内容标识怎么加, 我们接了已备案的大模型还要备案吗, or prepare a generative AI product for launch in mainland China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-genai-filing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the obligations that apply (generative AI service filing, registration for apps built on a filed model, algorithm filing, AI-generated content labelling), the documents and security self-assessment to prepare, a launch checklist, and the questions for the provincial cyberspace administration, each marked to confirm.
