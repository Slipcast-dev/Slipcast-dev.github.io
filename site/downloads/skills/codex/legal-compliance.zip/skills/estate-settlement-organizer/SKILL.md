---
name: estate-settlement-organizer
description: "Organize an executor's work — the settlement ladder from will-to-probate-to-distribution, the asset/debt inventory, the creditor and beneficiary communications, and the records that keep an executor protected. Use when asked I'm the executor what do I do, organize settling an estate, what's the probate process roughly, or track estate assets and debts."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# estate-settlement-organizer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the phased task ladder (jurisdiction-flagged), the inventory workbook structure, communication templates, and the executor's self-protection rules.
