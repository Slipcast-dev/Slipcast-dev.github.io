---
name: quality-manager-qms-iso13485
description: ISO 13485 Quality Management System implementation and maintenance for
  medical device organizations. Provides QMS design, documentation control, internal
  auditing, CAPA management, and certification support. Use when working with medical
  device quality systems, preparing for ISO 13485 audits, managing regulatory compliance
  documentation, setting up corrective actions, or building audit preparation programs.
  Useful for quality management, audit preparation, regulatory compliance, medical
  device documentation, and corrective action workflows.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# quality-manager-qms-iso13485

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

