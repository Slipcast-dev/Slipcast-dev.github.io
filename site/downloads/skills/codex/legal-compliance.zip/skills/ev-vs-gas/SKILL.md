---
name: ev-vs-gas
description: "Compare an EV against a comparable gas car on total cost — upfront gap after incentives, energy vs fuel per year, maintenance delta, and the crossover year when the EV pulls ahead (or doesn't). Use when asked is an EV worth it, EV vs gas total cost, when does an EV pay for itself, or should my next car be electric."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ev-vs-gas

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the year-by-year cumulative comparison from the script, the crossover year, the per-mile energy math, and the honest not-modeled list.
