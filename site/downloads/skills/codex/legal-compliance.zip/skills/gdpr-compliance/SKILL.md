---
name: gdpr-compliance
description: "Assess GDPR compliance and build the core records (ROPA, lawful basis, DSAR, DPIA triggers). Use when asked to get GDPR-compliant, build a Record of Processing Activities, decide a lawful basis, handle data-subject requests, or check whether a DPIA is needed."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# gdpr-compliance

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a GDPR assessment — a ROPA, lawful-basis mapping per activity, DSAR workflow, DPIA-trigger screen, and a prioritised gap list.
