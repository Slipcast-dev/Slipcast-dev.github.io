---
name: qa-release-signoff
description: "Produce a QA release sign-off / go-no-go readiness report. Use when asked for a release sign-off, a go/no-go QA report, release readiness, or a test summary before shipping."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# qa-release-signoff

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sign-off — what was tested and the results, open defects by severity, coverage and residual risk, the go/no-go recommendation with conditions, and a rollback note — so the release decision is evidence-based, not a vibe.
