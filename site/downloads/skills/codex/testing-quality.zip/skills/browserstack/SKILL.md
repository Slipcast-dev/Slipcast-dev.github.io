---
name: browserstack
description: Run tests on BrowserStack. Use when user mentions "browserstack", "cross-browser",
  "cloud testing", "browser matrix", "test on safari", "test on firefox", or "browser
  compatibility".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# browserstack

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

