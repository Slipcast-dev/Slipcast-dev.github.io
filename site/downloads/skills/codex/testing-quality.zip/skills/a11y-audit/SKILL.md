---
name: a11y-audit
description: Accessibility audit skill for scanning, fixing, and verifying WCAG 2.2
  Level A and AA compliance across React, Next.js, Vue, Angular, Svelte, and plain
  HTML codebases. Use when auditing accessibility, fixing a11y violations, checking
  color contrast, generating compliance reports, or integrating accessibility checks
  into CI/CD pipelines.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# a11y-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

