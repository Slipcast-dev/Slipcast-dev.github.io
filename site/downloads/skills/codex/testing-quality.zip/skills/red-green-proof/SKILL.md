---
name: red-green-proof
description: Turns a suspected bug into a proven one. Verify the cause against reality
  before claiming it, write a test that FAILS on the current code, apply the fix,
  watch it pass — then revert the fix and confirm the test goes red again, because
  a test that passes both ways proves nothing. Invoked bare after a debugging conversation,
  it takes the target from context rather than asking. Use when fixing a bug, investigating
  an incident, hardening a flaky area, or when asked to "add tests that reveal the
  bug". Triggers on "/red-green-proof", "prove the bug", "red-green", "make the test
  fail first", "is that test load-bearing", "reveal the bug with a test".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# red-green-proof

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

