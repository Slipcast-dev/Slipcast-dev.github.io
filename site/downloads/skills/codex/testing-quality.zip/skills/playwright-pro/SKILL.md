---
name: playwright-pro
description: Production-grade Playwright testing toolkit. Use when the user mentions
  Playwright tests, end-to-end testing, browser automation, fixing flaky tests, test
  migration, CI/CD testing, or test suites. Generate tests, fix flaky failures, migrate
  from Cypress/Selenium, sync with TestRail, run on BrowserStack. 55 templates, 3
  agents, smart reporting.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# playwright-pro

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

