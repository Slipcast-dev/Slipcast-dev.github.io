---
name: replica-diff
description: 'Compares an app clone against the original: a feature parity score from
  the feature matrix (weighted by must, should, could) with the missing list in build
  order, plus a screenshot layout diff that ignores colour so a rebrand does not count
  against you. Two standard-library Python tools. Use when the user says "how close
  is my clone", "compare it to the original", "what''s missing", "parity check", "diff
  the screens", "is it ready", or after /replica-test.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-diff

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

