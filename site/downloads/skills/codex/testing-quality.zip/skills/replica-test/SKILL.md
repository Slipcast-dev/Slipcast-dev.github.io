---
name: replica-test
description: 'Clicks through every flow of an app clone and tests it for bugs: a test
  plan generated from the recon flows with happy paths and edge cases, Playwright
  end-to-end tests where possible, a browser click-through where not, and bug reports
  in a fixed format with severity, steps and evidence. Use when the user says "test
  my clone", "find bugs", "QA this", "click through everything", "write e2e tests",
  "does it work", or after /replica-build or /replica-backend.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-test

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

