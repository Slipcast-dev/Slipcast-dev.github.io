---
name: senior-qa
description: Generates unit tests, integration tests, and E2E tests for React/Next.js
  applications. Scans components to create Jest + React Testing Library test stubs,
  analyzes Istanbul/LCOV coverage reports to surface gaps, scaffolds Playwright test
  files from Next.js routes, mocks API calls with MSW, creates test fixtures, and
  configures test runners. Use when the user asks to "generate tests", "write unit
  tests", "analyze test coverage", "scaffold E2E tests", "set up Playwright", "configure
  Jest", "implement testing patterns", or "improve test quality".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-qa

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

