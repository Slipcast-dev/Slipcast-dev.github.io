# Бэкенд и надёжность данных / Backend and data reliability · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Совместимая пагинация и согласованность транзакций.

Compatible pagination and transaction consistency.

Выберите скилл под задачу / Choose a skill for your task:

- [paginated-api-compatibility](skills/paginated-api-compatibility/SKILL.md)
- [transaction-consistency-check](skills/transaction-consistency-check/SKILL.md)
