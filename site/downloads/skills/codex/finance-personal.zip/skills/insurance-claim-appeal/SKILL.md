---
name: insurance-claim-appeal
description: "Appeal a denied insurance claim — read the real reason for the denial, find the strongest grounds, and draft the appeal with the evidence that answers it. Use when asked to appeal a denied claim, my insurance claim was rejected, the insurer won't pay, or how do I fight a claim denial. Not legal or regulated advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# insurance-claim-appeal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a decode of the denial reason, the best grounds to appeal on, a structured appeal letter citing your policy, the evidence checklist, deadlines to watch, and the external-review/ombudsman escalation.
