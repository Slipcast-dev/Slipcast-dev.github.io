---
name: investing-for-beginners
description: "Understand the basics of investing enough to start sensibly — the core concepts, the simple default that works for most people, and the traps that separate beginners from their money. Use when asked how do I start investing, explain investing for beginners, I have money to invest but don't know how, or is investing worth it for me."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# investing-for-beginners

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the essential concepts in plain language (risk, diversification, time, fees, compounding), the boring-but-effective default approach, the order of operations before you invest, and the beginner traps to avoid — educational only, not financial advice, and jurisdiction-neutral.
