---
name: purchase-justification
description: "Write the purchase request that gets approved — the cost-of-not-buying framing, the ROI math at the approver's altitude, the alternatives-considered section that preempts the obvious pushback, and the right-sized ask for the approval tier. Use when asked justify this tool/hire/equipment purchase, write the budget request, my requests keep getting deferred, or make the business case for this spend."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# purchase-justification

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the justification memo: the problem priced, the ROI shown, alternatives dispatched, and the ask sized to its approval path.
