---
name: lending-risk-brief
description: "Write a portfolio-level lending risk brief: concentration analysis by sector, geography and single name, vintage performance, migration matrix narrative, macro-sensitivity scenarios, top watch names, and actions. Use when asked to write a portfolio risk report, credit risk committee brief, loan book review, or quarterly portfolio quality update."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# lending-risk-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured risk brief with concentration tables, migration narrative, scenario read, watch list, and recommended actions.
