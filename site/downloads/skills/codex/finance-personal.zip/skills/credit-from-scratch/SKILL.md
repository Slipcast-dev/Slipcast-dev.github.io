---
name: credit-from-scratch
description: "Build a credit history from zero in a new country — understand that credit doesn't transfer across borders, get the first products that report, avoid the newcomer traps, and reach a usable score in months not years. Use when someone says 'I have no credit history in [country]', 'build credit as a newcomer/immigrant', 'why was I rejected with a great score back home', or 'how do I get a credit card/loan as a new arrival'. Educational, not financial advice; routes to official credit sources."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# credit-from-scratch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a credit-building plan, the starter products that report, a timeline, and the traps to avoid.
