---
name: layoff-financial-triage
description: "The first-72-hours money plan after a layoff — runway computed, deadlines caught, bleeding stopped, in priority order. Use when asked I just got laid off what do I do about money, build my layoff budget, how long can I last, or what needs to happen this week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# layoff-financial-triage

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the runway number, the deadline list (healthcare, unemployment filing, equity exercise windows), the spending triage, and a one-week action checklist.
