---
name: first-100k-plan
description: "Build a realistic plan to reach your first major savings/investing milestone — the hardest one — by focusing on the levers that actually move it: income, savings rate, and time. Use when asked how do I save my first 100k, plan to build wealth, reach a savings milestone, or how do I actually get ahead financially."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# first-100k-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest read on your three levers (earn more, spend less, invest consistently), which one has the most room for you, a milestone timeline based on real numbers, the compounding effect once you're rolling, and the traps that stall people — educational, not financial advice.
