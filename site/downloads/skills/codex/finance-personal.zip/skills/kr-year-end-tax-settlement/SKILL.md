---
name: kr-year-end-tax-settlement
description: "Use when asked 연말정산 어떻게 해요, 연말정산 간소화 자료 어떻게 제출해, which deductions can I claim in my Korean year-end tax settlement, 부양가족 공제 누구 올려야 해, 맞벌이 연말정산 누가 공제받는 게 유리해, or 13월의 월급 how do I get a bigger refund."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# kr-year-end-tax-settlement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the settlement timeline, which 공제 apply to the person's situation and what proves each one, the 홈택스 간소화 steps, what the employer cannot settle and must go to 5월 종합소득세 신고 or 경정청구 instead, and a document checklist.
