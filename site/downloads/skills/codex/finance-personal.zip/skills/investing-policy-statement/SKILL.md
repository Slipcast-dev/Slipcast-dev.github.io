---
name: investing-policy-statement
description: "Draft a personal investing policy statement (IPS) — the rules someone sets for their own investing. Use when asked to define an investment strategy, set a target asset allocation, or write rules to avoid panic-driven decisions. Educational, not regulated financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# investing-policy-statement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured IPS: goals, risk tolerance, target allocation, contribution & rebalancing rules, and what NOT to do.
