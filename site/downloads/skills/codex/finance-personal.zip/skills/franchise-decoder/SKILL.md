---
name: franchise-decoder
description: "Decode a franchise offering before you sign away a decade — the earnings claims and their absence, the territory that is not exclusive, the renewal terms that expire your equity, the mandatory-supplier margins, and the validation calls that reveal what the brochure will not. Use when asked to evaluate a franchise, review an FDD or franchise agreement, is this franchise a good deal, or what to ask existing franchisees. Not legal or financial advice — a franchise lawyer reviews before any signature."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# franchise-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clause-by-clause decode organised by where the money leaks, the earnings-claim reality check, the validation-call script, and the walk-away list.
