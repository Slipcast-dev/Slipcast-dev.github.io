---
name: cn-year-end-bonus
description: "Use when asked 年终奖怎么算, 13薪和年终奖有什么区别, 年终奖怎么交税, 单独计税还是并入综合所得, 年终奖被扣了怎么办, 离职了年终奖还发吗, 怎么问 HR 年终奖, or understand a year-end bonus in mainland China. Not tax or legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-year-end-bonus

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces how the person's bonus is likely calculated from their documents, the 13薪 versus discretionary bonus distinction, the tax options with a worked comparison marked to confirm, questions to ask HR or the manager in writing, and the steps if a bonus is withheld after resignation, all marked to confirm against current rules.
