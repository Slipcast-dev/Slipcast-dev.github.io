---
name: debt-payoff
description: "Build a debt payoff plan — avalanche vs snowball simulated month by month on your actual debts, the real payoff dates, and the psychology-vs-arithmetic tradeoff priced in dollars. Use when asked how do I pay off my debts, avalanche or snowball, make me a debt payoff plan, tackle my credit cards or loans, or when will I be debt-free. Educational, not regulated financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# debt-payoff

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the month-by-month comparison from the script, the payoff order with dates, the interest cost of choosing morale over math, and the plan-survival rules.
