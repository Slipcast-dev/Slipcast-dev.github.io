---
name: stop-the-bleed-triage
description: "When money is in free-fall, triage the crisis — what to pay first, what to let slide, and what to protect at all costs. Use when asked I can't pay all my bills, which bills do I pay first, financial emergency, or I'm broke and panicking. Not financial advice; points to nonprofit credit counseling."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stop-the-bleed-triage

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a priority order for scarce money (keep-the-lights-on essentials and things with severe consequences first, unsecured debt last), what to protect no matter what (housing, utilities, food, transport to work, essential insurance), which creditors to call and what to ask for (hardship programs, deferrals), the help to tap now (assistance programs, food banks), and a calm next-24-hours plan.
