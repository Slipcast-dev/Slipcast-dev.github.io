---
name: jp-tax-return
description: "Use when asked 確定申告のやり方, do I need to file a tax return in Japan, how do I claim medical expense deduction, ふるさと納税の確定申告, 副業の確定申告, how to file with e-Tax, or 日本报税怎么弄."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jp-tax-return

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces whether the person must or should file, the income and deductions to declare, a step-by-step filing plan with e-Tax or on paper, the documents to gather, and the deadlines and payment options to confirm with the National Tax Agency.
