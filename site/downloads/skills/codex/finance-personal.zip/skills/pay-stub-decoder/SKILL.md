---
name: pay-stub-decoder
description: "Decode a pay stub line by line — every deduction explained, the gross-to-net story, and the errors worth catching. Use when asked to explain my pay stub, why is my paycheck smaller than expected, what are all these deductions, or check my paycheck for mistakes."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pay-stub-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a line-by-line decode, the gross-to-net waterfall, the error checklist (withholding, benefits, overtime), and the fixes to raise with payroll.
