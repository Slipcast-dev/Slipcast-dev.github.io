---
name: daily-cash-book
description: "Keep simple daily money records for a small trader, stall or home business with no accounting software: a cash book, stock count and weekly summary that show whether the business makes money and keep business and household money apart. Use when someone says 'I don't know if my shop makes money', 'how do I keep records for my small business', 'the bank wants records for a loan', or 'I mix business and home money'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# daily-cash-book

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page daily cash book, a weekly summary, a simple stock count, and three rules to keep the habit.
