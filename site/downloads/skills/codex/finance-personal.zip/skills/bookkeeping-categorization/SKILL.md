---
name: bookkeeping-categorization
description: "Set up a chart of accounts and rules for categorizing transactions. Use when asked how to categorize expenses/transactions, set up a chart of accounts, organize bookkeeping, or sort bank transactions into the right buckets. Not tax/accounting advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# bookkeeping-categorization

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a practical chart of accounts for the business, categorization rules with examples and edge cases, and a clean-books routine — so the books are consistent and ready for an accountant.
