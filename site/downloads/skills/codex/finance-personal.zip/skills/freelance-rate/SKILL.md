---
name: freelance-rate
description: "Derive a freelance day/hourly rate backwards from target income, honest billable utilization, overhead, and the self-employment tax premium — the arithmetic that proves a rate is not salary÷2000. Use when asked what should I charge as a freelancer, how do I set my consulting rate, why is my freelance rate so high, or convert my salary to a contract rate."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# freelance-rate

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the required-revenue breakdown, billable-hours math, the hourly and day rate, and the multiplier vs the naive salary÷2000 number.
