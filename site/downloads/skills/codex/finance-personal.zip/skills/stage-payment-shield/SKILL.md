---
name: stage-payment-shield
description: "Set up deposits and stage payments that protect a tradesperson from the customer who won't pay AND read as fair to the customer — stage triggers tied to visible milestones, deposit sizing by job type, the payment terms paragraph for quotes, and the scripts for late stages. Use when a tradesperson asks 'how much deposit should I take', 'customer hasn't paid the second stage', 'payment terms for my quotes', or got burned on a big job."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stage-payment-shield

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a stage-payment schedule, the terms paragraph, and firm-but-professional chase scripts.
