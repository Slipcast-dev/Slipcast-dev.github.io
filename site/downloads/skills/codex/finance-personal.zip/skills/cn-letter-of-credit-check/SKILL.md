---
name: cn-letter-of-credit-check
description: "Use when asked 信用证审证, 信用证审单, 审核信用证条款, 单证不符点, L/C 软条款, 交单前检查, or check a letter of credit or a set of export documents against it for a Chinese exporter. Not legal or banking advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-letter-of-credit-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an L/C term review (dates, amounts, shipment, documents, soft clauses) with what to ask the buyer to amend, and a document-by-document discrepancy checklist (invoice, bill of lading, packing list, insurance, certificate of origin, inspection) with the relevant UCP 600 articles, all marked to confirm with the bank's documentary credit team.
