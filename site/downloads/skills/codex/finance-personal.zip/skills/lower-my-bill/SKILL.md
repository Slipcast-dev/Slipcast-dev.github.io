---
name: lower-my-bill
description: "Negotiate a recurring bill down — internet, phone, insurance, cable, gym — with a ready-to-read script, the competitor leverage that actually moves the price, and exactly what to say when they say no. Use when asked to lower my bill, negotiate my internet/phone bill, my provider raised my price, or how do I get a discount on [service]."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# lower-my-bill

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a call-or-chat script in your words, the specific leverage for your situation, a fallback ladder (discount → downgrade → cancel lever), and a note of what to write down so the promised deal actually sticks.
