---
name: student-loan-strategy
description: "Decide what the extra money does about student loans — attack them, invest alongside them, or ride a forgiveness track — with the three paths simulated on your actual loans and the guaranteed-vs-assumed framing kept honest. Use when asked should I pay off my student loans faster, pay loans or invest, is my forgiveness track worth it, or model my student debt."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# student-loan-strategy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the three-path comparison from the script, the guaranteed-return framing, the forgiveness-track math with its warnings, and the decision sheet.
