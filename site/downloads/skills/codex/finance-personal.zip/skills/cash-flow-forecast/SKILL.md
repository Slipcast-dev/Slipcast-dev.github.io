---
name: cash-flow-forecast
description: "Build a short-term (13-week) cash flow forecast to see if you can cover what's due. Use when asked to build a cash flow forecast, a 13-week cash flow, a cash projection, or to plan around a cash crunch. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cash-flow-forecast

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a week-by-week forecast structure — opening cash, expected inflows, scheduled outflows, net movement, and closing/low-point — with the formulas and a worked example, plus the levers if cash goes tight.
