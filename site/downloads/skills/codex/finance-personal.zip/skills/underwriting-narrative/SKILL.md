---
name: underwriting-narrative
description: "Write the underwriting file narrative for a risk: the risk story, exposure quantification, loss-history read, mitigating and aggravating factors, terms and subjectivities rationale, appetite fit, and a refer-or-bind recommendation. Use when asked to write up an underwriting file, document why we're writing a risk, prepare a referral to a senior underwriter, or justify terms and exclusions on a submission."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# underwriting-narrative

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete underwriting narrative ready for the file or referral.
