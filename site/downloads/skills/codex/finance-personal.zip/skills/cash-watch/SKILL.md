---
name: cash-watch
description: "Set up a proactive agent to watch a small business's cash every day across Stripe, QuickBooks or Xero and the bank feed: today's cash position, money due in and out this week, failed payments, new disputes and the runway line, with clear rules for what interrupts you and what waits for the morning brief. Use when asked to have my agent keep an eye on cash, daily cash check for Duet, alert me about failed payments or disputes, watch my runway, or monitor Stripe and QuickBooks for me."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cash-watch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the watch definition (sources, checks, thresholds), the interrupt and brief rules, the daily cash lines in a fixed format, and the drafts the agent may prepare.
