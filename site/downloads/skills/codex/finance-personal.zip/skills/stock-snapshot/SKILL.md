---
name: stock-snapshot
description: "Fetch a stock quote snapshot with keyless curl — Yahoo Finance's public chart endpoint, read with the discipline unofficial market data demands: timestamped, delayed-flagged, and never advice. Use when asked what's this stock at, how did the market do today, get me a ticker's recent range, or pull basic price history."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stock-snapshot

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the quote with change and range context, the source-honesty caveats (unofficial, possibly delayed), the rerunnable command, and a hard no-advice line.
