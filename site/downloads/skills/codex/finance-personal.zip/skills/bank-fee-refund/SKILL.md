---
name: bank-fee-refund
description: "Get a bank fee waived or refunded — overdraft, late, maintenance, ATM, or foreign-transaction — with the ask written and the leverage that works. Use when asked to get a bank fee refunded, waive my overdraft fee, the bank charged me a fee, or how to get charges reversed."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# bank-fee-refund

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on which fees are commonly reversible, the script to request a refund (in person, chat, or call), the loyalty/first-time/error leverage to use, and how to prevent the fee recurring — plus when to escalate or switch banks.
