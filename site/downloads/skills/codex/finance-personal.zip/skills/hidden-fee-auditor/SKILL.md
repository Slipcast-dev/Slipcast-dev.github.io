---
name: hidden-fee-auditor
description: "Scan a bill, contract, or quote for junk and hidden fees — the padding buried in the fine print — and get them questioned or removed. Use when asked to check this bill for hidden fees, are these charges legit, what am I actually paying for, or review this quote for junk fees."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hidden-fee-auditor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a line-by-line read flagging suspicious/vague/padded charges, which are commonly negotiable or bogus, the questions to ask and script to dispute them, and an estimate of what you could save — across bills like telecom, hotels, cars, banking, and services.
