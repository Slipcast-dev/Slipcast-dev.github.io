---
name: financial-independence-roadmap
description: "Map a realistic path toward financial independence — the number you'd actually need, your savings rate's massive effect on the timeline, and the honest tradeoffs. Use when asked how do I reach financial independence, explain FIRE, what's my FI number, or plan for financial freedom. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# financial-independence-roadmap

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an educational read on your rough FI number (and why the savings rate matters more than income), the timeline math at different savings rates, the levers and lifestyle tradeoffs, the different flavors (lean/coast/full), and the traps — turning a vague dream of freedom into a directional plan.
