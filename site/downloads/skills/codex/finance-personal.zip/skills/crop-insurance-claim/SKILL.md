---
name: crop-insurance-claim
description: "Make a crop or livestock insurance claim after drought, flood, pests, disease or hail: report it in time, record the loss properly, and follow up or appeal if the payout is too low or refused. Use when someone says 'my crop failed, how do I claim', 'the insurance company rejected my crop claim', 'what proof do I need for a crop loss', or 'how do weather-index insurance payouts work'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# crop-insurance-claim

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a claim timeline, an evidence checklist, a loss record, a notification message, and an appeal plan.
