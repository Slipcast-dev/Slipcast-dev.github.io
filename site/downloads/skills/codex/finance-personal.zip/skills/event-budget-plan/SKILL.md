---
name: event-budget-plan
description: "Build an event budget that survives the event — every cost line including the ones people forget, the contingency sized to the actual risk, and the tracking that shows overspend while it can still be stopped. Use when asked to build an event budget, cost an event, price a conference or wedding, or explain why an event went over budget."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# event-budget-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the full cost breakdown, the commonly-forgotten lines, the contingency sizing, the payment and cash-flow schedule, the per-head economics, and the variance tracker.
