---
name: the-car-dealership
description: "Simulate the car-buying gauntlet before you walk in — the four-square worksheet, the payment-question trap, the trade-in shuffle, and the finance office's second sales floor, all run against your actual deal. Use when asked practice negotiating at a dealership, simulate the finance office, what tricks will the dealer use, or prep me before I buy a car."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-car-dealership

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the showroom and finance-office transcripts with the salesperson's playbook notes, the deal outcome vs your targets, and a debrief with the holds that would have worked.
