---
name: compound-growth-explainer
description: "Make compound growth actually click — see how small, consistent amounts become large over time, and why starting now beats starting bigger later. Use when asked explain compound interest, how does compounding work, is it worth investing small amounts, or why should I start now. Educational, not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# compound-growth-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an intuitive explanation of compounding with concrete illustrative examples for your situation, the outsized effect of time (why an early start beats a later larger one), how fees and inflation eat into it, and the honest caveats — turning an abstract concept into the motivation to start now.
