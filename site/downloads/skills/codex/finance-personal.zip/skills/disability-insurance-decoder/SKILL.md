---
name: disability-insurance-decoder
description: "Decode a disability insurance policy or employer LTD plan — own-occupation vs any-occupation, the benefit math after offsets and taxes, and the definitions that decide whether it pays. Use when someone asks 'is my disability insurance any good', 'decode my LTD policy', 'what does own-occupation mean', or 'how much would I actually get'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# disability-insurance-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a definition decode of the clauses that decide claims, the real benefit math after offsets, ranked red flags, and the questions to ask before relying on the coverage.
