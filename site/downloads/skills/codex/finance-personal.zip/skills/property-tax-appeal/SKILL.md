---
name: property-tax-appeal
description: "Challenge an over-assessed property tax bill — check whether your assessment is too high, build the evidence, and file the appeal before the deadline. Use when asked to appeal my property taxes, my property assessment is too high, lower my property tax, or is my home over-assessed. Not legal or tax advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# property-tax-appeal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an over-assessment check (comparables vs your valuation), the evidence pack to build, the appeal steps and the strict deadline to watch, a realistic savings estimate, and what to expect at a hearing — flagging that process and rules are local.
