---
name: singapore-cpf-explainer
description: "Use when asked how CPF works, how much CPF my employer should pay, what happens to my CPF at 55, can I use CPF for my HDB flat, should I top up my CPF, or 公积金怎么算 in Singapore."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# singapore-cpf-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces how the person's CPF contributions are split across the accounts, a contribution check against payslips, what changes at 55 and 65, the housing, top-up and withdrawal options with their trade-offs, and the figures to confirm with the CPF Board.
