---
name: finance-skills
description: 'Router/index for the finance skills bundled in this plugin: financial-analyst
  (ratio analysis, DCF valuation, budget variance, rolling forecasts), saas-metrics-coach
  (ARR/MRR, churn, CAC/LTV, NRR, quick ratio) and month-end-close (close calendar,
  reconciliations, flux review). Use when a finance request doesn''t obviously match
  one skill and you need to pick the right one (e.g., ''analyze these financials'',
  ''how healthy are my SaaS metrics'').'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# finance-skills

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

