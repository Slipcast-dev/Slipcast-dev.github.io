---
name: subscription-audit
description: "Find and rank the recurring-payment leak — every subscription annualized, sorted by real yearly cost, with the keep/cancel/downgrade pass and the where-they-hide checklist. Use when asked audit my subscriptions, how much am I spending on subscriptions, help me cancel stuff, or what recurring charges am I forgetting."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# subscription-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the annualized ranking from the script, the hidden-subscription hunt list, the keep/cancel/downgrade decisions with the cancellation friction notes, and the re-audit cadence.
