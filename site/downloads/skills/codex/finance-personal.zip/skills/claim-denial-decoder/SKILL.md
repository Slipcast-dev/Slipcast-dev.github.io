---
name: claim-denial-decoder
description: "Decode an insurance claim denial letter — what the cited reason actually means, whether it's commonly overturnable, and the appeal letter that answers it point by point. Use when someone asks 'my insurance claim was denied what do I do', 'decode this denial letter', 'can I appeal this denial', or 'write my insurance appeal'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# claim-denial-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the denial decode with overturn-likelihood framing, the evidence checklist, the point-by-point appeal letter, and the escalation ladder past the insurer.
