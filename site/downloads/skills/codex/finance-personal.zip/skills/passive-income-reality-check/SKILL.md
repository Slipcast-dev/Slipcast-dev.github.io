---
name: passive-income-reality-check
description: "Cut through passive-income hype to what's actually realistic for you — the real effort, capital, and risk behind each option, and which (if any) fit your situation. Use when asked how do I make passive income, is passive income real, best passive income ideas, or help me build income streams. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# passive-income-reality-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest teardown of the popular passive-income options (what they really require, how 'passive' they actually are, typical returns and risks), a match to your capital/skills/time, the scams and get-rich-quick traps to avoid, and a grounded next step — replacing the fantasy with a realistic path.
