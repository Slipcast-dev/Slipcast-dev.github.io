---
name: financial-analyst
description: Performs financial ratio analysis, DCF valuation, budget variance analysis,
  and rolling forecast construction for strategic decision-making. Use when analyzing
  financial statements, building valuation models, assessing budget variances, or
  constructing financial projections and forecasts. Also applicable when users mention
  financial modeling, cash flow analysis, company valuation, financial projections,
  or spreadsheet analysis.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# financial-analyst

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

