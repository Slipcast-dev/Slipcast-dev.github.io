---
name: tax-residency-primer
description: "Orient yourself on your tax-residency situation after moving countries — the questions that determine where you owe tax, the double-taxation and dual-residency traps, and what to pin down before you file — so you know what to ask a cross-border tax professional. Use when someone says 'am I tax resident in [country]', 'do I pay tax in two countries', 'moved countries mid-year, what about tax', or 'tax residency rules'. Strictly not tax advice — it orients and routes to a qualified adviser."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tax-residency-primer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a residency-question map, the trap list, a document checklist, and the questions for a professional.
