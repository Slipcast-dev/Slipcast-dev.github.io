---
name: debt-collector-response
description: "Respond to a debt collector correctly — know your rights, make them prove the debt, and avoid the mistakes that reset the clock or admit liability. Use when asked how to deal with a debt collector, a collection agency is contacting me, is this debt real, or respond to a collections letter. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# debt-collector-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a validation/proof-of-debt request, a rights-aware read on what collectors can and can't do, guidance on statute-of-limitations and not accidentally restarting it, a communication and record-keeping plan, and escalation if they break the rules.
