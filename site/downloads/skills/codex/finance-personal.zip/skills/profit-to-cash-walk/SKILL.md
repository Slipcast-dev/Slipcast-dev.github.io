---
name: profit-to-cash-walk
description: "Use when asked to reconcile operating profit to free cash flow, walk from EBIT to FCF, explain why profit and cash differ in this report, or show a company's cash conversion from its own accounts. Takes operating profit from an uploaded annual report and walks line by line to free cash flow using the report's own numbers, arithmetic shown at every step. Educational, not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# profit-to-cash-walk

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a step table (line, page, amount, running total, one-sentence reason cash and profit diverge), a drift flag on every line where the arithmetic could go wrong, a tie-out to the reported cash flow statement, and an instruction to independently check at least one subtraction.
