---
name: cn-small-business-tax
description: "Use when asked 个体户怎么报税, 小规模纳税人增值税怎么算, 小微企业所得税优惠, 经营所得汇算, 开票超过免税额怎么办, or plan taxes for a sole trader (个体工商户) or small company in China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-small-business-tax

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the taxes that apply (增值税, 附加税费, 个人所得税经营所得 or 企业所得税), the relief that may apply with the announcement to check, a worked estimate from the person's own figures, a filing calendar, and the questions for the local tax office or 12366.
