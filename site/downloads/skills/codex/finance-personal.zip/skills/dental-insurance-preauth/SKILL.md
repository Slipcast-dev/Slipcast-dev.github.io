---
name: dental-insurance-preauth
description: "Write a dental pre-authorisation request or claim narrative that gets approved the first time — the diagnosis, the documented failure of lesser treatment, and the attachments a reviewer needs, assembled in the order they assess them. Use when asked to write a pre-auth, submit a predetermination, appeal a denied dental claim, or write a narrative for a crown, implant, or perio case. Administrative support only; clinical justification must come from the treating clinician's own findings."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dental-insurance-preauth

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the narrative, the supporting-evidence checklist, the attachment list, and an appeal letter if the claim was already denied.
