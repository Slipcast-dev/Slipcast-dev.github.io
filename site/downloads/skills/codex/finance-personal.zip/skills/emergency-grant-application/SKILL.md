---
name: emergency-grant-application
description: "Apply for emergency money after a disaster, crisis or sudden hardship: government disaster assistance, local hardship and welfare funds, charity crisis grants, and employer or union funds. Use when someone says 'is there emergency money after the flood', 'how do I apply for disaster assistance', 'I need a hardship grant to pay for food and rent', or 'my application for emergency help was refused'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# emergency-grant-application

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a list of funds to try in order, the documents each usually needs, an application statement, and a follow-up and appeal plan.
