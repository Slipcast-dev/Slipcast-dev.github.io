---
name: jp-year-end-adjustment
description: "Use when asked 年末調整の書き方, how do I fill in my nenmatsu chōsei forms, which deductions can I claim at year-end in Japan, 扶養控除等申告書の書き方, 保険料控除申告書, or do I need to file a tax return instead."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jp-year-end-adjustment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces which forms the person must submit to their employer, line-by-line guidance for their situation, the deductions they can claim through year-end adjustment, what must go to a tax return instead, and a checklist of certificates to gather.
