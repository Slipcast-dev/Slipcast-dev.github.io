---
name: net-worth-statement
description: "Produce a personal net-worth statement — assets minus liabilities — and a way to track it. Use when asked to calculate net worth, summarize finances, or set up net-worth tracking. Educational, not regulated financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# net-worth-statement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a categorized assets/liabilities statement, the net-worth figure, liquidity and debt ratios, and a tracking cadence.
