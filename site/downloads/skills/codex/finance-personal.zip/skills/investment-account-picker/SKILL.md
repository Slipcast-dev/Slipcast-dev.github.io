---
name: investment-account-picker
description: "Understand which type of investment/savings account to use for your goal — the tax-advantaged vs taxable question, and which wrapper fits which money. Use when asked which account should I invest in, what's the difference between these account types, where should I put my savings, or tax-advantaged accounts explained. Not financial advice; account types are jurisdiction-specific."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# investment-account-picker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain-language explainer of the common account categories (retirement/tax-advantaged, general/taxable, education, short-term), a match of your goals to the right account type, the order to prioritize them, and what to verify locally — because using the wrong wrapper can cost you real money.
