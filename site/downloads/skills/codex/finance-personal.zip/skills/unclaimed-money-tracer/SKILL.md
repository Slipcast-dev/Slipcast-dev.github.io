---
name: unclaimed-money-tracer
description: "Track down money that's yours but forgotten — dormant accounts, old deposits, uncashed checks, lost pensions, insurance payouts, and unclaimed-property funds. Use when asked to find unclaimed money, is there money owed to me, find a lost account/pension, or search unclaimed property. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# unclaimed-money-tracer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a checklist of where forgotten money hides, how to search the official (free) registries for each type, what proof you'll need to claim it, and a strong warning to only use official free searches and never pay a 'finder' up front.
