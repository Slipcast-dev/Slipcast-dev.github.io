---
name: tax-deduction-finder
description: "Surface the personal tax deductions and credits you might be missing — so you can research them or raise them with your tax preparer before you file. Use when asked what tax deductions can I claim, am I missing any tax breaks, deductions for [job/situation], or help me lower my tax bill. Educational — not tax advice, and rules vary by country and year."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tax-deduction-finder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tailored list of commonly-missed deductions/credits for your situation, what records each needs, the ones worth digging into, and clear flags to verify against current rules or a professional.
