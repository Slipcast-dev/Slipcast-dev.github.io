---
name: roi-estimator
description: "Estimate the ROI, payback, and NPV of an investment, project, or purchase. Use when asked to calculate ROI, build a business case, justify a purchase/initiative, work out payback period, or compare options by return."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# roi-estimator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a computed ROI summary (net benefit, ROI %, payback, simple NPV) with the assumptions made explicit and a sensitivity note, so a business case is defensible.
