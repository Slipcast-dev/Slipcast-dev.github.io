---
name: emergency-fund
description: "Size an emergency fund from essential spend and real risk factors — not a one-size 'six months' — with the funding timeline and where the money should sit. Use when asked how big should my emergency fund be, do I have enough saved, emergency fund or invest, or how many months of expenses do I need."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# emergency-fund

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the risk-adjusted target from the script, the essential-spend worksheet, the funding plan, and the what-counts-as-an-emergency rules.
