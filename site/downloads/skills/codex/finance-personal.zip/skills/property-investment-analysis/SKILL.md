---
name: property-investment-analysis
description: "Analyze a rental / investment property's returns — cash flow, cap rate, cash-on-cash, ROI. Use when asked to analyze a rental property, evaluate a real-estate investment, run the numbers on an investment property, or compute cap rate / cash-on-cash. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# property-investment-analysis

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an investment analysis — income and expenses, NOI, cap rate, monthly cash flow, cash-on-cash return, and a verdict against the investor's criteria — with formulas and a worked example.
