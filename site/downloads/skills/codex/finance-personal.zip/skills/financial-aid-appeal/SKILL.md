---
name: financial-aid-appeal
description: "Write a financial-aid appeal or scholarship request letter that aid offices act on — factual, documented, and specific about the ask. Use when asked to appeal my financial aid, write a scholarship letter, ask for more aid after circumstances changed, or respond to an aid decision."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# financial-aid-appeal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the appeal letter with the changed-circumstance case documented, the specific dollar ask, the evidence list to attach, and the follow-up plan.
