---
name: windfall-plan
description: "Make a smart plan for a lump sum — a bonus, inheritance, tax refund, settlement, or sale — so it builds your future instead of evaporating into lifestyle. Use when asked what should I do with a windfall, I came into some money, how to use a bonus/inheritance/tax refund, or don't want to waste this money. Educational — not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# windfall-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a cool-off-first plan, a tax/obligations check, an allocation across foundation-building, goals, and a guilt-free fun slice, and cautions against the classic windfall traps and the vultures that appear.
