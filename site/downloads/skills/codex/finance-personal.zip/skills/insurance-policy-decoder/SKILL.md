---
name: insurance-policy-decoder
description: "Decode a home, renters, or auto insurance policy into what's actually covered, what's excluded, and what the payout math really looks like before you need it. Use when someone asks 'what does my insurance actually cover', 'decode my policy', 'is this deductible normal', or 'actual cash value vs replacement cost'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# insurance-policy-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a coverage decode with real payout scenarios, ranked exclusion red flags, the ACV-vs-replacement-cost math, and the questions to ask your agent before renewal.
