---
name: microloan-comparison
description: "Compare small loans from microfinance institutions, lending apps, savings groups and moneylenders by what they really cost, including flat versus reducing-balance interest, fees, compulsory savings and group guarantees. Use when someone says 'which microloan is cheaper', 'is this lending app a good deal', 'the interest is only 2% a month, is that good', or 'should I join a group loan'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# microloan-comparison

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the true cost of each offer, a side-by-side comparison, the risks in each, and questions to ask before signing.
