---
name: cn-medical-insurance-claim
description: "Use when asked 医保怎么报销, 异地就医怎么备案, 住院能报多少, 门诊报销比例, 手工报销要什么材料, 惠民保值不值得买, or work out what China's basic medical insurance (医保) will pay for a treatment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# cn-medical-insurance-claim

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the person's scheme (职工医保 or 居民医保), how a claim works for this case (direct settlement or manual reimbursement), an out-of-pocket estimate built from the city's own deductible, rate and cap, the cross-region registration (异地就医备案) steps, and the documents to keep.
