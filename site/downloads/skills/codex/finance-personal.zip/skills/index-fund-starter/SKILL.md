---
name: index-fund-starter
description: "Understand index-fund investing and how to actually get started with the simplest evidence-backed approach — plus the details that quietly matter (fees, account, automation). Use when asked how do index funds work, are index funds good, how do I buy index funds, or set up index fund investing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# index-fund-starter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain explanation of what index funds are and why they beat most active investing over time, what to check before buying (expense ratio, what it tracks, the account/wrapper), how to automate contributions, and the mistakes to avoid — educational only, not financial advice.
