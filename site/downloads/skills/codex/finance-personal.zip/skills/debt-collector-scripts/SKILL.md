---
name: debt-collector-scripts
description: "Handle debt collectors without getting bullied or tricked — what to say, what never to say, and the rights that protect you from harassment and illegal tactics. Use when asked how do I deal with debt collectors, a collector keeps calling, can they do this, or how to respond to a collection notice. Not legal advice; points to legal aid."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# debt-collector-scripts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready scripts (request written validation, dispute, cease-contact, set boundaries), the phrases that accidentally restart the clock or admit the debt (and to avoid them), your rights under fair-debt-collection rules (harassment limits, validation, what's illegal), how to check the debt is real and yours, and safe next options.
