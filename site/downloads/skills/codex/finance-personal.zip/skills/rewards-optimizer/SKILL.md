---
name: rewards-optimizer
description: "Figure out the best card or payment route for a purchase (or your everyday spending) to maximize cashback/points — without overspending or drowning in complexity. Use when asked which card should I use for [purchase], maximize my credit card rewards, best card for [category], or optimize my points. Not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rewards-optimizer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the best-value route for the spend from the cards/programs you actually have, a simple everyday cheat-sheet by category, redemption tips, and honest guardrails (pay in full, don't chase points into debt or clutter).
