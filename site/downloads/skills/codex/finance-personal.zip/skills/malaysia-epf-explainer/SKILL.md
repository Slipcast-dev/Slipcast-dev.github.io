---
name: malaysia-epf-explainer
description: "Use when asked how EPF works, how much KWSP my employer should pay, what are Akaun Persaraan, Sejahtera and Fleksibel, when can I withdraw EPF, can I use EPF for my house, or 公积金怎么算 in Malaysia."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# malaysia-epf-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces how the person's EPF contributions are split across the accounts, a contribution check against payslips, the withdrawal routes with their conditions, voluntary contribution options, and the figures to confirm with KWSP.
