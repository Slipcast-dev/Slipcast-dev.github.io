---
name: micro-retirement-planner
description: "Plan a deliberate career break — 3 to 12 months off between chapters — with honest runway math, the re-entry story rehearsed before you leave, health/visa/pension admin by country flagged, and kill criteria for coming back early. Use when someone says 'I want to take 6 months off', 'micro-retirement', 'sabbatical planning', 'quit and travel', or 'can I afford a break'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# micro-retirement-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- В исходном наборе не разрешён ресурс ../../plugins/pm-resignation/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.

## Требования к результату

Produces a runway budget, a break charter with kill criteria, and the future-interview answer written in advance.
