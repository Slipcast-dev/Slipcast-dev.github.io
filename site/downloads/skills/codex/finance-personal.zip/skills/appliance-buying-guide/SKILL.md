---
name: appliance-buying-guide
description: "Cut through the model soup to buy the right appliance — the features that actually matter for you, the ones that are marketing, and when to buy. Use when asked which [fridge/washer/dishwasher] should I buy, help me choose an appliance, what features do I need, or is this appliance worth it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# appliance-buying-guide

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a needs-based feature shortlist (must-have vs nice-to-have vs marketing fluff), fit and capacity checks, reliability and running-cost considerations, warranty/extended-warranty guidance, and timing tips — flagging to verify current models, prices, and specs before buying.
