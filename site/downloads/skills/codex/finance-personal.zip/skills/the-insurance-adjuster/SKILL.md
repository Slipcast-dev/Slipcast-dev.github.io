---
name: the-insurance-adjuster
description: "Simulate the adjuster's settlement call after your accident or loss — the recorded-statement asks, the quick-settlement anchor, the friendly minimization — run against your actual claim, with a debrief on every answer that shrank it. Use when asked the adjuster wants a recorded statement, practice the settlement call, is this settlement offer low, or what will the insurance company try."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-insurance-adjuster

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the call transcript with the adjuster's file notes, the offer trajectory, and a debrief separating fair process from pressure tactics — plus the bright lines that protect a claim.
