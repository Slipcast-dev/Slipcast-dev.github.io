---
name: money-mindset-reset
description: "Untangle the money beliefs and emotions that quietly sabotage your finances — the scripts from childhood, the avoidance, the guilt or fear — and reset to a healthier relationship with money. Use when asked I have a bad relationship with money, why do I self-sabotage financially, money stresses me out, or fix my money mindset. Not therapy or financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# money-mindset-reset

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a look at your money story and where it came from, the specific beliefs driving unhelpful behaviors (avoidance, overspending, scarcity, guilt), a reframe toward a healthier stance, and small behavior shifts that follow — because money behavior is often emotional, not just mathematical.
