---
name: team-budget-tracker
description: "Track a team's budget so surprises die young — the commitment-based view (spent + committed + planned, not just invoiced), the category grain that matches how the team actually spends, the monthly close with its one-sentence read, and the forecast honesty for the year-end question. Use when asked track my team's budget, are we going to blow the budget, why did finance's number surprise us, or set up budget visibility for the team."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# team-budget-tracker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the three-lane tracker (spent/committed/planned), the monthly close ritual, the variance signals, and the year-end forecast method.
