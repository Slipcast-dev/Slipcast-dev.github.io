---
name: grocery-budget-audit
description: "Find where the food money actually goes — a no-shame ledger built from real receipts/statements, the four leak categories (waste, convenience markup, brand autopilot, the takeaway blur), a per-leak fix with realistic savings ranges, and a target budget that survives real life. Use when someone says 'we spend how much on food?!', 'audit my grocery spending', 'cut our food bill', or takeaway guilt is the household argument."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# grocery-budget-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ledger, the leak report, and a keep-the-joy budget.
