---
name: investing-vocabulary-explainer
description: "Use when asked what a term means in an annual report, to explain EBITDA, goodwill, free cash flow, working capital or diluted EPS, or to define any investing or accounting word in plain English, ideally in the context of an uploaded report. Explains each term the user gives, anchored to the specific document where one is provided. Refuses buy, sell and valuation opinions and points to the other skills in the bundle instead. Educational, not financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# investing-vocabulary-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces, per term, a one-sentence plain definition, where it appears in this document with the page, why a beginner might misread it, and one thing to check next.
