---
name: menu-cost-engineer
description: "Cost a menu item to a plate cost and food-cost percentage, then price it for a target margin. Use when asked to cost a dish, calculate food cost percentage, price a menu item, or engineer a menu for profitability."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# menu-cost-engineer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plate-cost breakdown (ingredient × yield × price), the food-cost %, a suggested price for the target margin, and menu-engineering flags (star / plow-horse / puzzle / dog) so the operator knows what to promote, reprice, or cut.
