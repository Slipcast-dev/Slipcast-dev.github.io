---
name: quarterly-tax-rhythm
description: "Build the tax habit self-employment requires — the setaside percentage from day one, the quarterly calendar, the records that make filing boring, and the no-withholding mindset shift nobody explains. Use when asked how do taxes work for my side income, how much should I set aside, what are estimated quarterly payments, or set up my freelance tax system."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# quarterly-tax-rhythm

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the setaside rule with its honest range, the quarterly rhythm calendar (jurisdiction-flagged), the five-minute-a-week records system, and the deduction-tracking habit — framing routed to a local professional for the numbers.
