# Bankruptcy Decision

Bankruptcy is neither a moral failure nor a magic reset — it's a legal tool that fits some situations and not others, buried under shame and predatory "debt relief" ads. This helps you think clearly: whether your situation is the kind it actually helps, what the main types do and don't erase, the honest trade-offs, the alternatives to weigh first, and why a real attorney consult (often free) is the essential next step — so you decide on facts, not fear.

## What This Skill Produces

- **A fit read** — whether your situation (debt type, amount, income, assets) is the kind bankruptcy meaningfully helps, or whether it wouldn't
- **The types, plainly** — the main forms (liquidation vs. reorganization/repayment) and what each does and doesn't discharge
- **The honest trade-offs** — what you typically keep (exemptions), the credit impact and how it recovers over time, and what's usually not dischargeable (many taxes, student loans, child support)
- **The alternatives to weigh first** — negotiation/settlement, a nonprofit debt-management plan, hardship programs, or simply not paying time-barred debt
- **A red-flag warning** — spotting predatory "debt relief"/settlement operations that make things worse
- **A clear next step** — consult a bankruptcy attorney (many offer free consults) and where to find nonprofit credit counseling

## Required Inputs

Ask for these if not provided:
- **The debts** — rough total and types (credit cards, medical, taxes, loans — types matter a lot)
- **Your picture** — income, essential assets (home, car), and what's threatened
- **What's driving it** — lawsuits, garnishment, just drowning in payments
- **Where** — region (exemptions and process vary by jurisdiction)

## Framework: Does It Fit — And What Else Might

1. **Check the fit.** Bankruptcy helps most with dischargeable unsecured debt and against garnishment/lawsuits — it does little for debts it can't discharge. Name the mismatch if there is one.
2. **Know what each type does.** Liquidation vs. repayment plans differ sharply in what you keep and what happens — match the situation to the type at a high level.
3. **Weigh the trade-offs honestly.** Exemptions often protect essentials; the credit hit is real but recovers; and key debts (many taxes, student loans, support) usually survive — no false comfort.
4. **Exhaust the alternatives.** Settlement, nonprofit debt-management, hardship programs, and the time-barred-debt option may fit better and cost less — consider them first.
5. **Avoid the predators.** For-profit "debt relief" and settlement mills often deepen the hole — steer to nonprofit counseling and a real attorney.
6. **Consult an attorney.** This is a legal decision with local rules and free consults widely available — that's the real next step, not a web form.

## Output Format

### Bankruptcy decision: [debt picture] · [region]

**Does it fit?** [likely helps because… / likely won't because the debts are non-dischargeable / borderline — attorney needed].
**Types, plainly:** [liquidation vs. repayment — what each does/keeps].
**Trade-offs:** [what you keep (exemptions) · credit hit + recovery · what won't discharge].
**Weigh first:** [negotiation/settlement · nonprofit debt management · hardship programs · time-barred debt].
**Avoid:** [for-profit "debt relief"/settlement mills].
**Next step:** [free bankruptcy-attorney consult · nonprofit credit counseling].

> Not legal advice — bankruptcy is jurisdiction-specific and consequential. A bankruptcy attorney (often a free consult) and nonprofit credit counseling are the right next steps.

## Quality Checks
- [ ] Assesses whether the debt types are actually dischargeable
- [ ] Explains the main types and what each keeps/discharges
- [ ] States credit impact, recovery, and non-dischargeable debts honestly
- [ ] Surfaces alternatives to weigh first
- [ ] Warns off predatory debt-relief; centers an attorney consult

## Anti-Patterns
- **Treating bankruptcy as shameful** or as a magic reset — it's neither.
- **Ignoring that key debts** (taxes, student loans, support) often survive.
- **Skipping the alternatives** that might fit better.
- **Trusting a for-profit "debt relief"** ad over nonprofit counseling.
- **Deciding without an attorney** on a legal, local matter.

## Example Trigger Phrases
- "Should I file for bankruptcy?"
- "Is bankruptcy really my best option or is there another way?"
- "What actually happens if I file, and what do I lose?"
- "What are the alternatives to bankruptcy?"
- "I'm drowning in debt — how do I decide what to do?"
