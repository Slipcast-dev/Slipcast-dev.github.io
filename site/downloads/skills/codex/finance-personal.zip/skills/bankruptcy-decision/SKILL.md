---
name: bankruptcy-decision
description: "Think clearly about whether bankruptcy is the right move, or whether another path fits better — without shame and without a sales pitch. Use when asked should I file for bankruptcy, is bankruptcy my best option, alternatives to bankruptcy, or what happens if I file. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Разделяй подтверждённые факты и допущения. Отметь вопросы, требующие проверки специалистом.
<!-- slipcast-model-profile:end -->


# bankruptcy-decision

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest read on whether your situation is the kind bankruptcy actually helps, the main types and what each does (and doesn't) discharge, the real trade-offs (what you keep, the credit impact and its recovery, what's not dischargeable), the alternatives to weigh first (negotiation, debt management, doing nothing on time-barred debt), and a strong push to consult a bankruptcy attorney.
