---
name: unit-economics
description: "Model the unit economics of a business — CAC, LTV, payback, contribution margin — from real inputs. Use when asked to calculate unit economics, work out LTV:CAC, find the payback period, or check whether a business model is viable per customer."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# unit-economics

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a computed unit-economics summary (LTV, CAC, ratio, payback, contribution margin) with a verdict and the levers that move it most.
