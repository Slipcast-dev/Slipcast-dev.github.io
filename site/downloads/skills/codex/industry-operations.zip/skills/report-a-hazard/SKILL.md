---
name: report-a-hazard
description: "Report a public hazard or code problem to the authority that can actually fix it — a pothole, broken streetlight, illegal dump, unsafe building, code violation, blocked drain — with the right department, the details that get it actioned, a tracking reference, and an escalation path if it's ignored. Use when someone says 'how do I report a pothole/hazard/violation', 'the council won't fix X', or 'who do I call about Y'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# report-a-hazard

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a report ready to submit, the right channel, and a follow-up plan.
