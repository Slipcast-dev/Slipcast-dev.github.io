---
name: cn-quality-traceability
description: "Use when asked 质量追溯体系怎么建, 产品追溯方案, 批次追溯, 一物一码, 客户要求可追溯性, 召回演练, 正向追溯和反向追溯, or plan product and batch traceability in a Chinese factory."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-quality-traceability

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a traceability plan in Chinese: the trace unit and coding rule, the data to capture at each process step (material lots, work orders, equipment, people, inspection results), forward and backward trace paths, record retention, a mock recall drill with a target time, gaps against the current system, and a phased rollout, with industry rules (food, medical devices, automotive) marked to confirm.
