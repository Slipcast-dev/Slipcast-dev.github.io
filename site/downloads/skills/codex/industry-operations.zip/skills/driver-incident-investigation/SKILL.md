---
name: driver-incident-investigation
description: "Investigate a commercial vehicle incident so the record is defensible and the cause is actually found — evidence secured in the first hours, the preventability decision made on stated criteria, and corrective action aimed at the system rather than the driver. Use when asked to investigate a vehicle accident, run a post-accident review, decide whether a collision was preventable, or write an incident report for a fleet. Not legal advice; involve your insurer and counsel early."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.
<!-- slipcast-model-profile:end -->


# driver-incident-investigation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the evidence checklist, the sequence reconstruction, the preventability determination with reasoning, the contributing-factor analysis, and the corrective actions.
