---
name: architecture-client-presentation
description: "Present a design to a client so they can make a decision rather than react to a picture — the brief restated, the moves explained against it, the options with their trade-offs, and a specific decision requested. Use when asked to present a design to a client, prepare a design review meeting, present concept options, or when a client keeps changing their mind after sign-off."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# architecture-client-presentation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the presentation structure, the brief-to-design traceability, the options with honest trade-offs, the cost and programme position, and the decision record that makes sign-off stick.
