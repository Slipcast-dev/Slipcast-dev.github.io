---
name: architectural-specification
description: "Write a specification section that a contractor can price accurately and a site can build from — performance stated, products defined, workmanship and tolerances given, and the coordination with the drawings made explicit. Use when asked to write a specification, spec a material or system, prepare an NBS-style section, or when a specification produced wildly different tender prices."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# architectural-specification

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the scope and interface definition, the performance requirements, the product or system definition, execution and tolerance requirements, and the submittals and testing schedule.
