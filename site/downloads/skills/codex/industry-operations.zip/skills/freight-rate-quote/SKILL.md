---
name: freight-rate-quote
description: "Build a freight rate that covers the cost of actually running the load — the per-mile economics, the deadhead and detention nobody prices, and the accessorials that decide whether the lane is profitable. Use when asked to quote a freight rate, price a lane, work out cost per mile, decide whether to accept a load, or explain why a lane is losing money."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# freight-rate-quote

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the fully-loaded cost per mile, the lane economics including empty miles, the accessorial schedule, the break-even and target rate, and the accept-or-decline recommendation.
