# Guest Incident Log Skill

When a guest slips, has a reaction, or complains of illness, what you write in the next hour can protect both the guest and the business — or sink it. This skill captures the facts objectively, records the response, and routes the notifications, without the speculation or apologies-as-admissions that create legal exposure.

## Working from a brief

Given what happened, **produce the full record** — capture only observed facts, mark anything reported-by-guest as such, and never invent details. Flag anything that requires immediate medical, legal, or regulatory action.

## Required Inputs

Ask for (if not provided, else infer and label):
- **What happened** — the incident type and a factual account
- **Who** — guest, staff involved, witnesses (and contact info if available)
- **When/where** and the **immediate actions** already taken

## Output Format

### Immediate response (if still unfolding)
The right-now checklist: ensure safety/medical aid, secure the area/preserve evidence (the spilled item, the food, photos), don't move hazards until documented, get witness details.

### Incident report

| Field | Detail |
|---|---|
| Date / time / location | |
| Incident type | injury / illness / foodborne / altercation / property |
| Persons involved | guest, staff, witnesses (contacts) |
| Factual account | observed facts, in sequence |
| Guest statements | quoted, marked "as reported by guest" |
| Actions taken | aid given, area secured, who was notified |
| Evidence | photos, retained item, CCTV reference |

### Notification & escalation
Who to inform and when — manager on duty, owner/GM, insurance carrier, and any mandatory reporting (a suspected foodborne illness may require the health department).

### Follow-up
Guest follow-up (care, not admission), corrective action to prevent recurrence, and where the record is retained.

## Quality Checks

- [ ] The account is factual and objective; guest claims are marked as reported, not asserted
- [ ] Witnesses and their contact details are captured while fresh
- [ ] Immediate safety/medical response is documented, and evidence preserved
- [ ] Notifications/escalation (incl. any mandatory health-dept reporting) are listed
- [ ] No admissions of fault or speculation about cause
- [ ] Follow-up includes a corrective action to prevent recurrence

## Anti-Patterns

- Speculating on cause or fault ("we should have mopped sooner") in the record
- Apologies phrased as admissions of liability
- Vague account with no times, witnesses, or actions
- Losing the evidence (throwing out the food, mopping before photos)
- Forgetting mandatory reporting for a suspected foodborne illness
- Filing it nowhere retrievable when insurance/legal needs it later

## Example Trigger Phrases

- "Write up a guest incident."
- "Log an accident."
- "Document a slip/fall."
- "Record an incident for insurance/legal."
