---
name: managing-up
description: "Work more effectively with your manager — communicate, align, escalate, and get what you need. Use when asked how to manage up, work better with a boss, get buy-in from your manager, escalate without overstepping, or prepare to raise something with leadership."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# managing-up

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a managing-up plan — what your manager needs and how they operate, how to frame your ask, what to bring vs. escalate, and the message.
