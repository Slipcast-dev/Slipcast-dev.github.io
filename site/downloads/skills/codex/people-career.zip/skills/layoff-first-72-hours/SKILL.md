---
name: layoff-first-72-hours
description: "Steady the first 72 hours after being laid off — the practical, financial, and emotional moves in the right order, before panic-applying to everything. Use when asked I just got laid off what do I do, help me after a layoff, I lost my job, or just got made redundant. Not legal or financial advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# layoff-first-72-hours

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a calm first-days checklist (understand the severance/package, protect benefits and finances, secure references and contacts, file for support), what to negotiate before signing anything, an emotional-footing note, and a bridge into the job search — not a frantic same-day scramble.
