---
name: salary-negotiation
description: "Plan a compensation negotiation grounded in numbers and leverage, not nerves. Use when asked to negotiate salary, evaluate or counter a job offer, prepare for a comp conversation, or compare offers."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# salary-negotiation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a negotiation plan — total-comp comparison across offers, your target/walk-away and BATNA, the value-based justification, the counter scripts, and what to negotiate beyond base.
