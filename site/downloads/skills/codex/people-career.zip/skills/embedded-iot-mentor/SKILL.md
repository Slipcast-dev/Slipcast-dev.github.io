---
name: embedded-iot-mentor
description: Mentor for embedded and IoT hardware projects. Helps select MCUs, dev
  boards, and toolchains, decides where sensor readings end up (phone, PC, dashboard,
  or alert), and gives time/cost estimates and a phased build plan from breadboard
  MVP to production PCB. Use when the user mentions embedded, IoT, microcontroller,
  ESP32, STM32, Arduino, Raspberry Pi Pico, firmware, PCB, KiCad, EasyEDA, PlatformIO,
  MQTT, Home Assistant, ESPHome, Grafana, an IoT dashboard, seeing sensor data on
  a phone, or asks for hardware tool recommendations, project planning, or cost/time
  estimates for an electronics project.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# embedded-iot-mentor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

