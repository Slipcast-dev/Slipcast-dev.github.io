---
name: informational-interview-prep
description: "Prepare for an informational interview — the outreach, the questions, and the follow-up — so a 20-minute chat actually helps your career instead of wasting their time. Use when asked to prep for an informational interview, questions to ask someone in [field], how to reach out for a career chat, or coffee chat prep."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# informational-interview-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a low-friction outreach message, a focused question set tuned to your goal (exploring a field, breaking in, a specific company), how to run the conversation, what NOT to do (don't ask for a job), and a follow-up that keeps the relationship warm.
