---
name: salary-benchmarking
description: "Build a defensible salary range for a role — what it actually pays given the market, location, level, and your value — so you can ask, counter, or set pay with a real number. Use when asked what should I be paid, is my salary fair, research market pay for [role], or how much to ask for. Not the same as running the negotiation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# salary-benchmarking

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured way to research the range from multiple sources, the factors that move your number (level, location, industry, skills, company size), where you likely sit in the band, and how to frame the number — flagging that pay data varies and should be triangulated, not taken from one source.
