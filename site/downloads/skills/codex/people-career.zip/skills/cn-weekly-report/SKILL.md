---
name: cn-weekly-report
description: "Write a Chinese workplace weekly or monthly report (周报 / 月报) for a manager: results with numbers, progress against goals, risks raised early, next week's plan and the support needed, in the structure Chinese managers expect. Use when asked 帮我写周报, 写月报, 整理本周工作, weekly report in Chinese, or turn my notes into a 周报."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-weekly-report

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the report in Chinese with 本周完成, 关键数据, 问题与风险, 下周计划 and 需要的支持, plus a one-line summary for chat apps.
