---
name: ask-for-a-raise
description: "Build and deliver a raise request that actually works — the evidence, the number, the timing, and the exact words — instead of hoping it gets noticed. Use when asked how do I ask for a raise, I deserve more money, prepare me to ask for a raise, or negotiate a pay increase at my job."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ask-for-a-raise

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a value case built on your actual contributions and market rate, a specific target number with justification, the right timing and person, a script for the conversation, and responses to the likely pushbacks — turning 'I want more' into a business case your manager can say yes to.
