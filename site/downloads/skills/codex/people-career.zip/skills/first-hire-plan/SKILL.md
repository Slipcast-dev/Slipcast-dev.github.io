---
name: first-hire-plan
description: "Plan your first hire — whether to hire at all yet, contractor vs employee, what role to hire, and how to do it right when you've never hired before. Use when asked to help me make my first hire, should I hire someone, contractor or employee, or how do I hire for my small business. Not legal or tax advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# first-hire-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a readiness and role read (what to hand off first), a contractor-vs-employee decision for your situation, a lightweight hiring process (role definition, sourcing, a fair evaluation, an offer), the obligations to be aware of, and onboarding basics — flagging that employment/tax/legal rules are local.
