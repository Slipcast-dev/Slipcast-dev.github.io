---
name: cn-soe-interview
description: "Prepare for recruitment at a Chinese state-owned enterprise (国企 / 央企), including its written test and interview: what these employers assess, the typical stages, answers that show fit and stability, and the questions to ask about the role. Use when asked 国企面试怎么准备, 央企校招, 国企笔试考什么, 国企和互联网怎么选, 国企面试问题, or prepare for a state-owned enterprise interview in China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# cn-soe-interview

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a stage map to confirm against the recruitment notice, a written-test preparation plan, a question bank with answer points, a mock interview with feedback, and a comparison with private-sector offers.
