---
name: federal-resume
description: "Write a US federal resume for a USAJOBS application: the long, detailed format with hours per week, grade-relevant duties and specialised experience written to the announcement's qualifications. Use when asked to write my federal resume, apply on USAJOBS, turn my private-sector resume into a government resume, or qualify for a GS grade."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# federal-resume

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the federal resume, a qualifications crosswalk against the announcement's specialised experience, and a checklist of the details USAJOBS reviewers reject applications for missing.
