---
name: cn-next-year-plan
description: "Use when asked 帮我定明年的个人 OKR, 写个人发展计划, IDP 怎么写, 明年目标怎么跟老板对齐, 个人 KPI 怎么定, 年初定目标, or plan next year's personal goals at a Chinese employer. For team or company OKRs use okr-builder; for reviewing the year just ended use cn-year-end-review."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-next-year-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces personal OKR or KPI drafts aligned upward to the team's goals with baselines, an individual development plan (个人发展计划) built on the 70-20-10 split, quarterly milestones and check-ins, and a script for the goal-setting conversation with the manager.
