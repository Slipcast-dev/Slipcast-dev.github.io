---
name: stoic-setback-debrief
description: "Recover from a professional setback — a failed launch, brutal feedback, a public mistake, a lost deal, a layoff — using the actual exercises from Marcus Aurelius' Meditations: the control sort, the evening review, and turning the obstacle into the task. Use when someone says 'today went badly', 'I blew it', 'the launch failed', 'I got torn apart in that meeting', or before replying to something that stung."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stoic-setback-debrief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured debrief that separates what happened from the story, and ends in one next action.
