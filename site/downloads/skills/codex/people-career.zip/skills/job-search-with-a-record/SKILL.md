---
name: job-search-with-a-record
description: "Run a job search when you have a criminal record — where to apply, when and how to disclose, and how to turn the question into a short, confident answer instead of a dealbreaker. Use when asked how do I get a job with a felony, when do I tell an employer about my record, ban-the-box, or explain my conviction in an interview. Not legal advice; points to reentry and legal-aid resources."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# job-search-with-a-record

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a target list of record-friendly employers and roles, a disclosure timing plan, a tight honest disclosure script (own it, pivot to now), answers to the background-check and gap questions, and the rights that protect you — so a record narrows the search without ending it.
