---
name: career-pivot-plan
description: "Build a realistic plan to change careers — mapping your transferable skills, the real gaps, and a bridge that doesn't require torching your income overnight. Use when asked to help me change careers, career pivot plan, how do I switch to [field], or I want a new career but don't know how."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# career-pivot-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a transferable-skills map, an honest gap analysis to the target role, a staged bridge (skill-building, positioning, side-door entry), a financial-runway reality check, and a narrative that reframes your background as an asset — not a starting-from-zero story.
