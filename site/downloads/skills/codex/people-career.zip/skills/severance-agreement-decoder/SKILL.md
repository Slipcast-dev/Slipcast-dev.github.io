---
name: severance-agreement-decoder
description: "Decode a severance agreement before you sign it — what you're giving up, what's negotiable, and the deadlines that decide your leverage. Use when asked to decode my severance, is this severance offer normal, review my separation agreement, or should I sign this release."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# severance-agreement-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clause-by-clause decode with ranked red flags, the money math (severance vs what you're releasing), the consideration-period clock, and the asks worth making.
