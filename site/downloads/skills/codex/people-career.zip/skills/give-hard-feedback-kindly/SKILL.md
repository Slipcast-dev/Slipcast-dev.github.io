---
name: give-hard-feedback-kindly
description: "Give someone difficult feedback — a report, a peer, a friend — so it actually lands and helps, without crushing them or dodging the point. Use when asked how do I give hard feedback, tell someone something difficult, address a problem with someone, or have a tough conversation about their [work/behavior]."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# give-hard-feedback-kindly

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on what you actually need to say (the specific behavior and its impact, not a vague vibe), a structure that's direct and kind at once, the exact opening and words, how to invite their side and land on a path forward, and the traps (sandwiching it away, going vague, making it about character).
