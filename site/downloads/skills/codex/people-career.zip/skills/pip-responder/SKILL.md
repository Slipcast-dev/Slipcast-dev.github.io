---
name: pip-responder
description: "Respond to a performance improvement plan strategically — decode what the PIP really is, decide fight-vs-land-softly with clear eyes, build the evidence file, and run the parallel job search the situation demands. Use when asked I was just put on a PIP what do I do, help me respond to a performance improvement plan, is my PIP survivable, or write my PIP check-in updates."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pip-responder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the honest read of the PIP, the two-track plan (perform + search), the documentation system, and templates for check-ins and the written response.
