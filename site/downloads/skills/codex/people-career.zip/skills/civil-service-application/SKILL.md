---
name: civil-service-application
description: "Write a UK Civil Service or NHS application: behaviour statements in the Success Profiles format, a personal statement mapped to the essential criteria, and a CV in the form these schemes expect. Use when asked to write my civil service application, answer Success Profiles behaviours, write a 250-word behaviour example, write my NHS supporting information, or apply on Civil Service Jobs or NHS Jobs."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# civil-service-application

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces each behaviour statement within the word limit using a situation, task, action, result structure, a criteria-mapped personal statement, and a check against the advert's essential criteria.
