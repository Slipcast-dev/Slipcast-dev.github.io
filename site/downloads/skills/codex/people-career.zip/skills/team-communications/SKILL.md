---
name: team-communications
description: Write internal company communications — 3P updates (Progress/Plans/Problems),
  company-wide newsletters, FAQ roundups, incident reports, leadership updates, status
  reports, project updates, and general internal comms. Use this skill any time the
  user asks to draft, edit, or format something meant for internal audiences. Trigger
  on keywords like "3P", "weekly update", "newsletter", "FAQ", "internal comms", "status
  report", "company update", "team update", "incident report", or any request to summarize
  work for leadership, teammates, or the broader company. Even casual requests like
  "write my update" or "summarize what my team did this week" should trigger this
  skill.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# team-communications

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

