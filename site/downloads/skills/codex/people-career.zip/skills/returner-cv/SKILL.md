---
name: returner-cv
description: "Write a CV for someone returning to work after a career break (caring, health, parenting, travel, redundancy or anything else), presenting the gap honestly and briefly and leading with current, relevant evidence. Use when asked how do I explain a gap on my CV, write my CV after a career break, returning to work after maternity or caring, or my CV has a two-year gap."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# returner-cv

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a CV with the break stated in one plain line, recent evidence brought forward, a short spoken answer for interviews, and a list of returnship programmes and refreshers worth checking.
