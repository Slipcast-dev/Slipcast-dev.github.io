---
name: the-org-simulator
description: "Stress-test a proposed org change before announcing it — simulate who gains, who loses, who blocks, where friction erupts in the first 90 days, and run the memo leak test: how does this land when it leaks before you announce it? Use when planning a reorg, changing reporting lines, merging or splitting teams, moving a function, or 'how will this org change land?'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-org-simulator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a winners/losers map, a friction forecast, the leak-test read, and a sequenced announcement plan.
