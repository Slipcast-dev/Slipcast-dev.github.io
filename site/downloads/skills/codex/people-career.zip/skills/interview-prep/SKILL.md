---
name: interview-prep
description: "Prepare for a specific interview at a specific company, not just 'an interview'. Use when asked to prep for an interview, prepare answers for a role, practice for a specific company's interview, or get ready for a behavioural/case/PM round."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# interview-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tailored prep pack — likely questions for this role & round, STAR-structured answers from your background, your stories mapped to their competencies, questions to ask, and the gaps to shore up.
