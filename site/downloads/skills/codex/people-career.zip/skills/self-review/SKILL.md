---
name: self-review
description: "Write a performance self-review that's specific, evidenced, and balanced. Use when asked to write a self-review, self-assessment, or self-evaluation for a performance cycle."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# self-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete self-review — accomplishments mapped to impact and competencies, growth areas owned honestly, and a forward-looking development plan, in the voice of the person being reviewed.
