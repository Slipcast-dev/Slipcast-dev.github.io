---
name: company-tailored-cv
description: "Produce a CV shaped for one target company and role: its applicant tracking system, the country's conventions, the sector's norms, its published values and the job ad, with every choice explained. Use when asked to write my CV for a specific company, tailor my CV to Google, Amazon or any named employer, make my CV fit this company's format, or turn my experience into a CV for this job. Never invents experience or insider knowledge."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# company-tailored-cv

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the tailored CV, a short format rationale citing public sources with dates, and a list of claims the person must be ready to defend.
