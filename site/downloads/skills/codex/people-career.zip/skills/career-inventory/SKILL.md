---
name: career-inventory
description: "Interview someone about their working life and turn the answers into a master CV inventory: every role, project and achievement with real numbers, before any CV is tailored. Use when asked to build my master CV, get my experience down properly, I don't know what to put on my CV, or as the first step before a tailored CV. Never invents a number."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# career-inventory

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured inventory of roles, achievements in a fixed shape with evidence and numbers, skills with proof, and a list of gaps to fill.
