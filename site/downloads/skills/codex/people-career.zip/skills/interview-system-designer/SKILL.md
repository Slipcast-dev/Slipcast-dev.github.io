---
name: interview-system-designer
description: This skill should be used when the user asks to "design interview processes",
  "create hiring pipelines", "calibrate interview loops", "generate interview questions",
  "design competency matrices", "analyze interviewer bias", "create scoring rubrics",
  "build question banks", or "optimize hiring systems". Use for designing role-specific
  interview loops, competency assessments, and hiring calibration systems.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# interview-system-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

