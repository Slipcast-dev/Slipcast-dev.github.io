---
name: reference-check-script
description: "Run a rigorous candidate reference check that surfaces real signal. Use when asked to prepare or conduct reference calls for a job candidate, design reference questions, or build a reference-check rubric."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# reference-check-script

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured question set, probing follow-ups, a red/yellow/green scoring rubric, and the legal guardrails — designed to get past 'they were great' without leading the referee.
