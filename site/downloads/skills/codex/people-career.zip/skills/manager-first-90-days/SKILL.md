---
name: manager-first-90-days
description: "Plan a new manager's first 90 days — first-time or new-to-team — as listen/decide/move phases: the 1:1 listening tour with real questions, the early-judgment traps, the quick-wins filter, and the 30/60/90 artifacts. Use when asked I just became a manager what do I do, plan my first 90 days as a manager, first-time manager advice, taking over an existing team, or new manager 30-60-90 plan."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# manager-first-90-days

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the phased plan, the listening-tour question set, the doer-to-enabler mindset shift, the team assessment framework, and the day-one and week-6 artifacts.
