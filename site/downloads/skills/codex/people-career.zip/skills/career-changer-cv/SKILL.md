---
name: career-changer-cv
description: "Write a CV for someone moving into a new field, leading with transferable evidence instead of job titles that do not match. Use when asked to write a CV for a career change, I'm moving from teaching into product, how do I present my experience for a new industry, or my job titles don't fit the jobs I want."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# career-changer-cv

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a hybrid CV with a targeted summary and a relevant-skills section backed by achievements, a translation table from old-field language to new-field language, and an honest list of gaps with how to close them.
