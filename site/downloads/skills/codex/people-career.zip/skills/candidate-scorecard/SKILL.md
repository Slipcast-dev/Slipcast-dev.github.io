---
name: candidate-scorecard
description: "Turn interview notes into a structured candidate scorecard and hire recommendation. Use when asked to write an interview scorecard, a candidate evaluation, an interview debrief, or to summarize feedback into a hire/no-hire call."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# candidate-scorecard

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a per-competency assessment with evidence and ratings, an overall recommendation with confidence, and the open questions for the next round — evidence-based, bias-aware, and decision-ready.
