---
name: cn-tech-interview-drill
description: "Use when asked 帮我准备大厂技术面试, 八股文怎么背, 模拟一面二面, 系统设计面试题, 项目深挖怎么答, 手撕算法, or run a mock technical interview for a Chinese internet company."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-tech-interview-drill

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a preparation plan for the interview rounds Chinese tech companies run (笔试, 技术一面二面, 交叉面, HR 面), a 八股 question bank by stack with answer points, a system design walkthrough, a project deep-dive script, and a mock round asked one question at a time with follow-ups (追问) and scores.
