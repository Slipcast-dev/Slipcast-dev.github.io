---
name: giving-feedback
description: "Turn a vague concern into specific, kind, actionable feedback. Use when asked to give feedback, write a feedback note, prepare to tell someone something hard about their work, or coach a report/peer."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# giving-feedback

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready-to-deliver feedback structured on situation–behaviour–impact, separating observation from judgement, with the change requested and an opening line — calibrated to praise or constructive.
