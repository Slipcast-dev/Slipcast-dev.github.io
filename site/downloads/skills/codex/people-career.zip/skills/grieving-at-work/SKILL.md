---
name: grieving-at-work
description: "Handle work while grieving — what to tell your manager and team, how much leave you can take, and how to function (or not) when you're back but not okay. Use when asked how do I tell my boss someone died, going back to work after a death, bereavement leave, or I can't focus at work while grieving. Not legal/HR advice; points to your policy, HR, and EAP."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# grieving-at-work

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a short message to tell your manager and team (with the boundary of how much to share), what to know about bereavement leave and options, a realistic re-entry plan for the first weeks back, scripts for when grief hits at work or people say the wrong thing, and how to ask for what you need — so work doesn't compound the loss.
