---
name: apprentice-first-week
description: "Plan an apprentice's or new laborer's first week so they're useful by Friday and safe from hour one — day-by-day teaching order, the safety non-negotiables stated before anything else, what they're allowed to touch unsupervised, and the check-out conversation that decides week two. Use when a tradesperson says 'my apprentice starts Monday', 'how do I train the new guy', or 'the apprentice is useless and I don't have time to teach'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# apprentice-first-week

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a first-week plan, a can/can't-touch list, and the Friday review script.
