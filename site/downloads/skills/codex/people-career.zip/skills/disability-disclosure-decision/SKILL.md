---
name: disability-disclosure-decision
description: "Decide whether, when, how, and to whom to disclose a disability or health condition at work — weighing the real benefits (accommodations, protection, honesty) against the real risks (bias, gossip), tuned to your specific situation. Use when someone says 'should I tell work about my disability/condition', 'disclose my ADHD/chronic illness at work', 'when do I tell my employer', or 'how much do I share'. Your choice throughout; it never pushes disclosure."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# disability-disclosure-decision

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a decision framework for the situation, a disclosure script if you choose to, and the minimum-disclosure options.
