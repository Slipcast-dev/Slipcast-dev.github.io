---
name: cv-docx-export
description: "Turn a finished CV into a parsing-safe Word file ready to upload: one column, real heading styles, no tables, headers or images, the right paper size, and correct fonts for Chinese, Japanese or Korean text. Use when asked to give me my CV as a Word file, export my CV to docx, make an ATS-safe CV file, or produce my 简历 as a Word document."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cv-docx-export

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the .docx file, a text read-back proving it parses, and the upload file name.
