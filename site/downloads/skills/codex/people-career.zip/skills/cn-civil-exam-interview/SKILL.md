---
name: cn-civil-exam-interview
description: "Practise the structured interview (结构化面试) for Chinese civil service and public institution posts (公务员面试 / 事业单位面试): the common question types, a clear answer structure for each, timed mock rounds and feedback on content, structure and delivery. Use when asked 公务员面试怎么准备, 结构化面试题, 帮我模拟面试, 综合分析题怎么答, 应急应变题, or practise the civil service interview."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# cn-civil-exam-interview

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a question-type guide, answer frameworks with worked examples, a timed mock interview asked one question at a time, scored feedback, and a practice plan up to the interview date.
