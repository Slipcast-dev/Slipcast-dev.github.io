---
name: recruiter-scan-simulator
description: "Simulate a busy recruiter's first scan of a CV for a specific role: what they read in the first seconds, what they decide, and why, then step out of character to say what would change the decision. Use when asked would a recruiter shortlist my CV, review my CV like a recruiter, what does a screener see first, or why am I not getting interviews."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# recruiter-scan-simulator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the in-character scan with the reading order and a shortlist, maybe or reject decision, then a debrief with the three changes most likely to flip it.
