---
name: the-promotion-committee
description: "Simulate the calibration meeting that discusses your promotion after your manager leaves the room — the debate, the packet's holes, the verdict. Use when asked will I get promoted, simulate the promo committee, stress-test my promotion packet, or why did my promo get rejected."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-promotion-committee

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the committee transcript (four archetypes on YOUR packet), the internal verdict with the real reason, and a debrief separating fixable gaps from timing politics.
