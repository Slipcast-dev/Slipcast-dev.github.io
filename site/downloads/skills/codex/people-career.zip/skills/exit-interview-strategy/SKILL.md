---
name: exit-interview-strategy
description: "Walk into an exit interview knowing what it's for, what to say, and what to keep — honest-but-strategic answers that protect references and leave the door open. Use when asked what do I say in my exit interview, should I be honest in my exit interview, prep me for my exit interview, or is the exit interview confidential."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# exit-interview-strategy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the goals-and-risks brief, prepared answers for the standard questions, the say/soften/skip sorting of your real feedback, and the scripts for the questions that are traps.
