---
name: counteroffer-decoder
description: "Decode a counteroffer after you resign — what the raise, promotion promise, or title bump really signals, the statistics-informed risks of staying, and a clear-eyed decision framework. Use when asked my company countered my resignation, should I accept a counteroffer, they offered me more to stay, or decode this retention offer."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# counteroffer-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a component-by-component decode with 🔴🟡🟢 severity, the questions that expose which promises are real, and the stay/go decision sheet.
