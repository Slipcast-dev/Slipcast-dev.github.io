---
name: driver-retention-plan
description: "Reduce driver turnover by fixing what actually makes drivers leave — the pay comparison that is real, the home-time reliability, the dispatch relationship, and the first ninety days where most departures are decided. Use when asked to improve driver retention, reduce turnover, understand why drivers are leaving, or design a driver onboarding or referral programme."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# driver-retention-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the turnover analysis by tenure and cause, the true cost of turnover, the exit-driver findings, the prioritised interventions, and the first-90-days plan.
