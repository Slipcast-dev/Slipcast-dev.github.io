---
name: future-self-interview
description: "Interview your future self about a decision or a stuck moment — a structured perspective-shift that pulls you out of present emotion and into the long view, using your own values and patterns rather than generic advice or woo. Use when someone says 'I don't know what to do', 'help me think long-term about this', 'what would future me say', or is stuck in the fog of a big decision. A structured reflection, not prediction or fortune-telling."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# future-self-interview

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an interview with your 5-or-10-years-older self, the themes it surfaces, and one concrete next step it points to.
