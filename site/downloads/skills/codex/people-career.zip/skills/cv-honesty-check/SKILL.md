---
name: cv-honesty-check
description: "Check a CV for claims that would not survive an interview, a reference or a background check: inflated titles, unprovable numbers, team results claimed as personal, date fudges and skills with no evidence. Use when asked to check my CV is accurate, will my CV hold up in an interview, is this claim too much, or as the last step before sending a CV."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cv-honesty-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a claim-by-claim risk table with the likely interview question, a safer truthful wording for each risky line, and a list of facts to verify before sending.
