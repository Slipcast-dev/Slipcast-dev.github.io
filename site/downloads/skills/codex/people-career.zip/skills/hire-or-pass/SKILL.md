---
name: hire-or-pass
description: "Turn a hiring debrief into a typed decision — hire, hire at a different level, get more signal, or pass — from rubric evidence only, with probabilities and confidence. Use when asked should we hire this candidate, run the debrief, hire or no-hire, or when interviewers disagree and the manager has to call it. Decision support for a human decision — a person owns the hire."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hire-or-pass

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the evidence state per competency, the four-way decision with probabilities, the act-or-hold verdict, and when holding, the exact competency to test and who tests it.
