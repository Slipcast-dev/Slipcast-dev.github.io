---
name: vpe-review
description: /c-level-agents:vpe-review [plan] — Throughput-first VP of Engineering
  interrogation of any plan that touches delivery, eng hiring, team structure, or
  production discipline. Use when cycle time balloons, DORA metrics slide, or before
  committing to an eng hiring wave or a reorg.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# vpe-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
