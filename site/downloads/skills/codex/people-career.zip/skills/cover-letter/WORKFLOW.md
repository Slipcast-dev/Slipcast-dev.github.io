# Cover Letter Skill

Most cover letters are throat-clearing the reader skips. A good one does one job: connect *your specific
evidence* to *this company's specific need*, in a voice that sounds like a person. This skill writes a
tight, tailored letter — no "I am writing to apply for…", no restating the resume — that earns the read.

## Required Inputs

Ask for these only if they aren't already provided:

- **The role & company** — and the job description (the letter must be specific to it).
- **Why this company** — something genuine: their product, mission, a recent move (avoids generic flattery).
- **Your 2–3 strongest, most relevant proofs** — the achievements that map to what they need.
- **Tone** — warm-professional (default), or more formal/creative per the company's culture.

## Output Format

A 3–4 paragraph letter (≈250–350 words):

> [Name] · [email] · [phone] · [date]
> Dear [hiring manager name, or "Hiring Team" if unknown],

**Hook (1 short para)** — open with a specific reason you're writing *to them* — a genuine connection to their product/mission/moment — and the role you want. No "I am writing to apply."

**Evidence (1–2 paras)** — the heart: take the role's top 2–3 needs and show, with a concrete result each, that you've done it. Map your proof to their problem; don't recap the resume — *interpret* it.

**Close (1 short para)** — what you'd bring, an honest note of enthusiasm, and a forward-looking line ("I'd love to talk about…"). Confident, not desperate.

> Sincerely, [Name]

**Voice note** (for the user): keep it human — contractions, active voice, no thesaurus words. Read it aloud; if it sounds like a robot, cut.

## Deeper Materials

- [`templates/cover-letter.md`](templates/cover-letter.md) — the four-paragraph template with anti-throat-clearing gates

## Quality Checks

- [ ] The opening is specific to this company — it could not be pasted to another employer
- [ ] Each evidence point maps a real, quantified result to one of the role's stated needs
- [ ] It complements the resume (interprets/connects) rather than repeating its bullets
- [ ] Under ~350 words; tight, scannable paragraphs
- [ ] Voice sounds like a person (contractions, active verbs), not a template
- [ ] Addressed to a named person where findable

## Anti-Patterns

- [ ] Do not open with "I am writing to apply for the position of…" — it wastes the most valuable line
- [ ] Do not restate the resume — the letter adds connection and context, not a duplicate list
- [ ] Do not use generic flattery ("your prestigious company") — name something real and specific
- [ ] Do not pad to a page — a tight 4 paragraphs beats a full page of filler
- [ ] Do not sound desperate or arrogant — aim for confident and genuinely interested

## Based On

Modern cover-letter practice — specific hook, evidence-to-need mapping, human voice.

## Example Trigger Phrases

- "Write a cover letter."
- "Write an application letter for this job."
- "Write a note to go with my CV."
- "Make my cover letter less generic."
