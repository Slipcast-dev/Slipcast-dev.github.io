---
name: cn-severance-calculator
description: "Estimate economic compensation (经济补偿金) when employment ends in mainland China: N, N+1 or 2N under the Labour Contract Law, with the high-earner cap, the part-year rule and the questions that decide which case applies. Use when asked 我被裁员了能拿多少补偿, N+1 怎么算, 经济补偿金计算, 违法解除 2N, or how much severance am I owed in China. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-severance-calculator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the scenario that likely applies and why, the calculation shown step by step, what to check before signing anything, and where to get it confirmed.
