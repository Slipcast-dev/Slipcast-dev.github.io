---
name: networking-outreach
description: "Write networking messages that actually get replies — warm, specific, and easy to say yes to — for reconnecting, cold outreach, referrals, or asking for advice. Use when asked to help me network, write a message to reconnect / to a recruiter / to someone at [company], reach out for a referral, or networking message help."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# networking-outreach

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a message tuned to the relationship and the ask, a specific and genuine hook, a low-friction request the person can easily grant, follow-up guidance, and a note on giving value — not a generic 'pick your brain' that gets ignored.
