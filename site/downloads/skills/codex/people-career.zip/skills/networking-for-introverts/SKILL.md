---
name: networking-for-introverts
description: "Network in a way that actually works for introverts — depth over breadth, one-on-one over rooms, and energy managed — instead of forcing yourself to work a crowd. Use when asked how do I network as an introvert, networking drains me, help me network without the small talk, or introvert-friendly networking."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# networking-for-introverts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an approach that plays to introvert strengths (deep 1:1 conversations, listening, follow-up, written outreach), a plan for the events you can't avoid (arrive early, one real conversation, leave), energy-management tactics, and how to build a genuine network without pretending to be an extrovert.
