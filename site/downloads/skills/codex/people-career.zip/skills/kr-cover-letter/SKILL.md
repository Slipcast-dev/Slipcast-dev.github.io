---
name: kr-cover-letter
description: "Use when asked 자기소개서 써 줘, 자소서 첨삭해 줘, 지원동기 어떻게 써, 입사 후 포부 항목, 대기업 공채 자소서, 공기업 NCS 자기소개서, or write a Korean self-introduction essay for a job application."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# kr-cover-letter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a 항목별 자기소개서 for a Korean employer: one answer per question within the character limit (공백 포함 or 제외 as specified), each with a 소제목, a 두괄식 opening and a concrete experience told as situation, action and result, tied to the job and company, plus a character count and the interview questions each answer invites.
