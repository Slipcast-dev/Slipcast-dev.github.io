---
name: executive-cv
description: "Write an executive or senior leadership CV and the matching board biography: scope, business results and governance up front, two to three pages, written for search firms and boards. Use when asked to write my executive CV, director or C-suite resume, CV for a headhunter, board bio, or non-executive director application."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# executive-cv

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the executive CV with a scope line per role, a results-led profile, a 150-word board biography in the third person, and a short brief for search consultants.
