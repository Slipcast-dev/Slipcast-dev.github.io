---
name: cn-level-mapper
description: "Compare job levels (职级) across Chinese technology companies and against international ladders, to judge an offer, a job move or a promotion target: what a level usually means in scope and expectations, how levels roughly line up, and what to ask the recruiter. Use when asked P7 相当于什么级别, 跳槽职级怎么对标, 字节 2-2 对应阿里什么, 这个 offer 的职级合理吗, compare Chinese tech levels, or how does Alibaba P-level map to Google levels."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# cn-level-mapper

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a level comparison built from the person's own ladders and offer details, a scope-and-expectation profile for each level, the negotiation questions to ask, and a clear note on what is approximate.
