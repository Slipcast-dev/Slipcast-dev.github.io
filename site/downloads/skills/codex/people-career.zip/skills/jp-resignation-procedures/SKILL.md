---
name: jp-resignation-procedures
description: "Use when asked 退職の手続き, how do I quit my job in Japan, 退職届の書き方, what happens to my health insurance and pension when I leave, 失業保険のもらい方, 有給消化, or 在日本辞职要办什么手续."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# jp-resignation-procedures

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a dated plan from giving notice to the first weeks after leaving: the resignation letter, using remaining paid leave, health insurance and pension choices with their costs, unemployment benefit steps, resident tax, and the documents to collect from the employer.
