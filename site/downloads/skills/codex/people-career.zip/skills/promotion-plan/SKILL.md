---
name: promotion-plan
description: "Plan a sale or promotion that drives revenue without wrecking margin. Use when asked to plan a promotion, a discount/sale campaign, a BFCM/holiday promo, or a product launch offer."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# promotion-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a promo plan — objective, the offer mechanic, margin math, audience & channels, timing, messaging, and how you'll measure it — so the discount is a strategy, not a reflex.
