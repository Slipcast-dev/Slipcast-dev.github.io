---
name: bilingual-cv-zh-en
description: "Produce a matched Chinese and English CV (中英文简历) from one set of facts: each version follows its own conventions rather than a literal translation, with names, titles, dates, education and company names rendered correctly in both. Use when asked for a Chinese and English resume, translate my CV into Chinese, 中英文简历, 英文简历, or apply to a foreign company in China or a Chinese company abroad."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# bilingual-cv-zh-en

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the Chinese CV, the English CV, a consistency table proving the facts match, and a glossary of the terms chosen.
