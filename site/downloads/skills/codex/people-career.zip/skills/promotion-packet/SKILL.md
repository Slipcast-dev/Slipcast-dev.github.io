---
name: promotion-packet
description: "Build a promotion case that proves you're already operating at the next level. Use when asked to write a promo packet/case, prepare for a promotion committee, or make the case for a level-up or title change."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# promotion-packet

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a promotion packet — the level-up thesis, evidence mapped to each next-level competency, scope/impact highlights, peer-quote slots, and the gaps to close before submitting.
