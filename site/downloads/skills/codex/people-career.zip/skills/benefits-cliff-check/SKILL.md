---
name: benefits-cliff-check
description: "Check whether a raise, more hours, or a new job could cost you more in lost benefits than you gain — the 'benefits cliff' — before you accept it. Use when asked will a raise hurt my benefits, benefits cliff, if I make more will I lose my food stamps or medicaid, or should I take more hours. Not financial/benefits advice; points to a benefits counselor."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# benefits-cliff-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a plain map of which benefits phase out at what income (and which cut off suddenly vs. taper), a rough read on whether a specific income change helps or hurts net, the ones with hard cliffs to watch (childcare, Medicaid, housing), the moves that soften a cliff, and where to get a real benefits screening.
