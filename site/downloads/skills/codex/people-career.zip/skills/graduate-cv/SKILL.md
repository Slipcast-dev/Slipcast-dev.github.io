---
name: graduate-cv
description: "Write a first CV for a student or recent graduate with little work experience, using coursework, projects, part-time jobs, societies and volunteering as real evidence. Use when asked to write my first CV, graduate CV, internship resume, I have no experience what do I put, or my CV for campus recruitment or a graduate scheme."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# graduate-cv

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page CV with education first, evidence-based project and activity bullets, a skills section tied to proof, and a list of quick additions that would strengthen it before deadlines.
