---
name: cn-campus-recruitment
description: "Plan a Chinese campus recruitment season (校招: 秋招 and 春招), including internships that convert to offers (实习转正): the timeline, a target company list, a one-page campus CV, online application answers, written tests and interview rounds, and choosing between offers and signing the tripartite agreement (三方协议). Use when asked 秋招怎么准备, 帮我做校招计划, 校招简历, 网申问题怎么写, 群面, 三方协议, 怎么选 offer, or plan my campus recruitment in China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# cn-campus-recruitment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a season timeline to confirm with each company, a tiered company list, a campus CV, application answer drafts, a test and interview preparation plan, and an offer comparison.
