---
name: named-persona-adversarial-review
description: Code review through the lens of real engineers' documented philosophies
  (Torvalds, Thompson, Carmack, Kent Beck, Jobs, Cagan). Complements abstract-role
  adversarial review with named, sourced perspectives. Use when automated review findings
  feel generic, when a PR has architectural or UX impact, or when the author wants
  pre-submit hardening beyond standard checks.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# named-persona-adversarial-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
