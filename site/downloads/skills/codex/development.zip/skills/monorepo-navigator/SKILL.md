---
name: monorepo-navigator
description: Navigate, manage, and optimize monorepos. Covers Turborepo, Nx, pnpm
  workspaces, and Lerna. Cross-package impact analysis, selective builds/tests on
  affected packages, remote caching, dependency graph visualization, and structured
  multi-repo to monorepo migrations. Use when setting up a new monorepo, optimizing
  CI for a large workspace, debugging cross-package dependency issues, or planning
  a multi-repo consolidation.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# monorepo-navigator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

