---
name: pr-description-live
description: Write a PR description grounded in the REAL diff — read the branch's
  actual changes via the GitHub connector, not a template the user fills in. Use when
  asked to write my PR description, describe this pull request, draft the PR body
  from my branch, or document these changes in Cowork. Reads the commits and diff
  via the GitHub connector, derives what changed and why from the code itself, and
  produces a PR-description artifact (summary, changes, testing, risk) ready to paste
  — matching the repo's PR template if one exists.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pr-description-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

