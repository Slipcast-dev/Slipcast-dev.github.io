---
name: minimalist
description: 'Use when the user asks to write code efficiently, avoid over-engineering,
  reduce dependencies, or prevent unnecessary abstractions. Enforces a strict efficiency
  ladder: YAGNI, reuse, stdlib, native platform, existing deps — before writing any
  new code.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# minimalist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

