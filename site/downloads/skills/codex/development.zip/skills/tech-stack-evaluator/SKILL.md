---
name: tech-stack-evaluator
description: Technology stack evaluation and comparison with TCO analysis, security
  assessment, and ecosystem health scoring. Use when comparing frameworks, evaluating
  technology stacks, calculating total cost of ownership, assessing migration paths,
  or analyzing ecosystem viability.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# tech-stack-evaluator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

