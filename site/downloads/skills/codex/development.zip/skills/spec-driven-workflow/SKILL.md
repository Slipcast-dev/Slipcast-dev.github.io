---
name: spec-driven-workflow
description: Use when the user asks to write specs before code, define acceptance
  criteria, plan features before implementation, generate tests from specifications,
  or follow spec-first development practices.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# spec-driven-workflow

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

