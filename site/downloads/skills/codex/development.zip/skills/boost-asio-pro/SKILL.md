---
name: boost-asio-pro
description: Use when writing or reviewing asynchronous C++ networking code with Boost.Asio
  or standalone Asio — TCP/UDP servers and clients, SSL/TLS, timers, strands, io_context,
  co_spawn, awaitable, async_read/async_write, asio::spawn, yield_context, or pre-C++20
  completion-handler callbacks.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# boost-asio-pro

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

