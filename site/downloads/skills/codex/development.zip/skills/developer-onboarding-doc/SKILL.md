---
name: developer-onboarding-doc
description: "Write a developer onboarding document for a service, codebase, or team. Use when asked to write a developer guide, service README, onboarding doc for a new engineer, codebase orientation, or getting-started guide for a technical team."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# developer-onboarding-doc

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- В исходном наборе не разрешён ресурс ./docs/decisions/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс ./docs/api/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс ./docs/runbooks/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс ./docs/cicd/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс ./docs/team/. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.

## Требования к результату

Produces a structured doc covering service overview, architecture, local setup, key patterns, testing, deployment, and who to ask for what.
