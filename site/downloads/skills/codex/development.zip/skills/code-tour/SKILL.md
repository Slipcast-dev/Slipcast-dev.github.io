---
name: code-tour
description: 'Use when the user asks to create a CodeTour .tour file — persona-targeted,
  step-by-step walkthroughs that link to real files and line numbers. Trigger for:
  create a tour, onboarding tour, architecture tour, PR review tour, explain how X
  works, vibe check, RCA tour, contributor guide, or any structured code walkthrough
  request.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# code-tour

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

