---
name: replica-recon
description: 'Reverse-engineers any app into a recon map: screen inventory, user flows,
  component list, inferred data model and a feature matrix, from public pages, screenshots,
  app store listings, help docs and the user''s own account. The first step of the
  Replica pack. Use when the user says "clone this app", "reverse engineer X", "how
  does X work", "map out X", "what screens does X have", "I want to build my own version
  of X", "copy this app", or pastes an app''s URL or App Store link and wants to rebuild
  it.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# replica-recon

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

