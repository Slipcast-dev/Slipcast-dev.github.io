---
name: bug-triage-pack
description: "Triage a raw bug report into something a team can act on — clean repro steps, a defensible severity/priority, environment, likely area/owner, and duplicate check. Use when asked to triage this bug, set severity and priority, is this a P1, or clean up this bug report for the backlog."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# bug-triage-pack

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the normalized repro, a severity and priority with the reasoning (impact × frequency × workaround), the environment/metadata, a suspected component and owner queue, and a duplicate/related-issue check — flagging when info is missing rather than guessing.
