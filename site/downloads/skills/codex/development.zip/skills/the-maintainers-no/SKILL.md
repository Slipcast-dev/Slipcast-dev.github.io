---
name: the-maintainers-no
description: "Say no as an open-source maintainer without burning contributors or yourself — the feature that doesn't fit, the PR that took someone a weekend but can't merge, the company that wants free support, the fork suggestion said kindly. Use when a maintainer says 'how do I reject this PR nicely', 'a company is demanding support', 'this feature request won't die', or is avoiding an issue thread out of guilt."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-maintainers-no

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the specific no for the situation, with reasoning shown and the relationship kept.
