---
name: replica-build
description: 'Rebuilds an app screen by screen from the recon map: app shell first,
  then the core flow as a vertical slice, then every screen with all its states, ticking
  off the feature matrix as it goes. Writes every line fresh, never the original''s
  code, assets or copy. Use when the user says "build the clone", "build screen S07",
  "start building", "rebuild this screen", "implement the booking page", or after
  /replica-design.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-build

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

