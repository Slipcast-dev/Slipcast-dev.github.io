---
name: replica-architect
description: Plans the stack, database schema and API for an app clone, from the recon
  map replica-recon wrote. Picks boring, managed tech, turns the inferred data model
  into real SQL with indexes and access rules, lists every route by flow, and orders
  the build as a thin vertical slice first. Use when the user says "plan the clone",
  "what stack should I use", "design the database", "write the schema", "plan the
  API", "architecture for my version of X", or after /replica-recon finishes.
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-architect

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

