---
name: spec-to-repo
description: 'Use when the user says ''build me an app'', ''create a project from
  this spec'', ''scaffold a new repo'', ''generate a starter'', ''turn this idea into
  code'', ''bootstrap a project'', ''I have requirements and need a codebase'', or
  provides a natural-language project specification and expects a complete, runnable
  repository. Stack-agnostic: Next.js, FastAPI, Rails, Go, Rust, Flutter, and more.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# spec-to-repo

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

