---
name: first-issue-designer
description: "Use when asked to create good first issues, prepare a repo for new contributors, turn a roadmap into starter tasks, or write issues that newcomers can actually finish. For the CONTRIBUTING guide itself, use contributor-guide."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# first-issue-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces 8 to 12 good first issues from a codebase and roadmap, each with context, acceptance criteria, files to touch and an effort estimate, plus the labels and a short pinned welcome note.
