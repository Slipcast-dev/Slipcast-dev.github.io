---
name: senior-backend
description: Designs and implements backend systems including REST APIs, microservices,
  database architectures, authentication flows, and security hardening. Use when the
  user asks to "design REST APIs", "optimize database queries", "implement authentication",
  "build microservices", "review backend code", "set up GraphQL", "handle database
  migrations", or "load test APIs". Covers Node.js/Express/Fastify development, PostgreSQL
  optimization, API security, and backend architecture patterns.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-backend

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
