---
name: saas-scaffolder
description: Generates complete, production-ready SaaS project boilerplate including
  authentication, database schemas, billing integration, API routes, and a working
  dashboard using Next.js 14+ App Router, TypeScript, Tailwind CSS, shadcn/ui, Drizzle
  ORM, and Stripe. Use when the user wants to create a new SaaS app, start a subscription-based
  web project, scaffold a Next.js application, or mentions terms like starter template,
  boilerplate, new project, or wiring up auth and payments.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# saas-scaffolder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

