---
name: dependency-check
description: "Honestly measure how dependent you've become on a tool, app, substance-free habit, or even AI itself — and reclaim the capability you've outsourced. Use when asked am I too reliant on, help me check my dependence on, could I function without, or I feel like I can't do anything without X."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dependency-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a candid read on where the reliance actually is, a low-stakes test to measure it (go without, briefly), what capability has atrophied, and a plan to rebuild the muscle — because unmeasured dependence is the dangerous kind, and the fix starts with noticing.
