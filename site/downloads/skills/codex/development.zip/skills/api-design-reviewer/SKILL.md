---
name: api-design-reviewer
description: Comprehensive REST API design review with automated linting, breaking-change
  detection, and design scorecards. Catches inconsistent conventions, missing versioning,
  and design smells before APIs ship. Use when reviewing a PR that adds or changes
  API endpoints, auditing an existing API for v2 migration, or establishing API standards
  for a team.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# api-design-reviewer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

