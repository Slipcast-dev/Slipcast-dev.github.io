---
name: explorer-viewer-builder
description: "Use when asked to build a 3D viewer for a GLB model, make an interactive explorer with clickable labelled parts, add an exploded view or quiz to a 3D model, or turn a parts list into a web page. Third step of explorer-pipeline."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# explorer-viewer-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a single-file Three.js viewer that loads GLB models, with orbit controls, clickable labelled parts, an exploded view toggle and a quiz mode, built from the tested template in references/viewer-template.html.
