---
name: senior-frontend
description: Frontend development skill for React, Next.js, TypeScript, and Tailwind
  CSS applications. Use when building React components, optimizing Next.js performance,
  analyzing bundle sizes, scaffolding frontend projects, implementing accessibility,
  or reviewing frontend code quality.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-frontend

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
