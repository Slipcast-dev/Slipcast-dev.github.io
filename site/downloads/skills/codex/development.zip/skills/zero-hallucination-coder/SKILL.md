---
name: zero-hallucination-coder
description: Runs a disciplined Discuss → Map → Decompose → Execute → Verify loop
  that grounds code in verified structure — no invented APIs, no assumed imports,
  no placeholder code — with a lazy-senior-dev YAGNI ladder that deletes unnecessary
  code before it is written. Use when a coding task is high-stakes, complex, or spans
  existing code (auth, databases, migrations, multi-file features), or when the user
  explicitly asks to plan carefully before coding, avoid hallucinated code, or work
  rigorously. Not for trivial edits, typos, or throwaway one-off scripts — those do
  not need the full loop.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# zero-hallucination-coder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

