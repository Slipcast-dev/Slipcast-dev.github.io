---
name: focused-fix
description: 'Use when the user asks to fix, debug, or make a specific feature/module/area
  work end-to-end. Triggers: ''make X work'', ''fix the Y feature'', ''the Z module
  is broken'', ''focus on [area]''. Not for quick single-bug fixes — this is for systematic
  deep-dive repair across all files and dependencies.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# focused-fix

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

