---
name: replica-backend
description: 'Builds the backend of an app clone: auth, database migrations and access
  rules, payments with Stripe, email, background jobs and third-party integrations
  through official APIs only, plus a security checklist. Use when the user says "add
  login", "set up auth", "wire up the database", "add payments", "connect Stripe",
  "add Google Calendar", "send emails", "backend for my clone", or when /replica-build
  is running on fake data.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-backend

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

