---
name: maintainer-triage
description: "Get an open-source repo's issue backlog from 400-and-drowning to triaged-and-honest in one pass — a label taxonomy that encodes decisions, batch triage rules you can apply in seconds per issue, saved replies that stay kind at scale, and stale-bot policy set with a conscience. Use when a maintainer says 'my issues are out of control', 'triage my backlog', 'set up labels for my repo', or dreads opening GitHub."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# maintainer-triage

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the taxonomy, the triage pass rules, saved replies, and a sustainable weekly routine.
