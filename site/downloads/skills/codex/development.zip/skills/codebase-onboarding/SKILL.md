---
name: codebase-onboarding
description: Analyze a codebase and generate onboarding documentation for engineers,
  tech leads, and contractors. Fast fact-gathering and repeatable onboarding outputs.
  Use when onboarding a new engineer, writing architecture-overview docs for a new
  project, or producing tech-lead briefings for unfamiliar repos.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# codebase-onboarding

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

