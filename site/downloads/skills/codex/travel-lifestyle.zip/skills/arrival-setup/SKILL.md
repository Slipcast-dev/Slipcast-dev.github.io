---
name: arrival-setup
description: "Set up the essentials in the right order after moving to a new country — the ID/registration, bank account, phone, address, and social/tax number that unlock each other — so you don't get stuck in the chicken-and-egg loops that trap newcomers. Use when someone says 'I just moved to a new country', 'what do I do first after arriving', 'set up my life in [country]', or 'I can't open a bank account without an address but can't rent without a bank'. Routes to official sources; rules are local."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# arrival-setup

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sequenced arrival checklist with dependencies and the official offices for each.
