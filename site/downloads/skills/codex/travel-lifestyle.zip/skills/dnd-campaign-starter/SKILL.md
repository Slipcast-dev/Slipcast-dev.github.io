---
name: dnd-campaign-starter
description: "Spin up a tabletop RPG one-shot or a session-zero for a new campaign — a hook, a map of the first adventure, NPCs, and encounters tuned to your party. Use when asked to start a D&D campaign, run a one-shot, help me DM, session zero, or make me an adventure for my party."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dnd-campaign-starter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a premise and hook, a session-zero framework (tone, safety tools, expectations), a first-adventure outline with beats and branches, ready-to-run NPCs and encounters scaled to party level/size, and improv fallbacks for when players go off-script.
