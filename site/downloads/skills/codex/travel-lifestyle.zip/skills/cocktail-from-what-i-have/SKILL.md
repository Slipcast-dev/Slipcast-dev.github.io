---
name: cocktail-from-what-i-have
description: "Make a genuinely good drink from the bottles already on your shelf — no special trip, no 12-ingredient recipe. Use when asked what can I make with [spirits], cocktail from what I have, I've got [bottles] what can I drink, or make me a drink without buying anything."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cocktail-from-what-i-have

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces two or three cocktails you can build right now with ratios, a method, sensible substitutions for what you're missing, and a zero-proof version — scaled to how many you're making.
