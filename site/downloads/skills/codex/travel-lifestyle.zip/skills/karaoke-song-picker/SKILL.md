---
name: karaoke-song-picker
description: "Pick the karaoke song that actually fits your voice and the room — so you land it instead of dying on a key change. Use when asked what karaoke song should I sing, pick me a karaoke song, what should I sing for [occasion], or a song for my voice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# karaoke-song-picker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a few tailored song picks matched to your range and skill, why each works (and the tricky bit to watch), a crowd-pleaser vs a show-off pick, a group/duet option, and a safe fallback for when nerves hit.
