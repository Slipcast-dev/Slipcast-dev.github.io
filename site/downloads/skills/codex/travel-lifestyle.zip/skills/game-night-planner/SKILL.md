---
name: game-night-planner
description: "Plan a game night that actually works for the specific people coming — the right lineup for player count, weight tolerance, and time, sequenced from icebreaker to main event, with the fallback for when someone bails. Use when someone says planning a game night, what board game should we play, games for six people, my partner hates long games, or we always end up arguing over what to play."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# game-night-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sequenced lineup with reasoning, teach-time and play-time estimates, swaps for the non-gamers, and a plan B.
