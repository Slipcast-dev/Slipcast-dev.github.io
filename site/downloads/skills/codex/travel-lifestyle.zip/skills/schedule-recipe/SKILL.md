---
name: schedule-recipe
description: "Turn 'run this every Friday at 4pm' into a working, copy-paste schedule on the user's actual runner. Use when asked to schedule a recurring AI task, set up a routine or cron job for a skill, automate a weekly report, or wire a skill into n8n or GitHub Actions."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# schedule-recipe

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the exact setup for the chosen runner plus the prompt to run, failure alerting, and a first-run test plan.
