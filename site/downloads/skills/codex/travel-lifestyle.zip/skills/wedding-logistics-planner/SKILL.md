---
name: wedding-logistics-planner
description: "Plan the wedding day as the operation it is — the minute-level run sheet, the vendor call sheet, the who-handles-problems roster, and the buffer discipline that keeps the couple out of logistics on the day. Use when asked make our wedding day timeline, day-of run sheet, who tells the vendors where to go, or how do we not deal with problems at our own wedding."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wedding-logistics-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the run sheet with buffers, the vendor call sheet, the delegation roster with a named day-of decision-maker, and the contingency cards for the classic failures.
