---
name: travel-brief
description: "Turn a business trip into a one-page brief that runs itself — the itinerary with buffers and failure modes, the meeting logistics pre-solved (addresses, contacts, backup numbers), the packing-and-prep list by trip type, and the expense capture set up before departure. Use when asked prep my business trip, build the travel brief, I always forget something when traveling, or organize this three-city week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# travel-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the one-page brief: timeline with buffers, the per-meeting logistics, the contingency card, and the expense setup.
