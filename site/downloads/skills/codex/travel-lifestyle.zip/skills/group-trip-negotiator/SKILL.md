---
name: group-trip-negotiator
description: "Save the group trip from the group chat — budget alignment before anything gets booked (the awkward conversation, scripted), a decision protocol that actually books things, cost-splitting rules with real numbers for unequal rooms and champagne-taste friends, and the it's-okay-to-split-up daytime clause. Use when someone says 'we're planning a trip with friends and it's chaos', 'how do we split costs', 'one friend wants luxury and one is broke', or the trip has been 'being planned' for three months."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# group-trip-negotiator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the budget-alignment script, the decision protocol, and the money agreement.
