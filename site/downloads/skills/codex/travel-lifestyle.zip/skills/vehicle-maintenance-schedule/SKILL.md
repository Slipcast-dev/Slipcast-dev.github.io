---
name: vehicle-maintenance-schedule
description: "Build a maintenance schedule for your car so it stays reliable and holds value — the service intervals, the DIY-vs-shop split, and the checks that prevent breakdowns and rip-offs. Use when asked for a car maintenance schedule, what maintenance does my car need, how to keep my car running, or am I being upsold at the mechanic."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# vehicle-maintenance-schedule

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an interval-based schedule keyed to your vehicle and driving, the essential do-not-skip items, DIY vs professional, seasonal checks, and how to spot unnecessary upsells — flagging that your owner's manual is the authority.
