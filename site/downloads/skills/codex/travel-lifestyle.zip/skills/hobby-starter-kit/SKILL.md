---
name: hobby-starter-kit
description: "Turn 'I want to try [hobby]' into a real first month — the minimal starter gear, the first skills to practice, and a beginner-friendly plan that survives contact with real life. Use when asked how do I start [hobby], I want to get into [activity], what do I need to begin, or help me pick up a new hobby."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hobby-starter-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a cheap-as-possible starter kit (buy now vs buy later), a first-30-days progression, where to learn and find a community, and the honest quitting-points to plan around so you actually stick with it.
