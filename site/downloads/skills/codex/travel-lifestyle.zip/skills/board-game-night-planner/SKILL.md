---
name: board-game-night-planner
description: "Plan a board game night that actually lands — the right games for your group size, mix, and time, in a running order that keeps energy up. Use when asked to plan a game night, what board game should we play, games for [N] people, or what to play with a mixed group."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# board-game-night-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces game picks matched to player count and experience, a warm-up-to-main running order, teach-time and play-time estimates, and swaps for the non-gamers or the one player who hates losing.
