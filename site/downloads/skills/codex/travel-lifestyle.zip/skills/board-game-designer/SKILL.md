---
name: board-game-designer
description: "Take a board game idea from 'wouldn't it be cool if' to a playtestable prototype — core loop, tension source, components you can make tonight, balance starting-points, and a real playtest protocol with kill criteria. Use when someone says 'I have a board game idea', 'design a game about X', 'my game drags in the midgame', or 'how do I playtest this'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# board-game-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a design one-pager, a print-and-play prototype spec, and a 3-session playtest plan.
