---
name: tabletop-negotiator
description: "Practice the table-talk that wins negotiation board games — play out a Catan-style trade, a Diplomacy-style alliance, or a Monopoly-style deal against an opponent with a hidden agenda, then get an out-of-character debrief scoring your moves. Use when someone says 'I always lose the trading part', 'practice Catan trades with me', 'how do I get better at Diplomacy', or 'roleplay a trade with me'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# tabletop-negotiator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a played-out negotiation plus a debrief with the reads you missed and one habit to change.
