---
name: whats-for-dinner
description: "Decide what to cook tonight from what you already have and how much time/energy you've got — no shopping trip, no recipe rabbit hole. Use when asked what should I make for dinner, what can I cook with what's in my fridge, quick dinner ideas, or I don't know what to eat."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# whats-for-dinner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces 3 doable options ranked by effort with a quick method for each, honest substitutions, and a 'need one thing' flag if a near-miss is worth a corner-shop run — respecting diets and dislikes.
