---
name: trip-planner
description: "Turn a destination, some dates, and your vibe into a realistic day-by-day trip itinerary — paced for real humans, with a packing list and a rough budget. Use when asked to plan a trip, build a travel itinerary, what should I do in [place], or help me plan my holiday."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# trip-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a day-by-day plan grouped by area (so you're not criss-crossing the city), must-book-ahead flags, a packing list tuned to the trip, a rough budget range, and honest notes on pace and gaps to fill with local info.
