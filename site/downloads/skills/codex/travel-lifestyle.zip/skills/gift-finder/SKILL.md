---
name: gift-finder
description: "Find a genuinely good gift for a specific person and occasion within a budget — thoughtful and non-obvious, not a generic 'top 10 gifts' list. Use when asked for gift ideas, what should I get [person], help me find a present, or I have no idea what to buy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# gift-finder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a short set of tailored ideas across price points, why each fits this person, where to get it and rough price, a safe backup, and an honest flag when you need one more detail to nail it.
