---
name: wine-pairing
description: "Pick a wine that flatters tonight's meal — at your budget, from what's actually available — without the sommelier mystique. Use when asked what wine goes with [dish], help me pick a wine, what should I drink with dinner, or recommend a bottle for."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# wine-pairing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a couple of specific bottle styles (not just 'a red'), why each works with the dish, a budget-tier pick, an easy-to-find fallback, and a non-alcoholic option — with a plain reason you can remember next time.
