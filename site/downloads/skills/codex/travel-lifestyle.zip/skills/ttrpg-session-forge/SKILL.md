---
name: ttrpg-session-forge
description: "Prep tonight's TTRPG session in 30 minutes — three scenes with stakes, NPC voice cards, a flexible encounter, treasure/clues, and the 'players did something insane' toolkit — plus session-zero safety tools for new tables. Use when a game master says 'prep my D&D session', 'my players derailed everything', 'I need an NPC on the fly', or 'help me start a campaign'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ttrpg-session-forge

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page session plan built to survive contact with the players.
