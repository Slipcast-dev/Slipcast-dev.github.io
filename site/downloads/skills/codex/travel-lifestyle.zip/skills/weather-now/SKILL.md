---
name: weather-now
description: "Get current weather and forecasts with zero API keys — wttr.in one-liners for humans, Open-Meteo JSON for data, with the exact curl commands and format codes. Use when asked what's the weather, will it rain today, forecast for a city, or get me weather data for a location."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# weather-now

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the live conditions or forecast pulled via curl, interpreted plainly, with the source timestamp and the command used shown so the user can rerun it.
