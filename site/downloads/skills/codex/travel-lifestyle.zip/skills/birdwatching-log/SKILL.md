---
name: birdwatching-log
description: "Get started birding from where you are — what you're likely to see, how to tell confusing species apart, and a simple life-list to track sightings. Use when asked to start birdwatching, what bird did I see, help me identify a bird, or set up a birding log."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# birdwatching-log

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a likely-species list for your area and season, ID prompts (the field marks and sounds that separate look-alikes), a beginner gear-and-timing note, and a lightweight life-list format — pointing you to a live ID app to confirm any specific sighting.
