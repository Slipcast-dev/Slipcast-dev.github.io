---
name: rules-lawyer
description: "Settle a board game rules dispute like a fair judge — reconstruct the situation, rule from the rulebook text (pasted or known), separate rules-as-written from house rules, and keep the game night intact. Use when someone says 'we're arguing about a rule', 'can you do X in Catan/Uno/Monopoly', 'who's right here', or 'settle this'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rules-lawyer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a table ruling with its reasoning, a rules-as-written vs house-rule distinction, and a keep-the-peace line to read aloud.
