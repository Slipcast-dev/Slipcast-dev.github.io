---
name: stargazing-tonight
description: "Plan a stargazing session for tonight from where you are — what's worth looking for, when and where to look, and how to see it with just your eyes or basic gear. Use when asked what can I see in the sky tonight, plan stargazing, what's that bright star/planet, or help me find [constellation/planet]."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stargazing-tonight

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a target list suited to your location, date, and light pollution, a simple when/where-to-look guide, naked-eye vs binocular/telescope notes, and viewing conditions to check — flagging that positions change, so confirm with a live sky app.
