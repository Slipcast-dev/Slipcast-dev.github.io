# Модели, MCP и рабочие процессы агентов / Models, MCP and agent workflows · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Совместимость MCP, проверка промптов на разных моделях, передача задач между агентами.

MCP compatibility, prompt regression across models, agent handoffs.

Рекомендуемый порядок / Suggested order:

1. [mcp-tool-contract-check](skills/mcp-tool-contract-check/SKILL.md)
2. [prompt-model-regression](skills/prompt-model-regression/SKILL.md)
3. [agent-handoff-evidence](skills/agent-handoff-evidence/SKILL.md)
