# Telegram и проверка источников / Telegram editing and source verification · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Посты и дайджесты Telegram, проверка цитат и ссылок.

Telegram posts and digests, quotation and link verification.

Рекомендуемый порядок / Suggested order:

1. [quotation-source-verification](skills/quotation-source-verification/SKILL.md)
2. [telegram-editorial-adaptation](skills/telegram-editorial-adaptation/SKILL.md)
