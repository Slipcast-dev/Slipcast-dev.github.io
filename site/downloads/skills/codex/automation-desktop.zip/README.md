# Автоматизация macOS и Windows / macOS and Windows automation · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Команды Shortcuts, AppleScript и PowerShell для рабочих задач.

Everyday workflows with Shortcuts, AppleScript and PowerShell.

Выберите скилл под задачу / Choose a skill for your task:

- [macos-applescript-workflow](skills/macos-applescript-workflow/SKILL.md)
- [macos-shortcuts-workflow](skills/macos-shortcuts-workflow/SKILL.md)
- [windows-powershell-workflow](skills/windows-powershell-workflow/SKILL.md)
