# Автоматизация файлов и документов / File and document automation · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Пакетное переименование, сортировка, преобразование PDF и CSV.

Batch renaming, file organization, PDF and CSV conversion.

Выберите скилл под задачу / Choose a skill for your task:

- [batch-file-rename-plan](skills/batch-file-rename-plan/SKILL.md)
- [file-routing-by-rules](skills/file-routing-by-rules/SKILL.md)
- [pdf-csv-batch-conversion](skills/pdf-csv-batch-conversion/SKILL.md)
