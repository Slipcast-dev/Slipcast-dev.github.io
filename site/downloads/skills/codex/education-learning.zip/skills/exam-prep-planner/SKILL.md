---
name: exam-prep-planner
description: "Build a realistic exam-prep schedule with spaced repetition and retrieval practice — the plan that survives contact with an actual week. Use when asked to plan my exam prep, make a study schedule, I have N weeks until finals, or how do I study for multiple exams."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# exam-prep-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a day-by-day plan across all exams: spaced blocks, retrieval-first sessions, weak-topic weighting, and built-in slack for the days that go wrong.
