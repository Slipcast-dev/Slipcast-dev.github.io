---
name: reading-retention-system
description: "Actually remember and use what you read — an active-reading system that beats the highlight-and-forget cycle. Use when asked how do I remember what I read, I forget books right after finishing, help me retain what I study, or take better reading notes."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# reading-retention-system

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an active-reading method (questions before, engagement during, retrieval after), a lightweight note format that captures the few ideas worth keeping, a spaced review touch, and how to actually apply what you read — turning passive consumption into knowledge you keep.
