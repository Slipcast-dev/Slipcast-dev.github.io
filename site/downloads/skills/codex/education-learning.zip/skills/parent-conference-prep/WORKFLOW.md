# Parent Conference Prep Skill

Parents remember how a conference *felt* more than the data in it. The teachers who land hard messages lead with genuine strengths, bring specifics instead of labels, and leave the parent with a partnership, not a verdict. This skill preps the whole conversation — including the reaction you're bracing for.

> **Not quite this?** Use `parent-teacher-conference-prep` when you are the parent getting ready for the meeting.

## Working from a brief

Given the student and the reason for the conference, **write the full prep** — infer likely parent concerns from the situation. Keep it partnership-framed: the teacher and parent on the same side of the table, the challenge on the other.

## Required Inputs

Ask for (if not provided, else infer and label):
- **Grade** and the **reason** for the conference (routine, grades, behavior, a specific incident)
- **The student's strengths** and the **concern**, with any specific examples
- **Anything known about the parent** (prior contact, sensitivities, language needs)

## Output Format

### Agenda (the arc)
Open warm → strengths with evidence → the concern (specific, non-labeling) → what we'll each do → close on partnership. With rough timing for a ~15–20 min slot.

### Strengths first
2–3 genuine strengths, each with a **specific example** (not "he's a good kid").

### The concern, said well
The hard message scripted: describe the behavior/pattern with evidence, not a character label ("I've seen him leave three assignments unfinished this week" — not "he's lazy"). Name the impact, then pivot to the plan.

### Anticipated reactions
The likely parent responses (defensiveness, blame, overwhelm, disengagement) and a calm, non-escalating reply for each.

### Next steps
2–3 concrete, shared actions — what the teacher will do, what the parent can do, and when you'll check back.

## Quality Checks

- [ ] Opens with genuine, specific strengths before any concern
- [ ] The concern is described with evidence and impact, never a character label
- [ ] At least two anticipated reactions have a prepared, de-escalating response
- [ ] Next steps are shared, concrete, and have a check-back
- [ ] Tone is partnership, not verdict; jargon is translated to plain language

## Anti-Patterns

- Leading with the problem before any strength
- Labels ("lazy," "disruptive," "unmotivated") instead of observed behavior
- Dumping data with no plan or partnership
- No plan for the defensive or upset reaction
- Education jargon (RTI, standards codes) left untranslated for the parent

## Example Trigger Phrases

- "Prep for a parent conference."
- "Plan what to say to a parent."
- "Handle a difficult conversation about a student's behavior."
