---
name: parent-conference-prep
description: "Prepare for a K-12 parent-teacher conference — including the hard ones. Use when asked to prep for a parent conference, plan what to say to a parent, or handle a difficult conversation about a student's behavior or grades."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# parent-conference-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured agenda, strengths-first talking points backed by specific evidence, a plan for the tough message, anticipated parent reactions with responses, and agreed next steps.
