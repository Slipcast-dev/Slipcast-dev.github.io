---
name: feynman-explainer
description: "Learn something deeply by trying to explain it simply — the Feynman technique — surfacing exactly the gaps where your understanding is fake. Use when asked help me really understand X, explain this back to check my understanding, use the Feynman technique on, or do I actually get this."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# feynman-explainer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a prompt to explain the concept in plain language yourself, a check that flags where your explanation went vague, hand-wavy, or jargon-hid a gap, the specific things you don't actually understand yet, and how to close each — because if you can't explain it simply, you don't really know it.
