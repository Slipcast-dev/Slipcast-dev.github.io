---
name: college-app-parent-guide
description: "Support a teenager through college applications without taking them over — the parent's actual jobs (logistics, finances, emotional ballast), the ownership lines that keep the application theirs, and the scripts for the hard moments. Use when asked how do I help my kid with college apps, how involved should I be, my teenager won't start their essays, or we disagree about the college list."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# college-app-parent-guide

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the role split, the family timeline, the money conversation framework, and the scripts for deadlock, rejection, and the essay you must not write.
