---
name: learn-anything-roadmap
description: "Turn 'I want to learn X' into a realistic, staged roadmap — the fundamentals to master first, the order that avoids overwhelm, and the milestones that prove progress. Use when asked how do I learn [skill], make me a learning plan for, where do I start with learning, or roadmap to learn X."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# learn-anything-roadmap

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a staged path from beginner to capable (fundamentals → building blocks → real application), the highest-leverage things to learn first, the traps and dead-ends to skip, milestones to measure progress, and the best resource types for each stage — tuned to your goal and time.
