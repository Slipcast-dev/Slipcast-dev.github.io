---
name: personal-statement
description: "Write a personal statement for a university, grad-school, or job application that's specific, coherent, and unmistakably you — showing fit and motivation, not a résumé in prose. Use when asked to write my personal statement, help with my university/grad application essay, statement of purpose, or make my personal statement stronger."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# personal-statement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read of what this program/role wants, a clear through-line (your motivation and fit), a structure that shows rather than lists, evidence from your real experience, and an authentic voice — drawing it out of you, not inventing a story.
