---
name: deliberate-practice-plan
description: "Design deliberate practice that actually builds a skill — targeted, effortful, feedback-driven — instead of mindless repetition that just entrenches your current level. Use when asked how do I practice X effectively, my practice isn't working, design a practice routine, or deliberate practice for."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# deliberate-practice-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a breakdown of the skill into trainable sub-skills, drills that target your specific weaknesses at the edge of your ability, a feedback mechanism, and a session structure — because time spent practicing is not the same as time spent improving.
