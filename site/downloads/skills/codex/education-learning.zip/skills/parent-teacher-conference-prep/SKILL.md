---
name: parent-teacher-conference-prep
description: "Get real information out of a 15-minute parent-teacher conference — the questions that beat 'how's she doing', the data to bring from home, and the follow-up that makes the meeting matter. Use when asked prepare me for the parent teacher conference, what should I ask my kid's teacher, the conference is 15 minutes what do I prioritize, or how do I raise a concern without making it adversarial."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# parent-teacher-conference-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the prioritized question list, the home-observations brief, the concern-raising scripts, and the follow-up plan with owners.
