---
name: cn-gaokao-planner
description: "Help a student and family plan university applications after the 高考 (gaokao): use the student's provincial rank rather than raw score, build a 冲 / 稳 / 保 (reach, match, safe) list from official historical admission data, check subject requirements under the new gaokao, and weigh major against university. Use when asked 帮我填高考志愿, 志愿怎么填, 冲稳保怎么排, 这个分数能上什么学校, or plan gaokao applications. Never guarantees admission."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-gaokao-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured application list with the reasoning for each choice, a risk check of the whole list, and the questions to settle as a family.
