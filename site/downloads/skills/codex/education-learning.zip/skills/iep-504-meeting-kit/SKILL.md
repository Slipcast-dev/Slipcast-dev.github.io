---
name: iep-504-meeting-kit
description: "Walk into an IEP or 504 meeting prepared and effective — the process decoded in plain language, the parent-input statement that gets read, the questions that make goals measurable, and advocacy that stays collaborative. Use when asked prepare me for my child's IEP meeting, what's the difference between an IEP and a 504, how do I disagree with the school's plan, or make sure the accommodations actually happen."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# iep-504-meeting-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the process map, the parent-input statement, the goal-quality checklist, the meeting scripts, and the paper-trail habits.
