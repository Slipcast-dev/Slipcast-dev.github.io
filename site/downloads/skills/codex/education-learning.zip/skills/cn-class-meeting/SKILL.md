---
name: cn-class-meeting
description: "Use when asked 帮我设计一节班会, 主题班会方案, 班会课教案, 开学第一课, 安全教育班会, 心理健康班会, or plan a class meeting as a 班主任."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-class-meeting

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a 主题班会 plan in Chinese with the background and goals, preparation, a timed sequence of student-led activities, discussion questions, the 班主任's closing words, follow-up actions for the following weeks, and notes for sensitive topics.
