---
name: cn-homework-helper-parent
description: "Use when asked 孩子这道题不会怎么教, 辅导作业总发火, 怎么给孩子讲应用题, 陪写作业, 作业太多写到很晚, or help a parent guide (not do) a child's homework in China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-homework-helper-parent

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces, for the specific question, an age-appropriate way to explain it with guiding questions in order, a hint ladder that stops before the answer, a similar practice item, what to do if the child is stuck or upset, and a homework routine, written for the parent in Chinese; it never hands over a finished answer for the child to copy.
