---
name: iep-goal-support
description: "Draft SMART IEP goals, accommodations, and present-levels statements that are measurable and compliant in spirit. Use when asked to write an IEP goal, draft special-education goals, list accommodations, or write a present-levels (PLAAFP) statement. A drafting aid for educators — not legal advice; the IEP team and local requirements govern."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# iep-goal-support

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces measurable annual goals with baselines, criteria, and measurement methods, plus matched accommodations.
