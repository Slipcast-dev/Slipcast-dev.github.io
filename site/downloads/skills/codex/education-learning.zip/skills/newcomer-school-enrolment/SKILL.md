---
name: newcomer-school-enrolment
description: "Get a child into school after moving to a new country: who to contact, the documents schools ask for, what to do when papers are missing, language support, and the right to a place. Use when someone says 'we just moved, how do I enrol my child in school', 'the school wants documents we don't have', 'my child doesn't speak the language yet', or 'which school can my kid go to here'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# newcomer-school-enrolment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an enrolment plan in order, a document checklist with fallbacks for missing papers, questions to ask the school, and a first-weeks support plan.
