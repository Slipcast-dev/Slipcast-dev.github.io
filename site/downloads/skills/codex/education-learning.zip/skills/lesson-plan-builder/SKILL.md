---
name: lesson-plan-builder
description: "Build a standards-aligned K-12 lesson plan with clear objectives, a timed activity sequence, checks for understanding, and differentiation. Use when asked to plan a lesson, write a lesson plan, align a lesson to a standard, or turn a topic into a class period."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# lesson-plan-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces measurable objectives, a bell-to-bell timeline (hook → instruction → practice → close), formative checks, differentiation for varied learners, and the materials list.
