---
name: college-cost
description: "Compute what a degree will actually cost — sticker minus real aid, inflated per year, split into cash and loans, with the loan's decade-long monthly tail made visible before enrollment instead of after. Use when asked what will college really cost, compare these two offers' real prices, how much loan payment after graduation, or is this school affordable."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# college-cost

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the all-in number from the script, the offer-letter decode (grants vs loans untangled), the monthly-tail reality check, and the two-school comparison.
