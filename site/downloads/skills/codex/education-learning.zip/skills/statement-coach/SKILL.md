---
name: statement-coach
description: "Coach a statement of purpose or personal essay to admission strength — structural diagnosis, specific feedback, and revision plans on YOUR draft; the words stay yours. Use when asked to review my personal statement, improve my SOP, give feedback on my application essay, or why is my essay generic."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# statement-coach

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a diagnostic against what committees actually read for, line-level feedback on the draft, a revision plan, and interview-style questions to mine for better material.
