---
name: teach-me-in-layers
description: "Learn a complex topic in progressive layers — a one-sentence version, then a paragraph, then the real depth — so you build a mental scaffold instead of drowning in detail. Use when asked explain this in layers, teach me X from simple to deep, I need to understand this progressively, or start simple then go deeper."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# teach-me-in-layers

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a topic explained at escalating depth (ELI5 → informed-adult → the real thing), each layer building on the last, checkpoints to make sure a layer landed before the next, and where to stop for your actual need — so you never get lost in detail without a frame to hang it on.
