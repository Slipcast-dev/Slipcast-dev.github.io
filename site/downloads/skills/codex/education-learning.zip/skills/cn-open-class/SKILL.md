---
name: cn-open-class
description: "Use when asked 公开课怎么准备, 帮我写说课稿, 优质课比赛, 评优课, 教研课, 汇报课, 青年教师赛课, 试讲, or prepare an observed lesson in a Chinese school."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-open-class

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a 公开课 preparation pack in Chinese: a 说课稿 (说教材, 说学情, 说教学目标, 说重难点, 说教法学法, 说教学过程, 说板书) timed to the required length, the lesson's highlights (亮点) and how observers will see them, a rehearsal and 磨课 plan, contingency plans, and answers to likely 评课 questions.
