---
name: thesis-outline
description: "Build a defensible thesis or dissertation outline — argument-first structure, chapter by chapter, with the through-line visible. Use when asked to outline my thesis, structure my dissertation, plan my capstone, or organize my research into chapters."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# thesis-outline

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a full outline: the one-sentence thesis, chapter map with each chapter's job and claim, evidence allocation, and the risk register of weak links an examiner would probe.
