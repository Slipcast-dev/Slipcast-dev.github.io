---
name: iep-goal-writer
description: "Write measurable IEP goals and matching accommodations for a K-12 student with an IEP or 504 plan. Use when asked to write an IEP goal, draft annual goals, make a goal measurable, or list accommodations."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# iep-goal-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces SMART annual goals (baseline, condition, behavior, criterion, measurement) with short-term objectives and a set of accommodations tied to the student's needs — written to be legally defensible and progress-monitorable.
