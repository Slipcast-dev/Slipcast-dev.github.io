---
name: scholarship-essay
description: "Write a scholarship essay that stands out — a genuine, specific story that answers the prompt and shows why you deserve the award, without clichés. Use when asked to help with a scholarship essay, write my scholarship application, essay about why I deserve this scholarship, or make my application essay stronger."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# scholarship-essay

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read of the prompt and what the committee is really looking for, a strong angle drawn from your real story, a structure that hooks and builds, specifics over platitudes, and a voice that's authentically yours — guiding you to write it, not fabricating experiences you didn't have.
