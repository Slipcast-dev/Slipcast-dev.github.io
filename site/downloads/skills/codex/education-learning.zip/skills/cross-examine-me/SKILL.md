---
name: cross-examine-me
description: "Stress-test a decision or claim through a sharp, fair Q&A — the questions a good lawyer or skeptical friend would ask before you commit. Use when asked to cross-examine me, ask me hard questions about this, interrogate my plan, or make me defend this."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cross-examine-me

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sequenced line of probing questions (from clarifying to challenging to the killer question), space to answer, and a debrief on where your answers were strong, evasive, or exposed a gap — so weaknesses surface in private before they surface in public.
