---
name: chess-opening-coach
description: "Build a small, coherent opening repertoire that fits your style and level — the few lines actually worth learning, plus the plans and traps behind them. Use when asked what chess opening should I learn, build me a repertoire, help with my openings, or what to play against [opening]."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# chess-opening-coach

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a compact repertoire for White and Black keyed to your rating and style, the main ideas and typical plans (not just moves to memorize), the common traps to know from both sides, and what to study next — kept small enough to actually learn.
