---
name: language-learning-plan
description: "Build a realistic plan to learn a language for your actual goal — travel, conversation, work, or fluency — focused on what moves the needle instead of endless app streaks. Use when asked to help me learn [language], make a language learning plan, how do I get conversational, or study a language efficiently."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# language-learning-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a goal-and-level read, a prioritized plan (the high-frequency vocab and core patterns first), a daily/weekly routine mixing input, speaking, and review, how to get real practice and feedback, milestones, and honest expectations — not a promise of fluency in a month.
