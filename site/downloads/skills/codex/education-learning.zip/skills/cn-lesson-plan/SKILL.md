---
name: cn-lesson-plan
description: "Use when asked 帮我写教案, 写一份新课标教案, 教学设计, 单元教学设计, 大单元教案, or a lesson plan in the format Chinese schools expect."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-lesson-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete 教案 in Chinese with 教材分析, 学情分析, 教学目标 tied to the subject's 核心素养, 教学重难点, 教学方法, a timed 教学过程 with teacher and student activity, 板书设计, layered 作业设计 within the 双减 time limits, and 教学反思 prompts, with curriculum references marked to confirm against the current 课程标准.
