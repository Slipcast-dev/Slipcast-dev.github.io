---
name: learn-from-a-project
description: "Design a real project to learn a skill by building something — the fastest way to actually get good, instead of endless tutorials. Use when asked I'm stuck in tutorial hell, what project should I build to learn, learn by doing, or a project to practice X."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# learn-from-a-project

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a project scoped to your level that forces the skills you want to learn, a breakdown into buildable milestones, the specific skills each milestone teaches, where to get help without copying, and a stretch to grow into — because you learn a skill by using it on something real, not by watching more tutorials.
