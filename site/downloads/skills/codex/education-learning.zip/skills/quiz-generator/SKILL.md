---
name: quiz-generator
description: "Generate a quiz or test on any topic with a balanced mix of question types and difficulty, plus a complete answer key with explanations. Use when asked to create a quiz, write a test, make practice questions, or build an assessment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# quiz-generator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces well-formed questions aligned to learning objectives, tagged by difficulty and cognitive level, with an answer key and (for MCQs) plausible distractors and rationale.
