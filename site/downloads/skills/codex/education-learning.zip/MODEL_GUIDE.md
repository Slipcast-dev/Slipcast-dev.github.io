# Модели / Models

Выберите модель в своей сессии. Доступ зависит от клиента, тарифа и организации.

Choose a model in your session. Availability depends on your client, plan, and organization.

| Задача / Work | Рекомендуемая модель / Suggested model |
| --- | --- |
| Короткий шаг / Focused task | GPT-6 Luna |
| Обычная работа / Everyday work | GPT-6.2 Sol |
| Изображения и интерфейс / Images and UI | GPT-6.1 Terra |
| Глубокая проверка / In-depth review | GPT-6.2 Astra |
| Сложная задача / Flagship workflow | GPT-6.2 Astra |

Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.

Preserve source references and units. Validate totals against a reference example.

[Модели / Models](https://learn.chatgpt.com/docs/models) · [Скиллы / Skills](https://learn.chatgpt.com/docs/build-skills)
