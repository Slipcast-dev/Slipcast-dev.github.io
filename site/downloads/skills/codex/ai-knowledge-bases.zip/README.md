# Базы знаний и обновление индекса / Knowledge bases and index refresh · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Загрузка документов, версии, дубли и контроль обновления.

Ingestion, versions, deduplication and refresh checks.

Выберите скилл под задачу / Choose a skill for your task:

- [knowledge-base-ingestion](skills/knowledge-base-ingestion/SKILL.md)
- [knowledge-base-refresh-check](skills/knowledge-base-refresh-check/SKILL.md)
