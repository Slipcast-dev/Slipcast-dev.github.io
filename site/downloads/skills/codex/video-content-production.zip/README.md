# Видео, раскадровки и субтитры / Video, storyboards and captions · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Сценарий, монтажная разбивка, субтитры и обложки.

Scripts, shot lists, captions and thumbnails.

Выберите скилл под задачу / Choose a skill for your task:

- [video-caption-thumbnail-handoff](skills/video-caption-thumbnail-handoff/SKILL.md)
- [video-storyboard-script](skills/video-storyboard-script/SKILL.md)
