---
name: shared-drive-cleanup
description: "Clean up a shared drive nobody owns — the ownership-first move, the top-down audit that finds the 80% (stale projects, duplicates, ex-employee folders), the archive-don't-delete discipline for shared property, and the norms that prevent regrowth. Use when asked our shared drive is a disaster, clean up the team drive, who owns all these folders, or people are scared to delete anything."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# shared-drive-cleanup

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the audit map, the archive plan with the fear-killing rule, the ownership assignments, and the going-forward norms.
