---
name: weekly-review-ritual
description: "Install the weekly review that keeps work from managing you — the 30-minute Friday ritual: close the week's loops, sweep the capture points, choose next week's big three before the calendar chooses for you, and the two questions that compound. Use when asked set up a weekly review, my weeks just happen to me, GTD-style review but lighter, or I keep dropping threads between weeks."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# weekly-review-ritual

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ritual's fixed agenda, the sweep checklist, the big-three selection, and the survival rules for busy weeks.
