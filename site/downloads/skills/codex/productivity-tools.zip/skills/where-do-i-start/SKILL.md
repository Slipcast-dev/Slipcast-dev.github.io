---
name: where-do-i-start
description: "Turn a chaotic pile of everything-in-your-head into one clear first action — the antidote to the paralysis of too much at once. Use when asked I don't know where to start, I'm overwhelmed with everything I have to do, help me get going, or just tell me what to do first."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# where-do-i-start

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces your brain-dump organized into a simple ordered list, the single next physical action to take right now, and the rest deliberately hidden so it can't overwhelm — outsourcing the executive-function job of structuring, so you can just execute.
