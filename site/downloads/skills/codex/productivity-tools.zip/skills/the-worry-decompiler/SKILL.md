---
name: the-worry-decompiler
description: "Turn an anxious spiral into a concrete list — separate the specific worries from the vague dread, sort what you can act on from what you can't, and get one action. Use when asked help me with my anxiety spiral, I can't stop worrying about, my mind won't stop racing, or break down what I'm anxious about. Not therapy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-worry-decompiler

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the swirling worry pulled apart into named, specific concerns, each sorted into can-act-on vs can't-control vs not-actually-likely, a single action for the actionable ones, and a way to set down the rest — because a spiral is fog, and a list is manageable.
