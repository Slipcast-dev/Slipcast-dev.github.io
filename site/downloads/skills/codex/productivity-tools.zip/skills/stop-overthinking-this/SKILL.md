---
name: stop-overthinking-this
description: "Break an analysis-paralysis loop on a small or reversible decision — set a limit, force a call, and move on. Use when asked I'm overthinking this, help me just decide, I keep going back and forth, or this shouldn't be so hard."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# stop-overthinking-this

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a quick read on whether this decision even deserves deliberation (most don't), the realization that the options are probably close enough that it doesn't matter much, a forced pick via a simple rule, and permission to move on — because the overthinking is costing more than a slightly-wrong choice ever would.
