---
name: file-access-preflight
description: "Run the pre-flight checklist before an agent gets filesystem access — the scope boundary (which directories, read vs write), the secrets-exposure sweep, the destructive-operation gates, and the path-traversal and untrusted-file defenses. Use when asked let my agent access my files safely, is it safe to give the agent file/computer access, guardrails before the agent touches my filesystem, or scope down my coding agent's reach."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# file-access-preflight

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the scope boundary, the secrets sweep, the write/delete gates, and the untrusted-content rules.
