---
name: good-enough-detector
description: "Tell you when to stop polishing and ship — the point where more effort stops adding real value. Use when asked is this good enough, should I keep working on this, when do I stop, or I keep tweaking this and can't let go."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# good-enough-detector

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on whether the thing already meets its actual bar, the diminishing-returns check (is more effort improving it or just moving it around), what genuinely still needs fixing vs what's perfectionism, and a clear ship / one-more-pass / keep-going verdict — freeing you from polishing things past the point anyone will notice.
