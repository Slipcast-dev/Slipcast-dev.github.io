---
name: should-i-quit-or-push
description: "Get an honest read on whether to quit or keep going on a project, job, hobby, or goal that's become a slog — distinguishing a dip worth pushing through from a dead end worth leaving. Use when asked should I quit this, is it time to give up on, push through or walk away, or I don't know if I should keep going."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# should-i-quit-or-push

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a diagnosis of whether you're in a temporary dip or a genuine dead end, the sunk-cost and identity traps clouding the call, honest signals pointing each way, and a clear push / pivot / quit recommendation — because both quitting too early and quitting too late are expensive.
