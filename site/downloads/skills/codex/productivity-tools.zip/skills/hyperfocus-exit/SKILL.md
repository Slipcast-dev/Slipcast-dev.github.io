---
name: hyperfocus-exit
description: "Give yourself a gentle, structured off-ramp from hyperfocus before it costs you sleep, meals, or the rest of your life. Use when asked I've been at this for hours, help me stop working, I can't pull myself away from this, or I lost track of time again."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# hyperfocus-exit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a quick reality check on how long you've been at it and what you've neglected, a save-your-place ritual so stopping doesn't feel like losing progress, a graceful stopping point, and the transition to what you actually need to do next — because for some brains, stopping is harder than starting.
