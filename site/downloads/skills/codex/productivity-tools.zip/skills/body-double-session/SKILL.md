---
name: body-double-session
description: "Set up and run a body-doubling session — using another person's presence (in the room, on a call, or a chat check-in) to start and stay on the task your ADHD brain keeps bouncing off. Use when someone says 'I can't start this task', 'body double with me', 'I only work when someone's around', or has ADHD/executive-dysfunction and a task that won't begin."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# body-double-session

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a session plan, the exact ask to send a body-double partner, and a solo fallback for when no one's available.
