---
name: knowledge-gardening
description: "Keep a team knowledge base alive — the gardener role and its weekly half-hour, the rot signals (stale pages, orphans, duplicates) and their fixes, the capture funnels that feed the garden, and the pruning that keeps search useful. Use when asked our wiki is a graveyard, who maintains the knowledge base, set up knowledge management that lasts, or people can't find anything anymore."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# knowledge-gardening

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the gardener rotation, the weekly tending routine, the rot triage, and the capture funnels.
