---
name: what-am-i-not-seeing
description: "Surface the blind spot — the missing stakeholder, the ignored option, the risk outside your frame, the thing you're too close to notice. Use when asked what am I missing, what's my blind spot, what haven't I considered, or is there something I'm not seeing here."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# what-am-i-not-seeing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the considerations outside your current frame: who you haven't accounted for, what you've ruled out without noticing, the second-order effects, and the thing your closeness to the situation hides — the opposite of confirming what you already think.
