---
name: personal-operating-manual
description: "Write the manual for how you work best — your energy, triggers, communication style, and non-negotiables — to share with a manager, team, or partner (or to know yourself). Use when asked to write my user manual, how I work best, a working-with-me guide, or help my team understand me."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# personal-operating-manual

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clear one-pager covering how you communicate, when you're at your best, what drains you, how you like feedback, and your non-negotiables — turning invisible friction into stated expectations, so people can work with you instead of around you.
