---
name: year-in-review
description: "Run an honest personal year-in-review and set next year's direction — wins, misses, an energy audit, and one theme, not a resolution list that dies in February. Use when asked for a personal year in review, a yearly reflection, to reflect on the past year, or plan next year. Personal, not corporate."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# year-in-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the structured retrospective (what worked, what didn't, what you learned), an energy audit of what gave vs. drained you, the honest misses, and a single theme with a few concrete commitments.
