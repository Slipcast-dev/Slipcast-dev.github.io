---
name: folder-structure-designer
description: "Design a folder structure people actually file into — shallow, purpose-first, with a home for everything and an inbox for the undecided, sized to the team that must maintain it. Use when asked organize our shared drive, design a folder structure for the project, where should things live, or our files are chaos."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# folder-structure-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the structure with its placement rules, the depth and naming constraints, the _inbox convention, and the migration-lite plan for the existing mess.
