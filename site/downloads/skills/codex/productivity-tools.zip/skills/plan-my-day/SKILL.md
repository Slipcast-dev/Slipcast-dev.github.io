---
name: plan-my-day
description: "Turn a messy to-do brain-dump into a realistic, time-blocked day — top priorities first, everything slotted with buffer, and an honest 'this won't all fit, cut these.' Use when asked to plan my day, time-block my schedule, help me organize today, or I have too much to do."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# plan-my-day

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the top 3 priorities, a time-blocked schedule around your fixed commitments, a realistic cut list when it's overloaded, and an if-things-slip fallback — planning for the day you'll actually have.
