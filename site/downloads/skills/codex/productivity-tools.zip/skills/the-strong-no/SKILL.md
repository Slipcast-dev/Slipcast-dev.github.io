---
name: the-strong-no
description: "Find the real reason to NOT do the exciting thing you're about to commit to — the honest case against, before the excitement carries you in. Use when asked talk me out of this, should I really do this, what's the case against, or I'm excited but is this a mistake."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-strong-no

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the strongest honest argument for not doing it, the excitement biases clouding your judgment, the specific conditions under which this is a bad idea for you, and a clear read on whether the strong no actually wins — protecting you from the plans that feel great and end badly.
