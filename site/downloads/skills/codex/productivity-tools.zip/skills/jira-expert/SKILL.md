---
name: jira-expert
description: Atlassian Jira expert for creating and managing projects, planning, product
  discovery, JQL queries, workflows, custom fields, automation, reporting, and all
  Jira features. Use when setting up or configuring Jira projects, writing JQL and
  advanced searches, creating dashboards, designing workflows, or performing technical
  Jira operations.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# jira-expert

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

