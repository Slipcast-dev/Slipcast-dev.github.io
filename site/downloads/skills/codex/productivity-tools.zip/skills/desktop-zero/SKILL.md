---
name: desktop-zero
description: "Clear the desktop that's become a hundred-icon guilt mosaic — the fast triage that empties it today, the honest read of what the desktop was being used for (it's a to-do list wearing icons), and the replacement systems that keep it clear. Use when asked clean up my desktop, my desktop has 200 files on it, why does my desktop keep filling up, or set up a clean-desktop habit."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# desktop-zero

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the today-pass, the function-replacement mapping, and the two-minute weekly habit.
