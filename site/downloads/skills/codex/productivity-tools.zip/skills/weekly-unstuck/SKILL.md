---
name: weekly-unstuck
description: "A short weekly ritual that clears the mental backlog, picks the one thing that matters, and keeps you honest about your dependence on autopilot. Use when asked run my weekly reset, help me plan my week, my weekly check-in, or get me unstuck for the week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# weekly-unstuck

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a quick brain-dump and triage of what's on you, the single most important focus for the week, the stuck things and their tiny first steps, and a self-check on where you're coasting or over-relying — a recurring executive-function reset rather than a one-off fix.
