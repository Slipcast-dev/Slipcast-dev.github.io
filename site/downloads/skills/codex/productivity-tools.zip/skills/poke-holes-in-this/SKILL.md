---
name: poke-holes-in-this
description: "Get only the weaknesses in something you made — no praise, no encouragement padding, just the holes and how to fix them. Use when asked to poke holes in this, tell me what's wrong with this, critique this honestly, or don't be nice about it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# poke-holes-in-this

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a focused list of the real problems in your draft, plan, argument, or code — ranked by severity, each with why it's a problem and a concrete fix — deliberately stripping the 'this is great!' padding that AI and polite humans add and you don't need.
