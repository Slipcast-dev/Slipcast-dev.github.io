---
name: deep-work-blocking
description: "Protect focus time that actually survives the week — the block placement matched to real energy hours, the defense rules (what moves a block, what never), the entry ritual that beats the blank-stare start, and the honest sizing that stops 8-hour fantasy blocks. Use when asked block focus time that keeps getting eaten, when should I schedule deep work, my calendar has no room to think, or I block time and then waste it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# deep-work-blocking

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the block design, the defense tiers, the entry ritual, and the meeting-culture negotiation.
