---
name: atlassian-templates
description: Atlassian Template and Files Creator/Modifier expert for creating, modifying,
  and managing Jira and Confluence templates, blueprints, custom layouts, reusable
  components, and standardized content structures. Use when building org-wide templates,
  custom blueprints, page layouts, and automated content generation.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# atlassian-templates

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

