---
name: future-selves-council
description: "Bring three versions of future-you into a decision — you in a week, in a year, and in ten years — because they each want different things. Use when asked what would future me want, will I regret this, think long-term about this choice, or help me decide for the long run."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# future-selves-council

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces each future self's honest take on today's decision, where they conflict (short-term relief vs long-term payoff), whose vote should weigh most given what's at stake, and the choice that best serves the future-you that matters here.
