---
name: inbox-triage-live
description: "Triage the user's REAL inbox through the Gmail connector — not a framework they run by hand. Use when asked to clear my inbox, get me to inbox zero on the actual account, triage my unread, or process my email backlog in Cowork. Reads unread via the Gmail connector, sorts every message into archive / reply-now / task / park, applies labels and archives in place, drafts the reply-now messages as real Gmail drafts."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# inbox-triage-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a triage-report artifact of what it did and what still needs the user.
