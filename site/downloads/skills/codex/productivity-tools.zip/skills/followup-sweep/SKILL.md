---
name: followup-sweep
description: Sweep the user's REAL mail and calendar for dropped balls — threads awaiting
  their reply, promises they made, and replies they're owed — then draft the nudges.
  Use when asked what am I forgetting, what have I not replied to, who owes me a reply,
  or chase my open threads in Cowork. Reads sent/received mail via the Gmail connector
  and recent events via Calendar, finds the open loops, and produces a follow-up-list
  artifact plus ready-to-send draft nudges.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# followup-sweep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

