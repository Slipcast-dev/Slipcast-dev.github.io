---
name: think-from-another-angle
description: "Get unstuck on a problem by deliberately re-framing it through a different lens — a child's, an outsider's, another industry's, the reverse, the extreme. Use when asked I'm stuck on this, look at this differently, reframe this problem, or how else could I think about this."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# think-from-another-angle

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the same problem re-cast through several deliberately different frames (each of which changes what the problem even is), what each reframe reveals, and the most useful new angle to pursue — because being stuck is usually a framing problem, not an effort problem.
