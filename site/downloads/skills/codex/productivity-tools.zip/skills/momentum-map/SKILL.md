---
name: momentum-map
description: "Break a stuck, stalled week with three tiny wins sequenced for momentum — because motion creates motivation, not the other way around. Use when asked I'm in a rut, help me get unstuck this week, I've stalled on everything, or I need momentum."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# momentum-map

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces three small, genuinely-achievable wins ordered so each fuels the next, a deliberately easy first one to prove motion is possible, the dopamine logic behind the sequence, and a reframe that you don't need motivation to start — starting creates it — turning a paralyzed week into a moving one.
