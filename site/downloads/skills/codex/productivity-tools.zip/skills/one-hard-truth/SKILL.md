---
name: one-hard-truth
description: "Get the single honest thing you're avoiding about a situation — said kindly but not softened away. Use when asked tell me the hard truth, what am I avoiding here, be honest with me about this, or what do I not want to hear."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# one-hard-truth

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the one thing you already half-know but keep sidestepping, said plainly and with care (not cruelty), why it's hard to face, and what facing it would actually make possible — because the truth you're avoiding is usually the one that would change things, and a kind voice can say what your own keeps ducking.
