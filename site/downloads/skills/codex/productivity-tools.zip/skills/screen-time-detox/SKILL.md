---
name: screen-time-detox
description: "Cut compulsive screen and phone use with a workable plan — friction, environment, and replacement habits — instead of relying on willpower or deleting everything. Use when asked to reduce my screen time, I'm addicted to my phone, help me use my phone less, or a digital detox plan."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# screen-time-detox

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on your worst triggers, targeted friction and environment changes, replacement activities for the itch, boundary settings that stick, and a realistic goal — not an all-or-nothing purge that fails by Tuesday.
