---
name: spoon-planner
description: "Budget limited energy the way spoon theory describes it — count your realistic daily 'spoons', price what each task actually costs (including the invisible ones), protect the non-negotiables, and plan for the days you'll have far fewer. Use when someone says 'I only have so much energy', 'help me pace with my chronic illness', 'I keep crashing', or lives with ME/CFS, long COVID, fibromyalgia, POTS, MS, or any limited-capacity condition. A self-management tool, not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани заданные ограничения. Дай конкретный следующий шаг и отметь недостающие данные.
<!-- slipcast-model-profile:end -->


# spoon-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a spoon budget, a task price list, and a pacing plan that respects payback and post-exertional crashes.
