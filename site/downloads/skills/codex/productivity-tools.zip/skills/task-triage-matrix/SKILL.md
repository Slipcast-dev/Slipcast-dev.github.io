---
name: task-triage-matrix
description: "Triage an overwhelming task list into what actually gets done — the urgent/important sort applied honestly (with the two corrections the classic matrix needs), the do/schedule/delegate/drop verbs, and the list hygiene that keeps triage from becoming a weekly archaeology dig. Use when asked my task list is overwhelming, triage my todos, everything feels urgent, or what should I actually work on."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# task-triage-matrix

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sorted list with verbs, the urgency audit (what's fake-urgent), the drop list with permission, and the intake rule.
