---
name: panel-of-experts
description: "Get the take of the specific experts a situation actually needs — a lawyer, a therapist, an accountant, a doctor-minded thinker, whoever fits — each in their own voice. Use when asked what would a [profession] say, get expert perspectives on this, who should I be thinking like here, or what am I missing that a pro would catch."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# panel-of-experts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a panel of the right domain experts for your situation, each flagging what a layperson would miss, where they'd disagree, and what to verify with a real professional — never a substitute for licensed advice on serious matters.
