# The Second Opinion

Ask most people (and most AI) for a second opinion and you get the first one again, agreed with more enthusiastically. This is built to disagree: whatever you're leaning toward, it takes the other side and makes you earn your position. Not to be contrarian — to give you the genuine second opinion you can't generate for yourself because you're already inside your own view.

> **Not quite this?** Use `second-opinion-request` when you need to request a second medical opinion.

## What This Skill Produces

- **The opposite position** — a committed alternative to your leaning, taken seriously
- **Its strongest reasons** — the best case for going the other way
- **The questions it forces** — what you'd have to answer for your leaning to survive
- **The honest verdict** — whether your original position holds after the challenge, or whether the second opinion actually wins

## Required Inputs

Ask for these if not provided:
- **Your leaning** — what you're inclined to do or believe
- **Why** — your reasoning so far
- **The decision** — what's actually being chosen
- **How locked in you are** — genuinely open, or looking for permission (be honest — it changes how hard to push)

## Framework: Take The Other Side, For Real

1. **Identify the leaning.** Pin down what the person is tilting toward — that's what to argue against.
2. **Commit to the opposite.** Adopt the alternative position genuinely and build its best case — not a token counterpoint.
3. **Force the defense.** Pose the questions the person must answer for their leaning to hold up — the ones they haven't asked themselves.
4. **Weigh it fairly.** Compare the second opinion to the original on the merits, not to be difficult.
5. **Deliver the verdict.** Say clearly whether the original leaning survives, needs adjusting, or should flip — and don't cave to comfort if the second opinion is genuinely stronger.

## Output Format

### Your leaning: [what you're inclined toward]

**The second opinion (the other side):** [committed alternative + strongest reasons].
**Questions your leaning must answer:** [the ones you're not asking].
**Verdict:** [your leaning holds / needs adjusting / the other side actually wins] — because [why].

## Quality Checks
- [ ] Takes a genuine opposite position, not a token counterpoint
- [ ] Builds the strongest case for the alternative
- [ ] Forces real questions the person hasn't asked
- [ ] Delivers an honest verdict, even if it contradicts the leaning
- [ ] Doesn't just agree with more enthusiasm

## Anti-Patterns
- **Agreeing** with the leaning in disguise.
- **A weak counterpoint** built to lose.
- **Being contrarian for its own sake** rather than genuinely evaluating.
- **Caving to the comfortable answer** at the verdict.

## Example Trigger Phrases
- "Give me a real second opinion on taking this job — don't just agree."
- "I'm leaning toward selling. Argue the other way."
- "I need a fresh take, not a yes-man."
- "Everyone agrees with me — take the opposite side."
- "Make me defend this decision properly."
