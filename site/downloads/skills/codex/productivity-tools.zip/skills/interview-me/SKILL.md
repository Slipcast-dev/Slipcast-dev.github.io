---
name: interview-me
description: "Elicit the real requirements by interviewing the requester BEFORE building or writing anything — one question at a time, until the brief is buildable. Use when a request is vague ('make me a dashboard', 'write something for the board'), when past deliverables missed the mark, or when the user says 'interview me' / 'ask me questions first'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# interview-me

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a validated brief: goal, audience, constraints, success criteria, and explicit non-goals — then, and only then, the work.
