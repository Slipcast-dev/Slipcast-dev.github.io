---
name: the-one-thing
description: "Cut a full plate down to the single highest-leverage move — the one thing that, done today, makes everything else easier or unnecessary. Use when asked what's the one thing I should focus on, help me prioritize, I have too much on and need to focus, or what matters most today."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-one-thing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces your list weighed by leverage (not urgency or ease), the single most important thing surfaced with why it beats the rest, permission to let the rest wait, and a first step into it — because doing the one thing that matters beats doing ten that don't.
