---
name: email-to-tasks
description: "Convert an email (or a whole thread) into real tasks — the actual asks extracted from the prose, each with owner, deadline, and the done-test, so nothing lives in the inbox as its own reminder. Use when asked what am I actually being asked to do here, turn this thread into a task list, extract the action items from this email, or I keep re-reading this thread."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# email-to-tasks

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ask extraction with quoted sources, the task list in owner-verb-deadline form, and the reply that confirms the commitments.
