---
name: shutdown-ritual
description: "End the workday on purpose — the ten-minute shutdown that closes open loops, stages tomorrow's start, and gives the brain permission to actually stop (the incomplete-task hum has an off switch, and it's written). Use when asked I can't stop thinking about work at night, build an end-of-day routine, my evenings are ruined by open loops, or how do I stop checking one more time."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# shutdown-ritual

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the shutdown checklist, the tomorrow-staging step, the closing phrase, and the after-hours boundary rules.
