---
name: full-page-screenshot
description: Use when the user asks to capture a full-page screenshot, long screenshot,
  or complete page capture of a web page. Handles SPA scroll containers, lazy-loaded
  images, and very tall pages via Chrome DevTools Protocol with zero external dependencies.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# full-page-screenshot

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

