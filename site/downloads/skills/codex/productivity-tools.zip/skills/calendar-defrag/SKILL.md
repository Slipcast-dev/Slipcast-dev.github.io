---
name: calendar-defrag
description: "Defragment a work calendar through a tool-using agent — find the meeting debt, propose the consolidation, and (approval-gated) execute the moves. Use when asked to defrag my calendar, get me focus time, audit my meetings, or fix my week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# calendar-defrag

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the calendar audit (cost per meeting, fragmentation map), a defrag proposal with focus blocks, and an approval-gated execution plan.
