---
name: brainstorming
description: "Run a real brainstorm — divergent generation without judgment, then convergent selection with explicit criteria — instead of listing ten obvious ideas and calling it creativity. Use when asked to brainstorm, generate ideas or options, explore a solution space, or name something."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# brainstorming

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a genuinely wide option set (including the weird tail), then a shortlist selected against named criteria with the rejects preserved.
