---
name: my-failure-museum
description: "Turn a mistake into a reusable lesson — a short, unsentimental 'here's what happened and the rule so it doesn't happen again' entry you can actually keep. Use when asked help me learn from this mistake, I keep making the same error, capture this lesson, or turn this failure into something useful."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# my-failure-museum

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest, blame-free autopsy of what happened, the real root cause (not the surface one), the specific rule or trigger that prevents a repeat, and a one-line entry for your growing 'failure museum' — because unexamined mistakes repeat and examined ones compound into wisdom.
