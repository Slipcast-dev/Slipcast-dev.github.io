---
name: confluence-expert
description: Atlassian Confluence expert for creating and managing spaces, knowledge
  bases, and documentation. Configures space permissions and hierarchies, creates
  page templates with macros, sets up documentation taxonomies, designs page layouts,
  and manages content governance. Use when users need to build or restructure a Confluence
  space, design page hierarchies with permission structures, author or standardise
  documentation templates, embed Jira reports in pages, run knowledge base audits,
  or establish documentation standards and collaborative workflows.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# confluence-expert

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

