---
name: devils-advocate-on-demand
description: "Argue hard against whatever you just concluded — so your decision has to survive a real challenge instead of an echo chamber. Use when asked to play devil's advocate, argue against this, challenge my conclusion, or talk me out of it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# devils-advocate-on-demand

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the strongest case against your position, the uncomfortable questions you're avoiding, the evidence that cuts the other way, and an honest read on whether your conclusion survives the challenge — deliberately countering the 'that's a great idea!' agreement bias.
