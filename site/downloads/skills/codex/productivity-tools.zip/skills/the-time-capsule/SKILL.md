---
name: the-time-capsule
description: "Write a sealed memo to your future self or successor — the honest state of things, falsifiable predictions with confidence levels, and the advice you suspect they'll need — with an open-on date and a scoring ritual for when it's opened. Use when leaving a role, finishing a big project, at year-end or planning season, before a leave, or 'write a letter to my successor'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-time-capsule

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sealed capsule, its prediction ledger, and the opening-day ritual.
