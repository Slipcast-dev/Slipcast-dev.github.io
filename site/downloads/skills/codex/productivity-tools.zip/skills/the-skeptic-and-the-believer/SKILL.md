---
name: the-skeptic-and-the-believer
description: "See an idea through two committed extremes — a true believer and a hard skeptic — so you get the full range before settling in the middle. Use when asked should I believe this, is this hype or real, give me both sides, or how excited should I be about."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-skeptic-and-the-believer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the believer's fullest bull case and the skeptic's sharpest bear case (each committed, not hedged), the crux question that separates them, and a grounded read on where the truth probably sits — great for evaluating claims, trends, opportunities, and your own enthusiasm.
