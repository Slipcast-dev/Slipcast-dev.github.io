---
name: unblock-protocol
description: "Get unstuck on purpose — the stuck-type diagnosis (don't-know-how, can't-decide, waiting, avoiding, too-big), the matched unblock move for each, and the timebox that stops noble struggling before it eats the day. Use when asked I'm stuck on this and don't know why, I keep avoiding this task, how long should I struggle before asking, or unblock my stalled project."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# unblock-protocol

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the stuck diagnosis, the matched move, the ask-for-help script that preserves standing, and the stuck-log pattern read.
