---
name: browser-automation
description: Use when the user asks to automate browser tasks, scrape websites, fill
  forms, capture screenshots, extract structured data from web pages, or build web
  automation workflows. NOT for testing — use playwright-pro for that.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# browser-automation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

