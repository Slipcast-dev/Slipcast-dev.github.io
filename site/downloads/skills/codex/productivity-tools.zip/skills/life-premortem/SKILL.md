---
name: life-premortem
description: "Write the failure story of your year, relationship, move, or big life bet in advance — imagine it's a year later and it went wrong, tell that story vividly, then mine it for the real risks and the cheap things that would have prevented them. Use when someone says 'I'm about to make a big life change', 'what could go wrong with this', 'de-risk my year', or is committing to something large and irreversible. The life-scale sibling of a project premortem."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# life-premortem

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the failure narrative, the extracted risk list with preventatives, and the early-warning signs to watch.
