---
name: journaling-prompts
description: "Get journaling prompts tuned to what you're actually working through — a decision, a rough patch, a goal, or just building the habit — not generic 'how was your day'. Use when asked for journaling prompts, help me start journaling, writing prompts for [situation], or what should I journal about."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# journaling-prompts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a small set of prompts matched to your intent, a simple format and cadence that fits your time, a starter for total beginners, and a gentle note on going deeper vs. when a topic is better taken to a professional.
