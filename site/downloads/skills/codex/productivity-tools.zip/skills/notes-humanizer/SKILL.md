---
name: notes-humanizer
description: "Strips AI writing patterns from text and rewrites it to sound genuinely human — removing the statistical defaults, then adding earned voice calibrated to genre (opinion pieces get a person's voice; docs and summaries stay neutral) without ever faking humanity. Use when a draft reads as AI-generated, over-polished, or rhythmically uniform — including blog posts, emails, LinkedIn posts, or any prose that needs to sound like a real person wrote it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# notes-humanizer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a pattern audit, side-by-side comparison, itemised change log, and clean rewritten output ready to paste.
