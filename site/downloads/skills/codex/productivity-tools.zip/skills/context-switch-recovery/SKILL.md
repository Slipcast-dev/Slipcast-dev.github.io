---
name: context-switch-recovery
description: "Reconstruct where you were and what's next after an interruption, so a broken focus doesn't cost you the whole thread. Use when asked where was I, I got interrupted and lost my place, help me pick back up, or I forgot what I was doing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# context-switch-recovery

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a quick rebuild of the task's state from what you remember (what you'd done, what you were mid-thought on), the single next action to re-enter it, and a 'breadcrumb' habit for next time — cutting the expensive re-immersion cost that interruptions inflict, especially on ADHD brains.
