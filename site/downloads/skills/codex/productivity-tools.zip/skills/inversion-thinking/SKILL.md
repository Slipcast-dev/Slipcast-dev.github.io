---
name: inversion-thinking
description: "Solve a problem backwards — ask how to guarantee the worst outcome, then avoid all of it. Use when asked to help me not fail at, what could go wrong with, how do I avoid messing up, or think about this in reverse."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# inversion-thinking

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the inverted question (how to guarantee failure), the specific ways you'd cause the disaster, and then the plan that is simply the avoidance of each — often clearer and more actionable than trying to plan success directly, because failure modes are more concrete than success factors.
