---
name: escalate-or-hold
description: "Decide whether an issue gets escalated now, held with a re-check time, or closed — as a typed decision with probabilities rather than a judgment call in a thread. Use when asked should I escalate this, is this a P1, do we page someone, hold or escalate, or when an on-call, support lead or PM is staring at an issue and unsure."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# escalate-or-hold

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the issue state in a fixed schema, the three-way decision with probabilities and confidence, the act-or-hold verdict, and the re-check time when holding.
