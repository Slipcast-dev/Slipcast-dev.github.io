---
name: personal-wip-limits
description: "Cap your work-in-progress so things finish — the personal WIP limit (3 active outcomes, defended), the finish-before-start rule with its exceptions named, the parking lot for the overflow, and the throughput evidence that converts the skeptic. Use when asked I have twelve things half-done, why does nothing ever finish, set a WIP limit for my work, or I start everything and complete nothing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# personal-wip-limits

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the active-list cap, the parking protocol, the start-gate, and the two-week throughput experiment.
