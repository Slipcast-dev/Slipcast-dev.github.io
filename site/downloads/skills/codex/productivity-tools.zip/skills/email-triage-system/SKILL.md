---
name: email-triage-system
description: "Turn an overflowing inbox into a four-verb system — archive, reply-now, task, or park — with the two-minute rule enforced and a daily cadence that survives busy weeks. Use when asked help me get to inbox zero, my email is out of control, build me an email triage system, or process this backlog."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# email-triage-system

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the triage pass on the actual inbox, the four-verb rules, the folder/label minimal set, and the daily cadence.
