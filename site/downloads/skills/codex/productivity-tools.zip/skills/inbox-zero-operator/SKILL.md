---
name: inbox-zero-operator
description: "Drive an email inbox to zero through a computer-use or tool-using agent — triage every message into act/delegate/defer/archive with drafts prepared, never a send. Use when asked to get my inbox to zero, triage my email hands-on, process my inbox for me, or run inbox zero."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# inbox-zero-operator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the triage ledger, prepared reply drafts, and an approval-gated action plan the agent then executes read-mostly.
