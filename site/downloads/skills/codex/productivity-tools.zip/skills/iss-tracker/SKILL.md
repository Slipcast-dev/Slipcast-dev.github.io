---
name: iss-tracker
description: "Track the International Space Station live with keyless curl — where it is right now, what it's over, and when to look up, with the orbital math translated into human terms. Use when asked where is the ISS right now, is the space station overhead, when can I see the ISS tonight, or track the station for the kids."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# iss-tracker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the live position translated to a place name, the overhead-math explained, the visibility rules of thumb, and the rerunnable command — the library's proof that live data can also just be delightful.
