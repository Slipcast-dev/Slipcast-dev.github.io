---
name: bennett-time-audit
description: "Audit a week the way Arnold Bennett's 'How to Live on 24 Hours a Day' (1908) prescribes — time as the one income that cannot be increased, the day-within-the-day, and starting with 90 minutes, not a life overhaul. Use when someone says 'I have no time', 'work eats everything', 'I want to learn X but can't fit it', or asks for a time audit or evening routine."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# bennett-time-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a time ledger, one reclaimed 'inner day' block, and Bennett's own warnings about overreach.
