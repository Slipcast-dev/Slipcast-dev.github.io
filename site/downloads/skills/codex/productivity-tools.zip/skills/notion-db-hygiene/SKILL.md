---
name: notion-db-hygiene
description: Clean the user's REAL Notion database — read it, find stale/incomplete/duplicate
  entries, and fix them via the connector — not advice on keeping Notion tidy. Use
  when asked to clean up my Notion database, my tracker is a mess, find the stale
  and duplicate entries, or tidy my projects DB in Cowork. Reads the database via
  the Notion connector, audits for staleness / missing required fields / duplicates
  / status drift, and produces a hygiene-report artifact plus the applied fixes (with
  a preview-and-confirm step before any change).
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# notion-db-hygiene

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

