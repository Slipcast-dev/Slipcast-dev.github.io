---
name: attention-reset
description: "Get your attention back with a 30-day protocol that assumes you'll break it — a screen-time ledger without moralizing, friction engineering (what to delete, grayscale, where the phone sleeps), planned relapses, and honest replacement activities for the boredom that shows up on day 3. Use when someone says 'my screen time is 7 hours', 'I want a dumbphone', 'digital detox', 'I can't read books anymore', or 'my attention span is gone'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# attention-reset

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ledger, a personal friction plan, and the 30-day protocol with expected failure points.
