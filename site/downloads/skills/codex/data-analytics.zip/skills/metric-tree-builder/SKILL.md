---
name: metric-tree-builder
description: "Decompose a north-star metric into a driver tree — the inputs and sub-inputs that actually move it — so a team knows which levers to pull. Use when asked to build a metric tree, break down a north-star metric, map metric drivers, or find the inputs behind an output metric."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# metric-tree-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a hierarchical tree from the top metric down to actionable input metrics, with the relationships, the highest-leverage levers, and what to instrument.
