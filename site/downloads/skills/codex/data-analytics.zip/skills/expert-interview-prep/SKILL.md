---
name: expert-interview-prep
description: "Get the most from an hour with an expert — the do-your-homework floor (never ask what's googleable), the question arc from calibration to the frontier, the follow-up discipline that goes deep instead of wide, and the capture that survives the call. Use when asked prep me for the expert call, what should I ask this advisor/analyst/practitioner, we get an hour with X, or our expert calls are pleasant but shallow."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# expert-interview-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the homework brief, the question arc, the follow-up toolkit, and the capture plan.
