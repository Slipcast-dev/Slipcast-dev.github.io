---
name: boolean-search-builder
description: "Build boolean and X-ray search strings to source candidates. Use when asked to build a boolean search, source candidates on LinkedIn/Google, write an X-ray search, or find people with specific skills."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# boolean-search-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready-to-paste boolean strings (with synonyms, must-haves, and exclusions), X-ray variants for LinkedIn/GitHub, and a refinement plan to widen or narrow the result set.
