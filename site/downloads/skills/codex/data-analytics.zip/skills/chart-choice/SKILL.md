---
name: chart-choice
description: "Pick the chart the data and the point actually need — the question-to-chart mapping (comparison, trend, composition, distribution, relationship), the honesty rules (axes, baselines, dual-axis traps), and the one-chart-one-point discipline. Use when asked what chart should I use, make this data visual, why does this chart feel misleading, or fix this graph for the deck."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# chart-choice

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the chart verdict with its reasoning, the honesty checklist applied, and the labeling that lets the chart travel without its author.
