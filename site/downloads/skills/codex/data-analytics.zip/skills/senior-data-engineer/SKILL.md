---
name: senior-data-engineer
description: Data engineering skill for building scalable data pipelines, ETL/ELT
  systems, and data infrastructure. Expertise in Python, SQL, Spark, Airflow, dbt,
  Kafka, and modern data stack. Includes data modeling, pipeline orchestration, data
  quality, and DataOps. Use when designing data architectures, building data pipelines,
  optimizing data workflows, implementing data governance, or troubleshooting data
  issues.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-data-engineer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

