---
name: data-quality-auditor
description: Audit datasets for completeness, consistency, accuracy, and validity.
  Profile data distributions, detect anomalies and outliers, surface structural issues,
  and produce an actionable remediation plan. Use when the user asks to check data
  quality, profile a dataset, hunt outliers or missing values, or validate data before
  analysis or model training.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# data-quality-auditor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

