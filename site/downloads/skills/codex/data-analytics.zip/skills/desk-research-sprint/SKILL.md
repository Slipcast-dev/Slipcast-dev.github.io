---
name: desk-research-sprint
description: "Run a timeboxed desk-research sprint that ends with an answer instead of forty tabs — the question decomposition, the source plan by question type, the capture discipline that prevents re-reading, and the stop rule that beats completionism. Use when asked research this market/tool/topic by Friday, I have two hours to get smart on X, structure my desk research, or I keep researching and never concluding."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# desk-research-sprint

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the decomposed questions, the source plan, the capture format, and the timeboxed synthesis with confidence labels.
