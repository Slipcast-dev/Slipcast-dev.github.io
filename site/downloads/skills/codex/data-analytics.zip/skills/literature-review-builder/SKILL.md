---
name: literature-review-builder
description: "Structure a literature review that argues, not lists — thematic synthesis from your sources with the debate mapped and the gap identified. Use when asked to write or structure a literature review, organize my sources, synthesize these papers, or find the gap for my thesis."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# literature-review-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a themed review skeleton with your sources placed in conversation, the points of scholarly disagreement, the gap your work addresses, and an honest register of what you haven't read yet.
