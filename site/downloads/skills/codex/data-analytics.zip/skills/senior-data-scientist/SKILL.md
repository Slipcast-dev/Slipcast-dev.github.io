---
name: senior-data-scientist
description: World-class senior data scientist skill specialising in statistical modeling,
  experiment design, causal inference, and predictive analytics. Covers A/B testing
  (sample sizing, two-proportion z-tests, Bonferroni correction), difference-in-differences,
  feature engineering pipelines (Scikit-learn, XGBoost), cross-validated model evaluation
  (AUC-ROC, AUC-PR, SHAP), and MLflow experiment tracking — using Python (NumPy, Pandas,
  Scikit-learn), R, and SQL. Use when designing or analysing controlled experiments,
  building and evaluating classification or regression models, performing causal analysis
  on observational data, engineering features for structured tabular datasets, or
  translating statistical findings into data-driven business decisions.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-data-scientist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

