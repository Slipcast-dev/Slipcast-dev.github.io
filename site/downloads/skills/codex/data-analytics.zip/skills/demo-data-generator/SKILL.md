---
name: demo-data-generator
description: "Use when asked to create demo data, seed a no-signup demo, generate fake but realistic data for screenshots, or fill a sandbox without using real customer data."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# demo-data-generator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces realistic, internally consistent fake data so a project can ship a demo nobody has to sign up for: a data schema summary, a seeded generation script, seed files, and a checklist confirming no real personal data is included.
