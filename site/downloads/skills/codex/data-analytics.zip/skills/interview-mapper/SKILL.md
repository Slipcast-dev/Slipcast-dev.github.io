---
name: interview-mapper
description: Maps a single interview transcript into a verbatim-grounded, lens-coded
  structure and checks whether analytic conclusions hold across independent re-runs.
  Use when the user wants to code, map, interpret, or make sense of an interview transcript,
  depth interview, custdev/JTBD/expert/usability/exit/win-loss/focus-group session,
  or wants cross-interview synthesis (insight cards, patterns) built up from coded
  transcripts — even if they don't name a method. Every conclusion must carry a verbatim
  quote verified against the source text; unstable conclusions are flagged for a human,
  never resolved by a single silent pass. Not for generating new interviews, not for
  plain audio transcription, and not for research-method or sample-size planning above
  the transcript (see product-research).
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.
<!-- slipcast-model-profile:end -->


# interview-mapper

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

