---
name: statistical-analyst
description: Run hypothesis tests, analyze A/B experiment results, calculate sample
  sizes, and interpret statistical significance with effect sizes. Use when you need
  to validate whether observed differences are real, size an experiment correctly
  before launch, or interpret test results with confidence.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# statistical-analyst

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

