---
name: flow-metrics-interpreter
description: "Read your team's flow metrics — cycle time, throughput, WIP, aging work — and say what they actually mean and what to try, not just restate the numbers. Use when asked to interpret cycle time, what do our flow/Actionable-Agile metrics mean, why is delivery slow, or read our Kanban metrics."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# flow-metrics-interpreter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the health read per metric, the likely bottleneck the numbers point to, 2–3 concrete process experiments to run next, and the trap-to-avoid so the team doesn't game the metric instead of fixing the flow.
