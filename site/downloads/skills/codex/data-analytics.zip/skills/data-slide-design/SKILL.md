---
name: data-slide-design
description: "Design slides where the data makes the argument — the takeaway-titled chart, the one-chart-per-slide rule, the annotation layer that guides the eye to the point, and the honesty pass on projected data. Use when asked make this data slide land, my chart slide confuses people, how do I present these numbers, or the audience missed the point of my graph."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.1 Terra**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Привязывай выводы к конкретной области изображения или документа.
- Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.
<!-- slipcast-model-profile:end -->


# data-slide-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the redesigned slide: takeaway title, the chart stripped and annotated, the eye-path check, and the honesty audit.
