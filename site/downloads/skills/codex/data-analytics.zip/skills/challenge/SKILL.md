---
name: challenge
description: Pre-mortem plan analysis. Imagine the plan failed 12 months from now
  and work backwards to find the weaknesses. Surfaces assumptions, dependencies, and
  execution risks before committing resources. Use when before significant resource
  commitment, before presenting to a board or investors, when feedback has been one-sidedly
  positive, or when there is pressure to move fast and figure it out later.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# challenge

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

