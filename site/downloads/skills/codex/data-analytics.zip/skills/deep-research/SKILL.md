---
name: deep-research
description: 'Run a disciplined, multi-source research investigation for a high-stakes
  question or decision — fan-out web search across many channels, parallel sub-agents,
  source triangulation (each claim backed by ≥3 independent sources), an adversarial
  review pass, and every source saved to its own file with verbatim quotes for reuse.
  Use when a low-quality answer is expensive: strategy work, comparing N products/methods/markets,
  validating a hypothesis with external data, or mapping how a field works. NOT for
  quick fact-checks (answer directly), structured 12-dimension competitor scoring
  (use competitive-teardown), or fast topic overviews where the decision risk is low
  (use the research router instead).'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.
<!-- slipcast-model-profile:end -->


# deep-research

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

