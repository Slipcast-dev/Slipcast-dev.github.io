---
name: research-repo-setup
description: "Set up a research repository the team actually reuses — the atomic-insight format (finding + evidence + source + date), the tagging that makes old research findable by new questions, and the check-the-repo-first norm that stops re-researching. Use when asked set up a research repository, we keep re-learning the same things, where do our user insights live, or make past research findable."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# research-repo-setup

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the repo structure, the insight-entry format, the intake funnel from studies, and the reuse norms.
