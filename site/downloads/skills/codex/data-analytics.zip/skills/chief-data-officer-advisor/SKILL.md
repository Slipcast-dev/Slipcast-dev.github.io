---
name: chief-data-officer-advisor
description: 'Chief Data Officer advisory for startups: AI training data rights and
  consent provenance, data product strategy (warehouse vs lakehouse vs mesh, build-vs-buy),
  B2B customer-data-as-asset valuation and M&A readiness, data team org evolution.
  Use when deciding whether to train models on customer data, choosing data architecture,
  valuing data for fundraising or M&A, sequencing data hires, or when user mentions
  CDO, chief data officer, data strategy, data mesh, lakehouse, training data, data
  product, data monetization, or customer data asset. NOT a tactical data engineering
  skill — strategic decisions only.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани ссылки на источники и единицы измерения. Проверь итоги на контрольном примере.
<!-- slipcast-model-profile:end -->


# chief-data-officer-advisor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

