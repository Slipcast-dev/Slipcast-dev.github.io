---
name: pivot-analysis-planner
description: "Plan pivot-table analysis that answers the actual question — the question-to-layout mapping (rows, values, filters chosen on purpose), the data-shape check that pivots require, and the drill-down path from summary to so-what. Use when asked analyze this data with a pivot, what's driving the total, break this down by category and month, or my pivot shows nonsense."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pivot-analysis-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the question decomposition, the pivot layout(s) with reasons, the data-shape fixes needed first, and the reading guide.
