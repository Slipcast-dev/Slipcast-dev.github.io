---
name: kpi-tracker-design
description: "Design a KPI tracker that drives decisions instead of decorating them — the few-metrics discipline (5–9, each with an owner and a so-what), targets with honest baselines, the trend-first layout, and the review ritual where the tracker actually gets used. Use when asked set up KPI tracking for the team, build a metrics dashboard in sheets, which numbers should we track, or our dashboard exists but nobody acts on it."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# kpi-tracker-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the metric selection with kill-list, the tracker structure, the target-setting notes, and the review ritual.
