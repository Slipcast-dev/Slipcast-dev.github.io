---
name: literature-review
description: "Structure and write a literature review for any research topic. Use when asked to write a literature review, systematic review summary, narrative review, or research background section."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# literature-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured review with thematic organisation, critical analysis, and gap identification.
