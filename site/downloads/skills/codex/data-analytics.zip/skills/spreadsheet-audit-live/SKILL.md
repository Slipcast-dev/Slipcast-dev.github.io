---
name: spreadsheet-audit-live
description: Audit the user's REAL spreadsheet by opening it in the Cowork sandbox
  — not by reading a description of it. Use when asked to check this sheet before
  we present it, audit the model in my Drive, why don't these numbers add up, or is
  this spreadsheet safe to build on. Pulls the file via the Google Drive connector
  (or an uploaded .xlsx), opens it programmatically in the sandbox to trace formulas,
  hunts hardcodes / broken ranges / unit mixes, and produces a ranked findings artifact
  with a verified-vs-suspect ledger and a fix list.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# spreadsheet-audit-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

