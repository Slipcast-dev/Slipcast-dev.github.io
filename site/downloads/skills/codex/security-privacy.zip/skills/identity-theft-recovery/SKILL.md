---
name: identity-theft-recovery
description: "Take back control after identity theft — the right first moves, in the right order, so you contain the damage and rebuild. Use when asked what to do about identity theft, someone stole my identity, my details are being used fraudulently, or help me recover from fraud."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Ограничься защитной проверкой предоставленных материалов. Указывай подтверждения и меры исправления.
<!-- slipcast-model-profile:end -->


# identity-theft-recovery

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an immediate-actions checklist (freeze, report, secure), an evidence and reporting plan for the right authorities and institutions, a dispute path for fraudulent accounts/charges, and an ongoing-monitoring setup — flagging where to use official channels and when to involve police/regulators.
