---
name: secure-a-lost-phone
description: "Do the right things fast when your phone is lost or stolen — lock it, protect your accounts and money, and decide on wipe vs. locate — in the correct order. Use when asked my phone was stolen, I lost my phone what do I do, someone took my phone, or secure my lost phone."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# secure-a-lost-phone

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an ordered action checklist (locate/lock, protect SIM and banking, change key passwords, wipe decision), the accounts to prioritize because the phone unlocks them, reporting steps, and prevention setup for next time.
