---
name: env-secrets-manager
description: Manage environment-variable hygiene and secrets safety across local development
  and production. Practical auditing, drift awareness, rotation readiness. Use when
  auditing .env files for committed secrets, planning a credential rotation, debugging
  missing-env-var production incidents, or hardening a new project against secrets
  leakage.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# env-secrets-manager

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

