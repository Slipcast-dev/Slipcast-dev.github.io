---
name: source-protection-plan
description: "Assess and reduce the risk of exposing a confidential journalistic source. Use when a reporter is working with a confidential source, a whistleblower, or sensitive leaked material and needs to protect the source's identity. Guidance is defensive; it is not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# source-protection-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a risk assessment (how the source could be identified — metadata, comms, patterns, documents), secure-communication and handling practices, a redaction/anonymization plan for what's published, and the promises to make (and not make) about protection.
