---
name: deepfake-drill
description: "Run a tabletop drill of a voice-clone or deepfake fraud attempt — the 'CEO needs this wire today' call — against your actual approval process, before a real attacker does, then debrief the tells and fix the process gap. Use when someone asks to train the team on deepfake fraud, test wire-transfer controls, run a social-engineering tabletop, or 'could we get CEO-frauded?'. Defensive training only."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# deepfake-drill

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a drill scenario pack, a facilitator script, a tells checklist, and the process fixes the drill exposed.
