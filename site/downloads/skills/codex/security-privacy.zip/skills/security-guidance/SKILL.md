---
name: security-guidance
description: PreToolUse security-anti-pattern hook for Claude Code. Catches 12 common
  security risks (command injection, XSS, SQL injection, unsafe deserialization, GitHub
  Actions workflow injection, eval/new Function code injection) BEFORE the Edit/Write/MultiEdit
  operation completes. Session-state caching prevents duplicate warnings on the same
  file+rule combo. Stdlib only — no dependencies. Use when you want a safety net during
  Claude Code sessions that touch security-sensitive code (auth, payments, user input
  handling, IaC). Disable with ENABLE_SECURITY_REMINDER=0 if you need to perform a
  verified-safe operation that would otherwise trip a pattern. Triggers — "add security
  hook", "block unsafe code", "detect command injection before write", "prevent SQL
  injection patterns", "security warning hook".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Ограничься защитной проверкой предоставленных материалов. Указывай подтверждения и меры исправления.
<!-- slipcast-model-profile:end -->


# security-guidance

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
