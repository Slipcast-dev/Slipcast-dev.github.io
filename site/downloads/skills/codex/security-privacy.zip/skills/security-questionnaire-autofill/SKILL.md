---
name: security-questionnaire-autofill
description: "Draft answers to a vendor security questionnaire (SIG, CAIQ, or a custom sheet) from your real controls — fast, consistent, and honest about gaps. Use when asked to fill out a security questionnaire, answer a SIG/CAIQ, respond to a customer's security review, or complete a vendor risk assessment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# security-questionnaire-autofill

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces drafted answers grounded in your stated controls, a gap list of questions you can't truthfully answer yet, and reusable answer snippets for next time — never fabricated compliance.
