---
name: account-recovery-plan
description: "Get back into a locked or hacked account the right way — the official recovery routes, what proof you'll need, and how to re-secure it so it doesn't happen again. Use when asked I'm locked out of my account, my account got hacked, help me recover my [email/social/bank] account, or I lost access to 2FA."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Ограничься защитной проверкой предоставленных материалов. Указывай подтверждения и меры исправления.
<!-- slipcast-model-profile:end -->


# account-recovery-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the official recovery path for the account type, the identity proof to prepare, a re-securing checklist for after you're back in, and warnings about fake 'recovery' services and support scams.
