---
name: kids-online-safety-plan
description: "Build an age-appropriate online-safety plan for a child — the settings, the agreements, and the conversations — that protects without just spying or banning everything. Use when asked to keep my kid safe online, parental controls setup, my child's online safety, or screen rules for kids."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# kids-online-safety-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an age-tuned plan covering device/platform settings, a family agreement, the ongoing conversations that matter more than any filter, warning signs to watch for, and how to respond to trouble — balancing safety with trust and independence.
