---
name: data-broker-removal
description: "Get your personal info off people-search and data-broker sites — a prioritized opt-out plan that targets the sites that matter and keeps them from reappearing. Use when asked to remove my info from the internet, opt out of data brokers, my address/phone is on people-search sites, or reduce my digital footprint."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# data-broker-removal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a prioritized target list (the high-traffic brokers first), the opt-out method for each, a suppression-at-source plan so data stops flowing back, a recheck cadence, and safe-handling cautions for the personal data you'll be submitting.
