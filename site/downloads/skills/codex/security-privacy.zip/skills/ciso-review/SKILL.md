---
name: ciso-review
description: /c-level-agents:ciso-review [plan] — Risk-paranoid interrogation of any
  plan that touches data, compliance, or production access. Use when launching features
  that handle customer data, before a SOC 2 / ISO audit, or after any incident or
  near-miss.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ciso-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
