---
name: privacy-policy-drafter
description: "Draft a clear, plain-language privacy policy tailored to what a product actually collects and does with data. Use when asked to write a privacy policy, draft a data-protection notice, or create a GDPR/CCPA-aware privacy statement. Not legal advice; have counsel review before publishing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# privacy-policy-drafter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured policy covering data collected, purposes, legal bases, sharing, retention, user rights, and contact — written to be readable, not boilerplate.
