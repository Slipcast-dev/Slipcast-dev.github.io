---
name: safe-online-shopping
description: "Check whether an online store or seller is legit before you pay — and pay in a way you can get your money back if it isn't. Use when asked is this website legit, is this online store a scam, should I buy from this site, or how to shop safely online."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель для сложной проверки: **GPT-6.2 Astra**. Для узкого случая подойдёт **GPT-6.2 Sol**.
- Работай в текущей модели Codex и загружай только нужные разделы. Сравни варианты, проверь пограничные случаи и укажи остаточные риски.
- Ограничься защитной проверкой предоставленных материалов. Указывай подтверждения и меры исправления.
<!-- slipcast-model-profile:end -->


# safe-online-shopping

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a trust assessment from the store's signals (too-good pricing, contact/policy gaps, domain and review red flags), safe-payment guidance that preserves buyer protection, what to check before checkout, and what to do if you've already paid a scam site.
