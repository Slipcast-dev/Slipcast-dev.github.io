---
name: dental-recall-reactivation
description: "Build a dental recall and reactivation system that brings lapsed patients back without nagging — the segments worth contacting, the message that works for each, the cadence, and the measure that tells you whether it is working. Use when asked to improve recall rates, reactivate lapsed patients, reduce hygiene no-shows, or fill an empty hygiene column. Communications and operations only; no clinical recall interval is set here."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# dental-recall-reactivation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the patient segmentation, per-segment message templates, the contact cadence, the booking-friction fixes, and the metrics to track.
