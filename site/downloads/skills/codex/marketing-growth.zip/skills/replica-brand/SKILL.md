---
name: replica-brand
description: 'Names and rebrands an app clone so it is the user''s own: name candidates
  with the trademark, domain, store and handle checks to run, a new palette checked
  for contrast, a logo brief, a voice guide, and a sweep tool that finds anything
  of the original left in the codebase. Use when the user says "name my app", "rebrand
  the clone", "make it mine", "pick a name and colours", "logo brief", "brand voice",
  "check for leftovers", or after /replica-entrepreneur. Always runs before /replica-launch.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-brand

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

