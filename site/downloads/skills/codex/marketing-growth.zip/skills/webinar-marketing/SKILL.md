---
name: webinar-marketing
description: 'When the user wants to plan, promote, run, or improve a webinar or virtual
  event to generate and convert demand. Use when the user mentions ''webinar,'' ''virtual
  event,'' ''online event,'' ''live demo,'' ''virtual summit,'' ''workshop,'' ''masterclass,''
  ''fireside chat,'' ''roundtable,'' ''registration funnel,'' ''show-up rate,'' ''attendance
  rate,'' ''webinar promotion,'' ''webinar follow-up,'' or ''on-demand webinar.''
  Also use when they have a webinar that isn''t converting — low registrations, low
  show-up, or attendees who don''t buy — and want to diagnose and fix it. Covers the
  full funnel: registration, promotion, show-up, live engagement, live-to-close, and
  post-event nurture. Distinct from launch-strategy (full product launches) and email-sequence
  (lifecycle nurture) — this is the end-to-end webinar/event motion. NOT for in-person
  field events logistics, and NOT for generic lifecycle email (use email-sequence).'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# webinar-marketing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
