---
name: linkedin-skills
description: Use when someone wants to grow an organic LinkedIn presence — a content
  strategy for a career change or consulting or thought leadership, a rewritten profile
  or headline, post drafts and hooks, a posting cadence or newsletter plan, connection
  notes and outreach, a commenting strategy, repurposing an article or talk into posts,
  or a read on why their reach dropped. Triggers on "grow my LinkedIn", "fix my headline",
  "write a LinkedIn post", "what should I post about", "LinkedIn strategy", "connection
  request", "my reach dropped". Forks context to route to one of five sub-skills,
  and refuses automation, scraping, pods, and bulk DMs before any drafting starts.
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# linkedin-skills

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

