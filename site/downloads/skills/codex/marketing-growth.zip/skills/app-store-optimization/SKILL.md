---
name: app-store-optimization
description: App Store Optimization (ASO) toolkit for researching keywords, analyzing
  competitor rankings, generating metadata suggestions, and improving app visibility
  on Apple App Store and Google Play Store. Use when the user asks about ASO, app
  store rankings, app metadata, app titles and descriptions, app store listings, app
  visibility, or mobile app marketing on iOS or Android. Supports keyword research
  and scoring, competitor keyword analysis, metadata optimization, A/B test planning,
  launch checklists, and tracking ranking changes.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# app-store-optimization

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

