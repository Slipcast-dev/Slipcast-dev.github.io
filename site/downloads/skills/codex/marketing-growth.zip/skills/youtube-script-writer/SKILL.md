---
name: youtube-script-writer
description: "Write a high-retention YouTube script — explainer, tutorial, video essay, review, or talking head — on the packaging then cold-open then value-stack then retention structure that holds watch time past the drop-off cliffs. Use when asked to write a YouTube script, script a long-form or explainer video, draft a video hook, outline a video essay, or turn a blog post or talk into a video."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# youtube-script-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces title and thumbnail concepts, multiple hook options, a beat-by-beat body with retention devices, and clear visual and audio cues.
