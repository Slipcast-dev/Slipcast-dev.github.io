---
name: co-marketing
description: "Plan a co-marketing partnership — two brands reaching each other's audiences for mutual gain. Use when asked to plan a partnership, joint campaign, co-branded content/webinar, integration launch, or partner outreach."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# co-marketing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the partner fit rationale, a fair value exchange, the joint campaign plan, the partner pitch, and how success is split and measured.
