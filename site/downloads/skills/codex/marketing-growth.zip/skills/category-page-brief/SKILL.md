---
name: category-page-brief
description: "Plan an e-commerce category / collection page that ranks and merchandises well. Use when asked to design a category page, a PLP (product listing page), a collection page, or to improve category SEO and merchandising."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# category-page-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a brief — search intent & keywords, intro copy, merchandising/sort logic, filters & facets, internal links, and SEO/technical notes — so the page converts browsers and earns organic traffic.
