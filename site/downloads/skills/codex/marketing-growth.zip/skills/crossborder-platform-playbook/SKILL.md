---
name: crossborder-platform-playbook
description: "Use when asked Temu 全托管还是半托管, TikTok Shop 怎么入驻, 亚马逊和 Temu 选哪个, 跨境电商平台怎么选, 产品出海要哪些认证, or choose and launch on cross-border marketplaces (Temu, TikTok Shop, Amazon, SHEIN, AliExpress). For the product listing copy itself, use cross-border-listing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# crossborder-platform-playbook

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a platform fit matrix for the seller's product and capacity, the operating model of each shortlisted platform (fully managed, semi-managed or self-operated), the compliance checklist by target market, a 90-day launch plan, and the questions to ask each platform's account manager.
