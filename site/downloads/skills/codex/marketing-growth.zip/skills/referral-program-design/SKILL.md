---
name: referral-program-design
description: "Design a referral or viral-loop program that actually drives growth. Use when asked to design a referral or refer-a-friend program, build a viral/invite loop, set referral incentives, turn happy users into a growth channel, or improve word-of-mouth growth."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# referral-program-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a referral design — the loop mechanics, incentive structure (who gets what, when), the viral-math estimate (k-factor/cycle time), the unit-economics check, fraud guardrails, placement & messaging, and success metrics.
