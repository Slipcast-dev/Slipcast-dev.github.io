---
name: testimonial-request
description: "Ask happy clients for a testimonial or review the right way — timed well, easy to give, and specific enough to actually persuade future clients. Use when asked to get testimonials, ask for a review, how to request a testimonial, or get social proof from clients."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# testimonial-request

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the right moment and channel to ask, a message that makes saying yes effortless, guiding questions that yield specific results-based testimonials (not 'great to work with'), how to handle a written vs video ask, and permission/usage basics — without being pushy or fishing for praise.
