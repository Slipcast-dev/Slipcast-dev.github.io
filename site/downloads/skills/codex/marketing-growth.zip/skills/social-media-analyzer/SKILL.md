---
name: social-media-analyzer
description: Social media campaign analysis and performance tracking. Calculates engagement
  rates, ROI, and benchmarks across platforms. Use when analyzing social media performance,
  calculating engagement rate, measuring campaign ROI, comparing platform metrics,
  or benchmarking against industry standards. Also use when the user mentions "social
  media audit," "engagement rate," or "which platform performs best."
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# social-media-analyzer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

