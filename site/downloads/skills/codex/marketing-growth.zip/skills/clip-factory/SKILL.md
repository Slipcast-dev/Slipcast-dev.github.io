---
name: clip-factory
description: "Turn one long video, podcast, or stream transcript into 8-12 short-form clips — each with a hook line, cut timestamps, captions, and a platform note for TikTok/Reels/Shorts — plus an honesty gate that kills clips that misrepresent the source. Use when someone says 'clip this podcast', 'make shorts from my video', 'what's clippable here', or runs a clipping side hustle."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# clip-factory

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ranked clip sheet ready for an editor or a clipping app.
