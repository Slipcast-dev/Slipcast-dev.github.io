---
name: youtube-script
description: "Write a long-form video script for YouTube — an explainer, tutorial, video essay, review, or talking-head — built on the packaging→cold-open→value-stack→retention structure that holds watch-time past the drop-off cliffs. Use when asked to script a YouTube video, write a long-form or explainer/tutorial video script, outline a video essay, or turn a blog post/talk into a video. Distinct from [[short-form-script]] (15–60s vertical)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# youtube-script

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces title + thumbnail concepts, a timed cold open, a segmented body with retention devices and B-roll cues, integrated CTAs, an outro/end-screen, and a description with chapter timestamps.
