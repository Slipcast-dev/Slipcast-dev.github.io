---
name: douyin-script
description: "Write a short-video script for 抖音 (Douyin) or similar vertical-video platforms: a hook in the first three seconds, a shot-by-shot plan with on-screen text, spoken lines timed to the length, and a cover and caption. Use when asked 帮我写抖音脚本, 短视频脚本, 分镜脚本, 视频开头怎么抓人, or write a Douyin video script."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# douyin-script

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the hook options, a timed shot list with visuals, voice-over and on-screen text, the caption and tags, the cover frame, and a compliance check of claims.
