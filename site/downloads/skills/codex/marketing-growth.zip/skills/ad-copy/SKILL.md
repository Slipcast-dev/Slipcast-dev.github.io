---
name: ad-copy
description: "Write platform-native paid ad copy with multiple angles to test. Use when asked to write ad copy, Google/Facebook/LinkedIn/Instagram ads, PPC headlines, or paid social creative copy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ad-copy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready-to-ship variants per platform (headlines, primary text, descriptions, CTAs) across distinct angles, sized to each platform's limits, with a note on what each variant tests.
