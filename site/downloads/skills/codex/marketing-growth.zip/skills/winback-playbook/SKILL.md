---
name: winback-playbook
description: "Turn an at-risk or churned account into a save play — root-cause hypothesis, the offer ladder, the outreach sequence, and the honest call on when to let go. Use when asked to save a churning customer, build a win-back plan, re-engage a lost account, or stop a renewal from slipping."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# winback-playbook

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the churn diagnosis, a ranked set of save levers, a timed outreach sequence, and the walk-away line so you don't over-invest in an account that's gone.
