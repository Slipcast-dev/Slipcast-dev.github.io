---
name: xiaohongshu-note
description: "Write a 小红书 (Xiaohongshu, RED) note that reads like a real person's experience: a scroll-stopping title, cover text, a body built on specific personal detail, tags, and a compliance check against restricted advertising words. Use when asked 帮我写小红书笔记, 小红书标题, 种草文案, 小红书怎么写才有流量, or write a Xiaohongshu post."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# xiaohongshu-note

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces three title options, cover image text, the note body in the platform's style, tags, an engagement question, a check of restricted words and undisclosed advertising, and notes for the images.
