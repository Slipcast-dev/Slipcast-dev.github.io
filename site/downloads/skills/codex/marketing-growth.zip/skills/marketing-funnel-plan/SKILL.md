---
name: marketing-funnel-plan
description: "Plan a full-funnel marketing strategy from awareness to retention. Use when asked to build a marketing funnel, map the customer journey to tactics, plan demand generation, or diagnose where a funnel leaks."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# marketing-funnel-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a funnel plan — stage definitions, the metric and conversion target per stage, channels & tactics, the biggest leak, and a 90-day focus.
