---
name: marketing-demand-acquisition
description: Creates demand generation campaigns, optimizes paid ad spend across LinkedIn,
  Google, and Meta, develops SEO strategies, and structures partnership programs.
  Use when planning demand gen strategy, growth marketing, advertising campaigns,
  PPC optimization, lead generation, pipeline generation, or marketing budgets. Covers
  multi-channel acquisition (Google Ads, LinkedIn Ads, Meta Ads), CAC analysis, MQL/SQL
  workflows, attribution modeling, technical SEO, and co-marketing partnerships. Default
  calibration profile is a Series A+ B2B SaaS scaling internationally (EU/US/Canada,
  hybrid PLG/Sales-Led) — adapt benchmarks for other stages and motions rather than
  skipping the skill.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# marketing-demand-acquisition

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

