---
name: linkedin-engagement
description: Use when someone wants to grow reach through comments, replies, groups,
  or outreach on LinkedIn — a commenting roster, a connection request note, a DM or
  InMail, a networking plan, or a check on whether their outreach volume is safe.
  Triggers on "who should I engage with", "write a connection request", "cold DM",
  "LinkedIn outreach", "networking strategy", "how many invites can I send". Builds
  a weekly comment roster inside a real time budget, assembles one message at a time
  and refuses templates, and caps volume against LinkedIn's limits. Nothing is ever
  sent.
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# linkedin-engagement

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

