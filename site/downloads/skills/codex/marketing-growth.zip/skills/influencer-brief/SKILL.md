---
name: influencer-brief
description: "Create a structured brief for an influencer or creator partnership campaign. Use when asked to brief an influencer, plan a creator collaboration, set up a paid partnership, or define deliverables for a sponsored content campaign."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# influencer-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete campaign brief with objectives, deliverables, creative guidelines, approval process, and performance metrics.
