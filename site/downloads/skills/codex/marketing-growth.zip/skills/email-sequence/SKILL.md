---
name: email-sequence
description: "Write a multi-email nurture/onboarding/launch sequence with a goal per email. Use when asked to write an email sequence, a welcome/onboarding series, a nurture drip, a launch sequence, or a re-engagement series."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# email-sequence

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sequence map (trigger, timing, goal per email) plus the full copy for each email — subject, body, and one CTA — designed to move the reader one step at a time.
