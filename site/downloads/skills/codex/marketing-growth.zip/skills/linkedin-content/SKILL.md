---
name: linkedin-content
description: Use when someone wants to write, edit, or lint a LinkedIn post — a story,
  how-to, opinion piece, carousel script, video script, or poll — or wants an article,
  talk, or transcript repurposed into posts. Triggers on "write a LinkedIn post",
  "is this hook any good", "review my post", "turn this into LinkedIn posts", "carousel",
  "what format should this be". Lints posts 0-100 on mechanics, hook, integrity, and
  accessibility; picks the format the material actually supports; and splits long
  sources into standalone units with a reuse ledger.
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# linkedin-content

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

