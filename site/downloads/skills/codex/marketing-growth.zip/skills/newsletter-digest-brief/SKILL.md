---
name: newsletter-digest-brief
description: "Turn a pile of newsletters and subscriptions into one skimmable brief — the items that matter to YOUR interests extracted with sources, the noise dropped with a count, on a cadence that replaces daily trickle-reading. Use when asked digest my newsletters, summarize what my subscriptions said this week, what did I miss that I actually care about, or make my reading pile useful."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# newsletter-digest-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the interest-filtered brief with per-item sources, the dropped-with-reasons ledger, and the cadence that makes trickle-reading obsolete.
