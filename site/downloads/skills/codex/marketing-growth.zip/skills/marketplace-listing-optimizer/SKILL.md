---
name: marketplace-listing-optimizer
description: "Audit and optimize a marketplace listing (Amazon, Etsy, eBay, Walmart) to rank and convert. Use when asked to optimize an Amazon/Etsy listing, improve marketplace SEO, fix a product listing that isn't selling, or write keyword-rich titles and bullets."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# marketplace-listing-optimizer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a prioritised optimization — title, bullets, backend keywords, A+/description, images plan, and conversion fixes — mapped to how that marketplace ranks and shoppers decide.
