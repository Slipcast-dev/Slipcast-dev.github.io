---
name: retention-loop-design
description: "Design retention and engagement loops that bring users back. Use when asked to improve retention, design an engagement/habit loop, fix a leaky retention curve, or build a re-engagement system."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# retention-loop-design

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a retention design — the retention curve diagnosis, the core habit loop (trigger→action→reward→investment), the activation→habit path, re-engagement triggers, and the metrics to watch.
