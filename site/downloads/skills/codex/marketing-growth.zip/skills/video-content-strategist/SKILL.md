---
name: video-content-strategist
description: 'Use when planning video content strategy, writing video scripts, optimizing
  YouTube channels, building short-form video pipelines (Reels, TikTok, Shorts), or
  repurposing long-form content into video. Triggers: ''start a YouTube channel'',
  ''video content strategy'', ''write a video script'', ''repurpose into video'',
  ''YouTube SEO'', ''short-form video''. NOT for written blog content (use content-production).
  NOT for social captions without video (use social-media-manager).'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# video-content-strategist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
