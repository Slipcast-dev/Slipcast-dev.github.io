---
name: aeo
description: Answer Engine Optimization (AEO) skill — optimize content to be cited
  by AI language models (ChatGPT, Perplexity, Claude, Gemini, Mistral) as authoritative
  sources. Distinct from SEO — AEO optimizes for citation in LLM-generated responses,
  not search rankings. Use when planning content for AI-first search audiences, auditing
  existing content for E-E-A-T signals, tracking which pages get cited by which LLMs,
  or building a citation-friendly content strategy. Triggers — 'AEO audit', 'optimize
  for ChatGPT', 'get cited by Perplexity', 'LLM citation strategy', 'answer engine
  optimization', 'content for AI search', 'E-E-A-T audit'. Output is a markdown audit
  report (default) or JSON for pipeline integration. Stdlib-only Python tools.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# aeo

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

