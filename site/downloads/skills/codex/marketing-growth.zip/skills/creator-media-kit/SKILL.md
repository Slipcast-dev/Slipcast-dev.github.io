---
name: creator-media-kit
description: "Build a creator's sponsorship media kit and brand-deal outreach — the one-pager brands ask for, plus a pitch email and a rate card. Use when asked to make a media kit, pitch a brand, land a sponsorship, write a brand-deal email, or set creator rates. The creator side of a sponsorship — distinct from a brand briefing a creator."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# creator-media-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured media kit (audience, stats, offerings, past work), a personalised outreach email, and a defensible rate card.
