---
name: marketing-psychology
description: "Apply behavioral-psychology principles to a marketing asset or decision — ethically. Use when asked to make copy/a page/an offer more persuasive, apply psychological triggers, reduce friction, or understand why something does/doesn't convert."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# marketing-psychology

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the relevant principles (social proof, scarcity, anchoring, loss aversion, etc.), how to apply each to the specific asset, and a line on staying ethical (no dark patterns).
