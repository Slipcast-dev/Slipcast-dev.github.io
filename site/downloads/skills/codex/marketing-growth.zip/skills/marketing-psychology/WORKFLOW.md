# Marketing Psychology Skill

People don't decide rationally — they use mental shortcuts. Marketing psychology applies those predictably and
**honestly**: real social proof, true scarcity, sensible defaults, clear framing. This skill diagnoses an asset
or decision through behavioral principles and gives concrete, specific applications — while drawing a hard line
at manipulation and dark patterns (which win a click and lose the trust).

## Required Inputs

Ask for these only if they aren't already provided:

- **The asset or decision** — the page/email/offer/pricing/CTA you want to make more persuasive.
- **Audience & context** — who it's for, their mindset, where they are in the funnel.
- **The goal & the friction** — the action you want, and what's holding people back (cost, risk, effort, trust, confusion).
- **What's true** — real proof points, actual constraints (so applications are honest, not invented).

## Output Format

### Marketing psychology: [asset]

**The decision & the friction** — what you want the person to do and the specific barrier (risk? effort? trust? price?). This selects the principles.

**Principles that apply (ranked)** — the few most relevant, each with a *specific* application to this asset:

| Principle | Why it fits the friction | Concrete application here |
|---|---|---|
| Social proof | | (e.g. "show '2,300 teams use this' near the CTA") |
| Loss aversion / framing | | |
| Anchoring | | |
| Scarcity / urgency (only if real) | | |
| Commitment & consistency | | |
| Reciprocity | | |
| Reducing friction (defaults, fewer choices) | | |

(Pick the relevant ones — not all of them. Friction-reduction often beats adding persuasion.)

**Rewrites / changes** — 1–3 concrete before→after edits applying the top principles.

**Ethics line** — flag anything that would be a dark pattern (fake scarcity, forced continuity, confirm-shaming, hidden costs) and why to avoid it. Real beats manufactured — it converts *and* retains.

## Quality Checks

- [ ] The principles chosen are matched to the actual friction, not a generic checklist
- [ ] Each principle has a specific, concrete application to *this* asset (not theory)
- [ ] Scarcity/urgency is only used where it's genuinely true
- [ ] At least one friction-reduction move is considered (often higher-leverage than persuasion)
- [ ] An ethics line flags dark patterns and keeps applications honest

## Anti-Patterns

- [ ] Do not invent fake scarcity, countdowns, or fake social proof — it's a dark pattern and it backfires
- [ ] Do not list every principle — pick the few that fit the specific friction
- [ ] Do not stay theoretical — every principle needs a concrete application to the asset
- [ ] Do not use confirm-shaming, forced continuity, or hidden costs — short-term lift, long-term trust loss
- [ ] Do not ignore friction — sometimes the fix is removing a step, not adding persuasion

## Based On

Behavioral economics & persuasion research (Cialdini's principles, Kahneman framing/loss aversion, Fogg behavior model) — applied ethically.

## Example Trigger Phrases

- "Make copy/a page/an offer more persuasive."
- "Apply psychological triggers."
- "Reduce friction."
- "Understand why something does/doesn't convert."
