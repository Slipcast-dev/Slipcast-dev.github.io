---
name: cto-review
description: /c-level-agents:cto-review [plan] — Architecture and scaling interrogation.
  Tech debt, scaling cliffs, team scaling, build-vs-buy. Use when committing to an
  architecture, planning for 10x load, or weighing a rebuild against a vendor.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# cto-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
