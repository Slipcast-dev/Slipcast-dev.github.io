---
name: side-business-setup
description: "Set up a side business in the right order — the do-first sequence (separate money, basic terms, simple records) vs. the feels-official-but-waits list (logos, LLCs-by-default, office chairs), with the structure question framed honestly and routed properly. Use when asked I'm starting a side business what do I need, do I need an LLC, set up my side hustle properly, or what comes first legally and financially."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# side-business-setup

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ordered setup sequence, the structure-decision framing (jurisdiction-flagged, professional-routed), the money-hygiene rules, and the employer-conflict check most people skip.
