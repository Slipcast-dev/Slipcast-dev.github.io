---
name: board-pre-read
description: "Write a board pre-read that's sent before the meeting so the meeting is about decisions, not status. Use when asked to prepare a board pre-read, a board update/package, or pre-meeting materials for a board."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# board-pre-read

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a board pre-read — a TL;DR, the metrics dashboard vs. plan, what's working / what's not, the decisions and asks for the board, and risks — designed to be read in advance.
