---
name: board-minutes
description: "Write formal board meeting minutes from an agenda, notes, transcript, or discussion summary. Use when asked to draft board minutes, governance minutes, meeting minutes for a board, or a formal record of decisions and actions."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# board-minutes

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces structured board minutes with attendees, agenda items, resolutions, decisions, action register, and approval-ready wording.
