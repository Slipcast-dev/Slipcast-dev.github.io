---
name: onboard
description: /cs-onboard — Founder interview that populates ~/.claude/company-context.md
  using the canonical 7-dimension cs-onboard schema. The first command to run when
  starting with c-level-agents. Use when setting up the virtual C-suite for a new
  company, or when advisors lack company context — e.g. before a first /c-level-agents:boardroom
  or after a fundraise changes the numbers.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# onboard

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
