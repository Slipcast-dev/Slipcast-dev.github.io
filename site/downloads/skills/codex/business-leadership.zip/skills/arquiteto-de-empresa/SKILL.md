---
name: arquiteto-de-empresa
description: 'Company Architect: builds a business from scratch as an OKF (Open Knowledge
  Format) bundle — a tree of version-controllable .md files with frontmatter type,
  links forming a graph, and reserved index.md/log.md, readable by humans and agents.
  Guides the founder through a 12-phase interview (foundation, strategy, market, financial,
  sales, marketing, product, operations, tech, people, legal, governance), one phase
  at a time, few questions per block, and generates the concepts as conformant markdown.
  Trigger when the user wants to create, structure, or document an entire company
  in folders and .md files; when they mention build my company from scratch, company
  as code, company knowledge base for AI to read, company wiki for agents, OKF, or
  knowledge bundle. In English.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# arquiteto-de-empresa

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- В исходном наборе не разрешён ресурс ../00-fundacao/identidade.md. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс ../01-estrategia/proposta-de-valor.md. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс identidade.md. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
- В исходном наборе не разрешён ресурс problema-solucao.md. Не считай его прочитанным; используй доступные материалы и явно укажи ограничение, если он необходим задаче.
