---
name: cfo-review
description: /c-level-agents:cfo-review [plan] — Numerate-skeptic interrogation of
  any plan that touches money. Unit economics, runway, dilution, capital allocation.
  Use when a plan commits meaningful spend — e.g. a hiring wave, a fundraise decision,
  or a new channel budget.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# cfo-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
