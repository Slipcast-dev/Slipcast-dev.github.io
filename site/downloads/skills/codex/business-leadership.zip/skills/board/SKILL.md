---
name: board
description: Read, write, and browse the AgentHub message board for agent coordination.
  Use when the user runs /hub:board or asks to post, read, or inspect coordination
  messages between competing AgentHub agents.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# board

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

