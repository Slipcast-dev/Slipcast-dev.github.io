---
name: office-hours
description: /c-level-agents:office-hours [topic] — YC-style 6-question founder interrogation
  before any advice. Forces clarity on problem, customer, distribution, defensibility,
  capital, and founder fit. Use when a founder question is too vague to route — e.g.
  'should we grow faster?' — or before drafting a strategy brief.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# office-hours

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

