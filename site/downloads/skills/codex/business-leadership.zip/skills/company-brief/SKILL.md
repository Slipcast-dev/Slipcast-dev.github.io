---
name: company-brief
description: "Build a candidate's research brief on a company before an application or interview. Use when asked to research a company for a job, prep a company brief before an interview, or understand a prospective employer fast."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# company-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page brief — what they do & how they make money, recent news & trajectory, product & competitors, likely challenges, culture signals, and smart questions to ask.
