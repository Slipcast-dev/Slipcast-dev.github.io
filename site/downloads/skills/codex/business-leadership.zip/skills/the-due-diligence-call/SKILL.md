---
name: the-due-diligence-call
description: "Simulate the due-diligence call where an acquirer's or investor's analyst takes your metrics apart — the questions behind the spreadsheet, the moment a number wobbles, and a debrief on which answers create risk. Use when asked simulate due diligence on my startup, stress-test my metrics before the raise, what will the acquirer's analyst ask, or prep me for the DD call."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-due-diligence-call

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the call transcript with the analyst's private notes, the internal memo they write afterward, and a debrief separating fixable presentation from fix-the-business findings.
