---
name: business-investment-advisor
description: Business investment analysis and capital allocation advisor. Use when
  evaluating whether to invest in equipment, real estate, a new business, hiring,
  technology, or any capital expenditure. Also use for ROI calculations, IRR, NPV,
  payback period, build vs buy decisions, lease vs buy analysis, vendor evaluation,
  or deciding where to allocate limited budget for maximum return.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# business-investment-advisor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

