---
name: executive-presence
description: "Sharpen how you show up in high-stakes rooms — communicate with gravitas, concision, and confidence. Use when asked to improve executive presence, prepare to present to leadership, sound more senior, command a room, or get coaching before a big meeting."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# executive-presence

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces specific guidance — how to open, structure answers (BLUF/headline-first), handle tough questions, project calm, and the habits to drop, tuned to the moment.
