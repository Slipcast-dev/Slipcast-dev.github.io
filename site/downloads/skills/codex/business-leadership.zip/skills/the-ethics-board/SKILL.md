---
name: the-ethics-board
description: "Simulate defending your study or protocol before an ethics committee — the consent-comprehension probe, the vulnerable-participant challenge, the minimal-risk fight, the data-retention question you did not prepare for — with a debrief mapping every wobble to the protocol section that needs rewriting. Use when asked to prepare for an IRB or ethics review, rehearse an ethics-committee defence, why might ethics reject my study, or practice my protocol presentation. Rehearsal only — never a substitute for actual review."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-ethics-board

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the review transcript with board file notes, the vulnerability map, and the revision list in the board's vocabulary.
