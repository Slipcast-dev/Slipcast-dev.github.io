---
name: cco-review
description: /c-level-agents:cco-review [plan] — Retention-obsessed Chief Customer
  Officer interrogation of any plan that touches customer retention, segmentation,
  CS team sizing, or CS team hiring. Use when gross retention is slipping, before
  approving CSM headcount, or when deciding which customer segments to keep or fire.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# cco-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
