---
name: business-name-fit
description: Suggest, pick, or vet a business, startup, or product name that stays
  true to the founder's cultural origin while working professionally in the markets
  they want to sell into. Use when someone is naming a company, brand, or product
  and cares about how it lands across languages and regions — for example a name that
  sounds right at home but might read oddly to English speakers, or an authentic name
  they want to check before committing. Trigger this for any request about choosing
  a business name, checking if a name "works" abroad, spotting bad meanings in other
  languages, or making a name sound trustworthy in a specific market — even if the
  person doesn't say the word "skill".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# business-name-fit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

