---
name: company-event-ops
description: "Run a company event — the launch party, the customer day, the team celebration — as the operation it is: the goal that shapes every choice, the budget with its forgotten lines, the vendor and venue coordination, the run-of-show with owners, and the day-of roles that keep hosts hosting. Use when asked plan the company event, organize our customer day/holiday party/launch event, what am I forgetting for this event, or be the run-of-show for Thursday."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# company-event-ops

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the goal-shaped plan, the budget with the forgotten lines, the run-of-show, and the day-of role card.
