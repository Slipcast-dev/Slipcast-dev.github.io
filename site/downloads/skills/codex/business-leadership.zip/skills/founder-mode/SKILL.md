---
name: founder-mode
description: /c-level-agents:founder-mode [question] — Auto-routes any founder question
  to the right C-role advisor or to /c-level-agents:boardroom for multi-role topics.
  The single-command entry point. Use when a founder asks any strategic question without
  knowing which advisor or command fits — e.g. 'runway pressure' routes to the CFO,
  'gross retention dropped' routes to the CCO.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# founder-mode

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
