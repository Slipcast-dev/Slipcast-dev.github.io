---
name: pitch-vs-teach
description: "Know which talk you're giving — the pitch (drive one decision) vs. the teach (build understanding) — because mixing their structures fails both, and most bad presentations are one wearing the other's clothes. Use when asked is this a pitch or a training, my informative deck didn't land the ask, my pitch felt like a lecture, or structure this talk for the right job."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pitch-vs-teach

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the mode diagnosis, the structural implications, the mixed-mandate split, and the mode-check on an existing deck.
