---
name: replica-entrepreneur
description: Researches the app being cloned and reads what its real users say in
  public reviews (App Store, Google Play, G2, Capterra, Trustpilot, Reddit, Hacker
  News, its own feature-request board), then ranks what they hate, what is missing
  and what is unsolved, turns it into a fix plan for the clone and a positioning angle
  you can sell. Every quote is real, verbatim and linked. Use when the user says "what
  do people hate about X", "read the reviews", "how do I make mine better", "find
  the gap", "what features are missing", "how do I position this", "make it sellable",
  or after /replica-diff.
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-entrepreneur

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

