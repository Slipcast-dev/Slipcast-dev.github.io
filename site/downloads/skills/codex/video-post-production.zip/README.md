# Монтаж и постобработка видео / Video editing and post-production · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Подготовка исходников, монтаж, звук, цвет и проверка экспорта.

Ingest, edits, audio, color and export checks.

Рекомендуемый порядок / Suggested order:

1. [video-editorial-ingest](skills/video-editorial-ingest/SKILL.md)
2. [video-master-export-qc](skills/video-master-export-qc/SKILL.md)
