---
name: value-proposition
description: "Craft a sharp value proposition that says who it's for, the outcome, and why you over the alternative. Use when asked to write a value prop, a value proposition, a one-liner, or to clarify 'what do we even say we do?'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# value-proposition

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a primary value-prop statement, a plain-language one-liner, 3 benefit-led variations, and the before→after transformation it promises — ready to headline a landing page.
