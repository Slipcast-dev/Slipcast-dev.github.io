---
name: hard-call
description: /em:hard-call — Framework for decisions with no good options. Use when
  every option is painful and a structured 10/10/10 + regret-minimization pass is
  needed — e.g. choosing between a layoff and a down round, or killing a beloved product
  line.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# hard-call

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

