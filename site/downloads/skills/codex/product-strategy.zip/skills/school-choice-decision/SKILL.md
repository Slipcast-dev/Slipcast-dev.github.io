---
name: school-choice-decision
description: "Choose the right school for a specific child by weighing what actually matters to them and your family — not just rankings. Use when asked how to choose a school, compare schools for my kid, which school is best, or help me decide on a school."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# school-choice-decision

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a priorities profile for this child, a comparison of the options on the factors that matter (fit, teaching, environment, logistics, cost), the questions to ask and things to observe on visits, a weighted decision, and a note that a good fit beats a high ranking.
