---
name: discovery-eyes
description: "Read your team's messages the way opposing counsel would in litigation discovery — prevention training that makes communication hygiene visceral. Use when asked how would our Slack look in discovery, train my team on communication hygiene, review this thread like a plaintiff's lawyer, or what shouldn't we put in writing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# discovery-eyes

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the highlighted-exhibit reading of sample messages, the patterns that create legal risk, and a debrief with the write-it-this-way rules — strictly for prevention, never for concealment.
