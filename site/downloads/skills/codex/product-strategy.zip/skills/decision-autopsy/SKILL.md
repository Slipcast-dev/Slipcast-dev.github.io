---
name: decision-autopsy
description: 'Judge a past decision by its PROCESS, not its outcome — because good
  decisions lose and bad decisions win, and teams that can''t tell the difference
  learn the wrong lessons. Use when reviewing a big call after the fact (a bet that
  failed, a pass that haunts, a hire, a pivot) and the room is about to conclude ''it
  failed so it was wrong.'' Produces a process-forensics report: what was knowable
  then, the quality grade of the decision as-made, the luck accounting, and the ONE
  process change worth keeping.'
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# decision-autopsy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

