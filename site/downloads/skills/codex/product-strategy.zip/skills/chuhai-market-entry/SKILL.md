---
name: chuhai-market-entry
description: "Plan a Chinese company's entry into an overseas market (出海): choose the market with evidence, then plan entity, payments, localisation, compliance, channels and team for the first twelve months. Use when asked 出海计划, 我们要进入东南亚 / 中东 / 欧洲 / 美国市场, how should a Chinese company expand overseas, or a go-global plan. Bilingual output on request."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# chuhai-market-entry

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a market scorecard, a twelve-month entry plan by workstream, the compliance and data checklist for the chosen market, and the top risks with mitigations.
