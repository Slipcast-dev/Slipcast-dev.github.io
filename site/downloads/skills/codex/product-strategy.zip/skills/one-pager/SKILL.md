---
name: one-pager
description: "Distil anything — a startup, product, project, or idea — into a single persuasive page. Use when asked to make a one-pager, a one-page summary, a leave-behind, a startup/product one-sheet, or a tl;dr brief."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# one-pager

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured single page — headline + tagline, the problem, the solution, why-now/proof, and a clear ask/CTA — designed to be skimmed and remembered, ready to export as a typeset PDF.
