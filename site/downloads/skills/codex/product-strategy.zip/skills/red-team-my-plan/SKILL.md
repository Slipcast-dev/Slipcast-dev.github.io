---
name: red-team-my-plan
description: "Attack your own plan the way a smart adversary would — find the weakest point, the thing you're hoping nobody notices, and where it breaks under pressure. Use when asked to red-team this, attack my plan, find the holes, or where does this break."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# red-team-my-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an adversarial breakdown of the plan's weakest points, the single move an opponent (or reality) would make to break it, the part you're quietly hoping holds, and the fixes that close the biggest gaps — a hostile stress-test done by your own side, before someone else does it for real.
