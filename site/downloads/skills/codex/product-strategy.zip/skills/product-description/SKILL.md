---
name: product-description
description: "Write a product description / listing that sells and ranks. Use when asked to write a product description, e-commerce listing copy, a product page, or to rewrite a flat product blurb."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# product-description

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces benefit-led listing copy — a hook, scannable feature→benefit bullets, specs, an SEO-aware title and keywords, and trust/again-objection elements — tuned to the buyer and channel.
