---
name: competitor-alternatives
description: 'When the user wants to create competitor comparison or alternative pages
  for SEO and sales enablement. Also use when the user mentions ''alternative page,''
  ''vs page,'' ''competitor comparison,'' ''comparison page,'' ''[Product] vs [Product],''
  ''[Product] alternative,'' ''competitive landing pages,'' ''switch from competitor,''
  or ''comparison content.'' Covers four formats: singular alternative, plural alternatives,
  you vs competitor, and competitor vs competitor. Emphasizes deep research, modular
  content architecture, and varied section types beyond feature tables.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# competitor-alternatives

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
