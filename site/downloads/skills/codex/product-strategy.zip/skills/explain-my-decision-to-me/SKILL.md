---
name: explain-my-decision-to-me
description: "Talk through a decision out loud with a patient thinking partner that reflects your reasoning back, so the answer you already half-know becomes clear. Use when asked help me think this through, I need to talk this out, be my sounding board, or I don't know what I actually think."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# explain-my-decision-to-me

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured reflection of your own reasoning — what you've actually said, the values driving it, the contradictions and gaps, and the question that would clarify it — acting as a rubber-duck / sounding board rather than handing you an answer you didn't reach yourself.
