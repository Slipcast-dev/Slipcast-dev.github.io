---
name: senior-pm
description: Senior Project Manager for enterprise software, SaaS, and digital transformation
  projects. Specializes in portfolio management, quantitative risk analysis, resource
  optimization, stakeholder alignment, and executive reporting. Uses advanced methodologies
  including EMV analysis, Monte Carlo simulation, WSJF prioritization, and multi-dimensional
  health scoring. Use when a user needs help with project plans, project status reports,
  risk assessments, resource allocation, project roadmaps, milestone tracking, team
  capacity planning, portfolio health reviews, program management, or executive-level
  project reporting — especially for enterprise-scale initiatives with multiple workstreams,
  complex dependencies, or multi-million dollar budgets.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# senior-pm

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

