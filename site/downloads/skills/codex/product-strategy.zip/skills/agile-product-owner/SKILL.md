---
name: agile-product-owner
description: Agile product ownership for backlog management and sprint execution.
  Covers user story writing, acceptance criteria, sprint planning, and velocity tracking.
  Use when writing user stories, creating acceptance criteria, planning sprints, estimating
  story points, breaking down epics, or prioritizing the backlog.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# agile-product-owner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

