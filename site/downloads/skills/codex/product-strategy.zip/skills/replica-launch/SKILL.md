---
name: replica-launch
description: 'Writes the launch for an app clone: the landing page built on the positioning
  angle, pricing set against the original''s public pricing and its users'' complaints,
  and the App Store and Google Play listing linted against the stores'' limits and
  copycat rules. Use when the user says "landing page", "pricing", "how much should
  I charge", "App Store listing", "store screenshots", "launch plan", "Product Hunt",
  or after /replica-brand.'
metadata:
  source-package: replica-skill-main
  adapted-for: Codex
---

# replica-launch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

