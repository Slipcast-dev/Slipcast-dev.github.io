---
name: red-team-review
description: "Stress-test a plan, strategy, PRD, or launch by simulating hostile expert personas who attack it from every angle. Use when asked to red-team, stress-test, pre-mortem, pressure-test, play devil's advocate, or find the blind spots in a plan before committing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# red-team-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a per-persona critique, a ranked list of the most dangerous risks, a pre-mortem, and the specific changes that would most strengthen the plan.
