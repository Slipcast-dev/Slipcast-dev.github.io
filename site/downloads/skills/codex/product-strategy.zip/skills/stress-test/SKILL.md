---
name: stress-test
description: /em:stress-test — Business assumption stress testing. Use before betting
  on a plan whose core assumptions are unvalidated — e.g. stress-testing 'enterprise
  buyers will tolerate a 6-month pilot' or a hockey-stick revenue model.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# stress-test

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

