---
name: the-2-minute-launch
description: "Break the paralysis on the thing you keep not starting with a 2-minute launch sequence — a countdown into motion before the resistance can win. Use when asked I keep putting this off, help me finally start, I've been avoiding this for days, or I can't make myself begin."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-2-minute-launch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a diagnosis of what flavor of resistance is stopping you, a 2-minute launch move matched to it, a literal countdown into action, and a bare-minimum win definition — designed to convert avoidance into motion in the next 120 seconds, not to make a plan for later.
