---
name: strategy-memo
description: "Write a strategy memo that commits to a bet and says what you won't do. Use when asked to write a strategy memo, articulate a strategy, make the case for a strategic direction, or align the team on where to focus."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# strategy-memo

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a strategy memo — the strategic question, the diagnosis, the bet/approach, why now, explicit non-goals (what we're NOT doing), how we'll know it's working, and the risks.
