---
name: decision-meeting-format
description: "Run meetings that actually decide — the pre-read-then-decide format, the options-on-the-table rule, the decider named before debate starts, and the recorded-or-it-didn't-happen close. Use when asked run this decision meeting, we discuss forever and never decide, structure the meeting where we pick the vendor/plan/design, or why do our decisions get relitigated."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# decision-meeting-format

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the meeting design: pre-read, the in-room sequence, the decision rule, and the recording that makes it stick.
