---
name: freeze
description: /c-level-agents:freeze [decision] [days] — Lock a strategic decision
  for a cooldown period to prevent impulse reversal. Mirrors gstack's safety primitives
  for the business layer. Use when an irreversible decision was made under pressure
  — e.g. a layoff plan or multi-year contract — and deserves a cooling-off lock before
  execution.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# freeze

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
