---
name: product-strategist
description: Strategic product leadership toolkit for Head of Product covering OKR
  cascade generation, quarterly planning, competitive landscape analysis, product
  vision documents, and team scaling proposals. Use when creating quarterly OKR documents,
  defining product goals or KPIs, building product roadmaps, running competitive analysis,
  drafting team structure or hiring plans, aligning product strategy across engineering
  and design, or generating cascaded goal hierarchies from company to team level.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# product-strategist

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

