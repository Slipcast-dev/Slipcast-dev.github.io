---
name: decision-when-tired
description: "Make a decent decision when you're too depleted to think well — a low-energy protocol that protects you from bad tired-brain choices. Use when asked I'm too tired to decide, help me choose I'm exhausted, I can't think straight right now, or should I even decide this now."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# decision-when-tired

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a first check on whether this decision can simply wait until you're rested, and if not, a minimal-effort path to a safe-enough choice (default to reversible, avoid the tired-brain traps, use a simple rule) — because decisions made depleted are predictably worse, and the best move is often not to make them now.
