---
name: decision-helper
description: "Help me decide between options with a weighted pros/cons that actually reaches a recommendation — not just two lists. Use when asked should I take job A or B, which one should I buy, help me decide, or make a pro/con list."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# decision-helper

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the criteria that matter (weighted by what you care about), the options scored against them, a clear recommendation with its confidence, and the single question that would flip the decision if you're still torn.
