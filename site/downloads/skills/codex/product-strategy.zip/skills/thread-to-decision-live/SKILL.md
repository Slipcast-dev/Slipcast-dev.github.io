---
name: thread-to-decision-live
description: Turn a REAL Slack thread (or channel) into a logged decision — read it,
  extract what was decided, who owns what, and record it in Notion — not a template
  for writing decisions. Use when asked to capture the decision from this thread,
  log what we agreed, turn this Slack discussion into a decision record, or close
  this out in Cowork. Reads the thread via the Slack connector, distils the decision
  / owners / next steps / open questions, and produces a decision-record artifact
  written to a Notion database (with the source thread linked).
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# thread-to-decision-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

