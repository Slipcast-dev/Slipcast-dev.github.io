---
name: decision-panel
description: "Run a decision past a panel of clashing advisors — an optimist, a pessimist, a numbers person, an ethicist, and future-you — then get a chair's verdict. Use when asked to help me decide, weigh this decision, what should I do about, or run this by different advisors."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# decision-panel

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces each advisor's honest take on the decision (each committed to their lens), where they disagree most, the question that would break the tie, and a chair's recommendation that weighs the panel — turning a lonely choice into a structured board meeting.
