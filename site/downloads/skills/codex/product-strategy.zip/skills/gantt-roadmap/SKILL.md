---
name: gantt-roadmap
description: "Turn a plan or set of milestones into a timeline / Gantt chart. Use when asked to build a roadmap, schedule phases, show a project timeline, or visualize what happens when."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# gantt-roadmap

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ready-to-render Mermaid Gantt chart (renders live, exportable as PNG/SVG) — and, because it has real dates, the result also exports to a calendar (.ics) — plus notes on the critical path and risks.
