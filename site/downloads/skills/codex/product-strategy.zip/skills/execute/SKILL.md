---
name: execute
description: /c-level-agents:execute [decision] — Generate a 90-day execution plan
  with weekly milestones, DRIs, and check-in cadence from an approved decision. Use
  when a logged decision needs to become an operating plan — e.g. turning an approved
  market-entry call into weekly milestones with DRIs.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# execute

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
