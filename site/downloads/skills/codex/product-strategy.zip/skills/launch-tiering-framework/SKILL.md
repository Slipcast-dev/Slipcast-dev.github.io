---
name: launch-tiering-framework
description: "Tier a product launch (T1/T2/T3) and scope the right go-to-market effort. Use when asked to decide a launch tier, right-size launch activities, build a launch tiering framework, or plan channels and effort proportional to a launch's impact."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# launch-tiering-framework

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tiering recommendation with the scoring rationale, the activities and channels for that tier, owners, and a lightweight launch checklist.
