---
name: assumption-bounty
description: "Extract every hidden assumption from a plan or document and put a price on each one — what it costs if wrong, what it costs to test. Use when about to commit to anything whose author says 'obviously' or whose spreadsheet has hardcoded cells: the bounty hunt makes the invisible load-bearing beliefs explicit and tells you which three to test this week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# assumption-bounty

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the assumption ledger (priced and ranked), the cheapest test for each dangerous one, and the document's honest confidence statement.
