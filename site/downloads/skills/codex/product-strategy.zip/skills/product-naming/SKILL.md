---
name: product-naming
description: "Generate and evaluate names for a product, feature, or release. Use when asked to name a product/feature/company, brainstorm naming options, or choose between name candidates."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# product-naming

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a shortlist of names across naming strategies, each with rationale, plus an evaluation against clear criteria (clarity, fit, memorability, availability checks to run) and a recommendation — not just a random list.
