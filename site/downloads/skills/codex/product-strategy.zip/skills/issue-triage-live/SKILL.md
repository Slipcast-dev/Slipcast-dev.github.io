---
name: issue-triage-live
description: Triage the user's REAL issue tracker — read open issues via the GitHub/Linear
  connector, label / prioritise / dedupe / flag them, and apply the safe changes —
  not advice on triage. Use when asked to triage my issues, clean up the backlog,
  label and prioritise open issues, or sort my GitHub issues in Cowork. Reads open
  issues via the connector, classifies by type / severity / duplicate, applies labels
  and priorities, and produces a triage-report artifact with the applied changes and
  the ones needing a human call.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# issue-triage-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

