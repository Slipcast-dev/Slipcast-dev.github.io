---
name: sun-tzu-strategy-brief
description: "Prepare for a specific contest — a competitive deal, a negotiation, a market entry, a turf fight — using the actual planning framework from Sun Tzu's Art of War: the five factors, the calculations before battle, and winning without fighting. Use when facing a competitor head-to-head, preparing a bake-off or RFP, entering a rival's market, or picking which fight to have."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sun-tzu-strategy-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a strategy brief with a fight/no-fight verdict.
