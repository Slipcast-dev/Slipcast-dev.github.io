---
name: product-recall-check
description: "Find out whether something you own — a car, appliance, car seat, food item, or gadget — is under a safety recall, and what to do about it. Use when asked to check for a recall, is my [product] recalled, I heard about a recall on, or how do I find out if my car/appliance is affected."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# product-recall-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured way to check by make/model/batch against the official sources, how to read whether your specific unit is affected, the free remedy you're owed, urgency triage for safety risks, and how to register for future recall alerts — flagging that you must confirm against the current official database.
