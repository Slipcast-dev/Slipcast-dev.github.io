---
name: cn-prd-review
description: "Prepare for and run a product requirements review (需求评审 / PRD 评审会) the way Chinese internet teams do it: a pre-read the engineers, testers and designers can challenge, the questions each role will ask, the meeting run sheet and a written conclusion (通过 / 有条件通过 / 不通过). Use when asked 帮我准备需求评审, PRD 评审会怎么开, 评审前检查一下我的 PRD, 研发会问什么问题, or prepare my requirements review in Chinese."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-prd-review

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a readiness check of the PRD, a role-by-role question bank with answer points, a 60-minute run sheet, and the review minutes template with the conclusion and follow-ups.
