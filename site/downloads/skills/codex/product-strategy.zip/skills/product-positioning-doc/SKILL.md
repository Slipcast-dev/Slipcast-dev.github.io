---
name: product-positioning-doc
description: "Write a product positioning document and messaging framework. Use when asked to define product positioning, write a positioning statement, build a messaging framework, or create a messaging hierarchy."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# product-positioning-doc

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete positioning doc with category definition, target customer, differentiation, proof points, messaging pillars, and persona-specific messaging.
