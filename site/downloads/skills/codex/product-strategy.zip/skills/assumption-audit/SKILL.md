---
name: assumption-audit
description: "Surface the hidden assumptions a plan or belief rests on, then test what happens when each one is wrong. Use when asked what am I assuming here, check my assumptions, what if I'm wrong about, or stress-test my thinking."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# assumption-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the unstated assumptions your conclusion depends on (ranked by how load-bearing they are), a flip of each to see which one breaking would change everything, and the cheapest way to check the riskiest ones — because the assumption you didn't know you were making is what sinks plans.
