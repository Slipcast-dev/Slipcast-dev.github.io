---
name: client-red-flags
description: "Spot a bad client before you sign — the warning signs of the projects that turn into unpaid, scope-creeping nightmares, and how to screen, price, or decline them. Use when asked is this client a red flag, should I take this client, screening a difficult client, or how to avoid bad clients."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# client-red-flags

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a read on the warning signs present (haggling, vagueness, disrespect, urgency, unrealistic expectations), what each predicts, screening questions to ask before committing, protective terms if you proceed anyway, and how to decline gracefully — so you avoid the clients who cost more than they pay.
