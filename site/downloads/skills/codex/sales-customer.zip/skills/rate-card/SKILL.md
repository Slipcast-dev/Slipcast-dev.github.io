---
name: rate-card
description: "Build a consulting/freelance rate card and pricing structure — and the floor rate to not go broke. Use when asked to set freelance/consulting rates, build a rate card, decide what to charge, package services, or move off hourly billing."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rate-card

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a rate card — your minimum viable rate (from real targets), tiered packages, pricing models (hourly/day/project/retainer/value), and how to present and defend it.
