---
name: pricing-calculator
description: "Model pricing scenarios — tiers, margins, break-even, and the revenue impact of a price change. Use when asked to calculate pricing, model a price increase, find break-even volume, set tier prices to a margin target, or estimate the revenue effect of a pricing change."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pricing-calculator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a computed pricing model (per-tier margin, break-even units, price-change revenue impact with an elasticity assumption) and a recommendation.
