---
name: investor-cold-email
description: "Write a cold or warm-intro email to an investor that actually gets a reply — short, specific, traction-forward, with a clear ask. Use when asked to email an investor, write a fundraising outreach, request a warm intro, or craft a forwardable blurb."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# investor-cold-email

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tight cold email, a forwardable intro blurb a mutual contact can paste, and the follow-up — all skimmable on a phone.
