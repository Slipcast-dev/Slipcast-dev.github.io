---
name: client-onboarding-kit
description: "Build a smooth client-onboarding process that starts projects on the right foot — clear expectations, the info you need, and a professional first impression that prevents problems later. Use when asked to onboard a new client, create an onboarding process, kick off a client project, or client welcome packet."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# client-onboarding-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a welcome and kickoff flow, the intake you need to start, expectation-setting on scope/comms/timeline/payment, a kickoff-meeting agenda, and the templates to reuse — so onboarding is consistent, not improvised, and prevents the scope and communication problems that sink projects.
