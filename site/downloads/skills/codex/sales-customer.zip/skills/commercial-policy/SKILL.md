---
name: commercial-policy
description: Use when designing or revising a company's commercial policy — the rules
  of engagement governing discounts off list price, approver thresholds, exception
  flows, and the deal framework that Deal Desk and AEs operate under. Covers discount
  matrix design (ARR band x term length x payment terms x strategic value), commercial
  policy design, exception policy, discount governance, approval thresholds, deal
  framework structure, and policy linting (contradictions, gaps, cliff edges, gaming
  surfaces). For Head of Commercial, Head of Deal Desk, VP Sales, or RevOps at the
  policy-design moment — NOT per-deal application (that is deal-desk) and NOT pricing
  model selection (that is pricing-strategist).
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# commercial-policy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

