---
name: client-offboarding
description: "Wrap up a client project the right way — a clean handoff, a strong final impression, and the moves that turn a finished project into referrals and repeat work. Use when asked to wrap up a client project, offboard a client, end a client relationship well, or project handoff."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# client-offboarding

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a closeout checklist (deliverables, access, final invoice, documentation), a handoff/wrap-up message, the referral/testimonial/repeat-work asks to make at the peak moment, a graceful process for ending an ongoing relationship, and how to leave the door open — so the ending builds your business instead of just stopping.
