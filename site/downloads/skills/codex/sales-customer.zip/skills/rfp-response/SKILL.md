---
name: rfp-response
description: "Write a compliant, competitive response to an RFP/RFQ/ITT (government or enterprise procurement). Use when responding to a request for proposal, bidding on a tender, or answering a procurement questionnaire."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rfp-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a compliance-matrix-driven response that answers every requirement, wins on evaluation criteria, and reads as low-risk to the buyer — structured to the scoring, not the seller's ego.
