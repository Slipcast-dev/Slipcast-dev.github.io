---
name: customer-success-manager
description: Monitors customer health, predicts churn risk, and identifies expansion
  opportunities using weighted scoring models for SaaS customer success. Use when
  analyzing customer accounts, reviewing retention metrics, scoring at-risk customers,
  or when the user mentions churn, customer health scores, upsell opportunities, expansion
  revenue, retention analysis, or customer analytics. Runs three Python CLI tools
  to produce deterministic health scores, churn risk tiers, and prioritized expansion
  recommendations across Enterprise, Mid-Market, and SMB segments.
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# customer-success-manager

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

