---
name: client-discovery
description: "Run a consulting client discovery session — uncover the real problem, scope, and decision process. Use when asked to prepare for a client discovery call, qualify a consulting lead, scope an engagement, or run a kickoff."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# client-discovery

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a discovery plan — the questions that surface the real problem (not the stated one), budget/authority/timeline qualifiers, success criteria, red flags, and a follow-up that leads to a proposal.
