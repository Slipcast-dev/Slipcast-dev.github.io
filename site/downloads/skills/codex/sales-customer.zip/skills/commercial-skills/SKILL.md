---
name: commercial-skills
description: Use when reviewing, approving, or designing commercial motion — pricing
  models, deal review, discount approval, partnership economics, channel mix, commercial
  policy, RFP/RFI response, bookings forecast. Triggers on "review this deal", "should
  we discount", "pricing model", "partner economics", "RFP response", "bookings forecast",
  "channel mix". Forks context to route to one of seven Commercial sub-skills (pricing-strategist,
  deal-desk, partnerships-architect, channel-economics, commercial-policy, rfp-responder,
  commercial-forecaster) and returns a digest. Distinct from business-growth (sales
  execution) and c-level-advisor/cro-advisor (strategic CRO judgment).
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# commercial-skills

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

