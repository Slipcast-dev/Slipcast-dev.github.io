---
name: resale-flip-kit
description: "Sell secondhand like someone who's done it 500 times — honest condition grading, comps-based pricing with a floor and an anchor, listing titles built from real search terms, photo checklists, and offer/haggle scripts for Vinted, Depop, eBay, and Facebook Marketplace. Use when someone says 'help me sell this', 'price my old jacket', 'write my Depop listing', or 'lowballers keep messaging me'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# resale-flip-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces ready-to-post listings plus a pricing sheet and reply scripts.
