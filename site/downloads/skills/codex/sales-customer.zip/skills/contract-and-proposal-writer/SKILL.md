---
name: contract-and-proposal-writer
description: 'Generate professional, jurisdiction-aware business documents: freelance
  contracts, project proposals, SOWs, NDAs, and MSAs. Structured Markdown output with
  docx conversion instructions. Covers US (Delaware), EU (GDPR), UK, and DACH (German
  law) jurisdictions. Not a substitute for legal counsel — use as strong starting
  points. Use when drafting a freelance contract, preparing a client proposal, writing
  an SOW for a new engagement, or producing an NDA before sharing sensitive material.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# contract-and-proposal-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

