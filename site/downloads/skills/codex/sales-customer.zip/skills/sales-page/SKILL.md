---
name: sales-page
description: "Write a long-form sales page that takes a cold reader to a purchase. Use when asked to write a sales page, a long-form sales letter, a course/offer page, or direct-response copy that has to close on the page."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sales-page

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a full long-form structure — hook, problem agitation, the offer & mechanism, proof, offer stack & price framing, risk reversal, urgency, and a repeated CTA — written to sell, ethically.
