---
name: consulting-proposal
description: "Write a consulting proposal that wins the engagement — outcomes over hours. Use when asked to write a consulting proposal, a project proposal, a pitch for a client engagement, or to respond to an RFP. Ready to export as a designed PDF."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# consulting-proposal

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a proposal — the client's problem in their words, your approach & deliverables, outcomes/value, timeline & phases, investment with options, and why-you — framed around results, not a task list.
