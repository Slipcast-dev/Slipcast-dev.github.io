---
name: renew-or-churn-call
description: "Score an account's renewal likelihood on a five-level scale with probabilities, and name the next move for the account owner. Use when asked will this account renew, what's the churn risk on this account, should we run a save play, or when a renewal is 30–120 days out and the owner needs a calibrated read rather than a gut feel."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# renew-or-churn-call

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the account state in a fixed schema, the five-level renewal score with a probability per level and confidence, the mapped next move, and the single signal that would change the call.
