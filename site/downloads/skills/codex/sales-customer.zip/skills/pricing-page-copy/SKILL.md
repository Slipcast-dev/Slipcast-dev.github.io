---
name: pricing-page-copy
description: "Write pricing page copy that helps buyers self-select the right plan and convert. Use when asked to write or improve a pricing page, name and describe pricing tiers, write plan feature lists, pricing CTAs, or a pricing FAQ."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pricing-page-copy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces complete pricing page copy — a header, tier cards with names, prices, audiences, feature lists, CTAs, an add-on/enterprise section, and an objection-handling FAQ.
