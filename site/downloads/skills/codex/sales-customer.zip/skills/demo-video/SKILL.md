---
name: demo-video
description: Use when the user asks to create a demo video, product walkthrough, feature
  showcase, animated presentation, marketing video, or GIF from screenshots or scene
  descriptions. Orchestrates playwright, ffmpeg, and edge-tts MCPs to produce polished
  video content.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# demo-video

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

