---
name: demo-clip-storyboard
description: "Use when asked to plan a short demo video for a repo, script a 20-second clip, storyboard a GIF for a README or launch post, or make a project look good on X or LinkedIn. For a live product demo to an audience, use demo-script; for cutting clips from a long recording, use clip-factory."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# demo-clip-storyboard

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the script for the 20-second video that sells a repo: a shot list with a timestamp per shot, on-screen text, exactly what to record, the hook in the first two seconds, and post copy for X and LinkedIn.
