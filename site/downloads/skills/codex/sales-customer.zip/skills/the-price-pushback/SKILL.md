---
name: the-price-pushback
description: "Simulate the client who grinds on your price — the budget theater, the competitor quote, the scope squeeze — against your actual offer, with a debrief on where you caved and what holding would have sounded like. Use when asked simulate a client negotiating my rate, practice price pushback, they said I'm too expensive, or stress-test my pricing conversation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-price-pushback

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the negotiation transcript with the client's private playbook notes, the deal outcome, and a debrief on every concession with its stronger alternative.
