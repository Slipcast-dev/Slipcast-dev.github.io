---
name: cn-trade-quotation
description: "Use when asked 做一份外贸报价单, FOB 和 CIF 怎么报价, 出口报价核算, 报价怎么算利润, 退税怎么算进报价, quotation sheet for an export order, or price an export quotation from China."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# cn-trade-quotation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a cost build-up from the factory price through export tax rebate, domestic logistics, port charges, freight and insurance to each Incoterms 2020 term, a quotation sheet in English with a Chinese summary, quantity tiers, validity and exchange-rate assumptions, payment terms and the risk each term puts on the seller, with rates marked to confirm.
