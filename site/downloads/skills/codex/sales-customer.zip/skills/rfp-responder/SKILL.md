---
name: rfp-responder
description: Use when an RFP, RFI, RFQ, security questionnaire, vendor questionnaire,
  or proposal request arrives and the team needs a structured response — parsing multi-section
  buyer-dictated requirements (MANDATORY vs WEIGHTED vs NICE-TO-HAVE), building a
  Shipley-method proof-point matrix mapping each requirement to a verifiable proof
  point, articulating 3-5 win-themes that ladder up across requirements, and producing
  a Shipley-derived winrate estimate that informs a bid / no-bid / partner-bid recommendation.
  For Bid Managers, Proposal Leads, Directors of Sales, and Sales Engineers at the
  response-strategy moment. Surfaces GAP requirements explicitly — never invents claims.
  NOT free-form proposal narrative authoring, NOT contract redline, NOT marketing
  collateral.
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# rfp-responder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

