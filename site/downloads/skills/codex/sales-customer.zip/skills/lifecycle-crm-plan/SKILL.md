---
name: lifecycle-crm-plan
description: "Design lifecycle marketing / CRM journeys across the customer lifecycle. Use when asked to plan onboarding emails, lifecycle/CRM campaigns, drip sequences, re-engagement or winback flows, or a messaging calendar."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# lifecycle-crm-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a lifecycle plan — stage map, the trigger/message/goal for each journey, channel & timing, segmentation, suppression rules, and success metrics.
