---
name: crm-hygiene-sweep
description: "Have a proactive agent sweep a CRM (HubSpot, Salesforce, Pipedrive) on a schedule for the things that quietly rot a pipeline: deals with no next step, close dates in the past, deals untouched for weeks, contacts with no owner, and duplicate records, reported per owner with suggested fixes a human approves. Use when asked to clean up my CRM, find stale deals, have Duet check HubSpot every week, which deals have no next step, or pipeline hygiene check."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# crm-hygiene-sweep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the sweep rules, the per-owner list of issues with the evidence, the suggested fix per line, and the weekly summary numbers; it never edits, merges or deletes records itself.
