---
name: rfp-writer
description: "Write a clear Request for Proposal that gets comparable, high-quality vendor bids. Use when asked to write an RFP, a request for proposal/quote/tender, or to solicit and compare vendor proposals."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# rfp-writer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete RFP — background, scope of work, requirements, evaluation criteria with weights, submission instructions, and timeline — structured so responses are easy to compare apples-to-apples.
