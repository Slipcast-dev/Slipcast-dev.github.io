---
name: customer-advisory-board
description: "Plan and run a customer advisory board (CAB). Use when asked to design a customer advisory board, plan a CAB meeting agenda, choose CAB members, or write CAB invitations and follow-ups."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# customer-advisory-board

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a CAB program plan — objectives, member selection criteria, a meeting agenda, discussion guides, roles, logistics, and a follow-up and value-capture plan.
