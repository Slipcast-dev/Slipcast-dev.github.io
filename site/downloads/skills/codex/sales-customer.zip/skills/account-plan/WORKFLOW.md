# Account Plan Skill

Produces a structured account plan — the document that separates account managers who grow accounts from those who just service them.

## Required Inputs
- **Account name**
- **Current ARR / revenue**
- **Contract renewal date**
- **Key contacts** (names, roles, relationship strength)
- **Products/services currently in use**
- **Known opportunities or expansion areas**
- **Known risks**
- **Planning horizon** (6 / 12 / 24 months)

## Output Structure

---

# Account Plan: [Account Name]
**Account Manager:** [Name] | **Period:** [Date range]

---

### Account Snapshot

| Metric | Current | Target (EOY) |
|---|---|---|
| ARR / Revenue | £[amount] | £[target] |
| NPS / Health score | [Score] | [Target] |
| Products in use | [List] | [Expansion targets] |
| Renewal date | [Date] | — |
| Risk level | Low / Medium / High | — |

---

### Relationship Map

| Name | Title | Influence | Relationship | Notes |
|---|---|---|---|---|
| [Name] | [Role] | Decision maker / Influencer / User | Strong / Neutral / Weak | [Insight] |

**Relationship gaps:** [Who we do not have access to that we should]
**Executive sponsor:** [Do we have one? If not — who could become one?]

---

### Why They Stay (Retention Anchors)
[2-3 specific reasons this account renews. If the list is short, that is the risk signal.]

---

### Growth Opportunities

| Opportunity | Product | Est. Value | Timeline | Next Action |
|---|---|---|---|---|
| [Opportunity] | [Product] | £[value] | [Q/Year] | [Specific action] |

**Whitespace:** What products do we have that this account does not use, and why?

---

### Risks and Mitigation

| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| [Risk] | H/M/L | H/M/L | [Action] | [Name] |

---

### 90-Day Action Plan

| Action | Why | Owner | Due |
|---|---|---|---|
| [Specific action] | [Why it matters] | [Name] | [Date] |

**Next QBR / EBR:** [Date — if no EBR cadence, flag as a risk]

---

### Success Criteria
At end of [period]:
- Renewed at or above current ARR
- [Expansion opportunity] progressed to [stage]
- Health score moved from [current] to [target]

## Anti-Patterns

- [ ] Do not list only executive contacts in the relationship map — champions and day-to-day users are often more influential on renewal decisions
- [ ] Do not set growth opportunity estimates without a basis — even rough ARR values prevent the plan from being treated seriously
- [ ] Do not treat "no known risks" as acceptable — if no risks are identified, the plan hasn't been scrutinised honestly
- [ ] Do not write 90-day actions as vague aspirations ("strengthen the relationship") — each action must specify a call, meeting, or deliverable with a named owner

## Quality Checks

- [ ] Relationship map identifies decision-makers, influencers, and any relationship gaps
- [ ] Risks all have mitigation actions and named owners
- [ ] Growth opportunities include estimated value (even roughly)
- [ ] 90-day actions are specific (not "have a call" — what call, with whom, to achieve what)
- [ ] Success criteria are measurable at the end of the planning period

## Example Trigger Phrases

- "Create an account plan for our biggest customer."
- "Build a key account strategy for Acme."
- "Run a strategic account review before renewal."
- "Plan my territory for next year."
