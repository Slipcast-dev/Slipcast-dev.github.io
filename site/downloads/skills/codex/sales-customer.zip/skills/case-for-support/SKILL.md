---
name: case-for-support
description: "Write a fundraising case for support that makes donors want to give. Use when asked to write a case for support, a fundraising case statement, a major-gift or campaign case, or the core argument for a donation appeal."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# case-for-support

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a persuasive case — the need, your solution and why you, the impact a gift makes, specific funding opportunities with amounts, and a clear ask — donor-centred, not org-centred.
