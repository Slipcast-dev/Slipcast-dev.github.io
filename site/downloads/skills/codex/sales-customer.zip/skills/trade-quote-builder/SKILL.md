---
name: trade-quote-builder
description: "Build a trade quote that wins the job and protects the margin — materials and labor itemized, assumptions and exclusions stated, variations priced by rule, and the professional one-page layout customers trust. Use when a tradesperson says 'help me quote this job', 'I keep losing money on jobs', 'customer wants a price for X', or 'how do I quote a day rate vs fixed'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# trade-quote-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a ready-to-send quote plus the internal costing sheet behind it.
