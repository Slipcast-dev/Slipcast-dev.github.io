---
name: market-stall-pricing
description: "Price goods for a market stall, street stall or small shop so every sale covers its costs, and hold your price when customers bargain. Use when someone says 'how much should I sell this for', 'customers always bargain me down', 'am I making any money at the market', or 'what price for my vegetables, crafts or snacks'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# market-stall-pricing

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a cost-per-item calculation, a floor price, a starting price with room to bargain, bargaining lines that keep the margin, and a quick end-of-day check.
