---
name: customer-incident-update
description: "Write the customer-facing incident update during an outage — status-page post or email — that's honest about impact without over-promising. Use when asked to write a status page update, draft customer comms for an outage, post an incident notice, or tell customers about downtime. Distinct from incident-postmortem (the internal retro)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# customer-incident-update

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the update in the right tense for the incident stage (investigating / identified / monitoring / resolved), with impact scope, any workaround, and a concrete next-update time.
