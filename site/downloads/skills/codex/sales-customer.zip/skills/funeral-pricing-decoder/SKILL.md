---
name: funeral-pricing-decoder
description: "Decode a funeral home price list while grieving — the package maths versus the itemised list, the non-declinable basic fee, the upsells that arrive as care, and the direct-cremation benchmark that anchors every other number. Use when asked to compare funeral quotes, is this funeral price fair, what can we decline, or help me read this price list. Consumer information, not legal advice; disclosure rules are strongest in the US (FTC Funeral Rule)."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# funeral-pricing-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a line-by-line decode, the decline-safely list, package-versus-itemised maths, questions for the director, and a comparison across homes.
