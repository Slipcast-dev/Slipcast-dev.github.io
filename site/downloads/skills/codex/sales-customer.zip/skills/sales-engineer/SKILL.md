---
name: sales-engineer
description: Analyzes RFP/RFI responses for coverage gaps, builds competitive feature
  comparison matrices, and plans proof-of-concept (POC) engagements for pre-sales
  engineering. Use when responding to RFPs, bids, or proposal requests; comparing
  product features against competitors; planning or scoring a customer POC or sales
  demo; preparing a technical proposal; or performing win/loss competitor analysis.
  Handles tasks described as 'RFP response', 'bid response', 'proposal response',
  'competitor comparison', 'feature matrix', 'POC planning', 'sales demo prep', or
  'pre-sales engineering'.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# sales-engineer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

