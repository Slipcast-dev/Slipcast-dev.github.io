---
name: chief-customer-officer-advisor
description: 'Chief Customer Officer advisory for startups: retention decomposition
  (gross retention vs NRR honesty, churn root-cause taxonomy), customer segmentation
  strategy (differential investment across tiers + ICP fit scoring), CS team coverage
  model (pooled vs named CSM thresholds + ratio math), and CS team org evolution (CS
  vs Support vs AM distinctions). Use when designing retention strategy, segmenting
  customers for differential investment, sizing CS team, or sequencing CS hires. Strategic
  only — does not duplicate engineering/business-growth tactical skills.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Сохрани факты, аудиторию и нужный тон. Сверь итог с требованиями к формату.
<!-- slipcast-model-profile:end -->


# chief-customer-officer-advisor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

