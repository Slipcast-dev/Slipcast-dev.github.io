---
name: pricing-your-services
description: "Design a freelance/consulting pricing structure — hourly vs day-rate vs project vs retainer chosen per engagement type, anchored packages, and the rules for saying the number out loud without flinching. Use when asked how should I price my freelance services, hourly or fixed price, build my pricing packages, or a client asked my rate what do I say."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# pricing-your-services

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the pricing-model decision per engagement type, a three-tier package structure, the rate-conversation script, and the discount policy with its floor.
