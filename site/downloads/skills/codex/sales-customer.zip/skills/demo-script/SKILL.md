---
name: demo-script
description: "Script a product demo that lands — the audience's-workflow storyline (their day, not your feature list), the golden path rehearsed with fallbacks, the wow moment placed early, and the demo-death contingencies (the backup video, the reset state, the narration bridge). Use when asked script our product demo, demo this to a customer/exec, our demos meander through features, or the demo broke live last time."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# demo-script

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the demo storyline, the click-path script with fallbacks, the wow placement, and the contingency kit.
