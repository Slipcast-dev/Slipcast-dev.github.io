---
name: late-invoice-chaser
description: "Chase an overdue invoice and actually get paid — a firm-but-friendly escalation ladder that protects the client relationship until it's clear the relationship is the problem. Use when asked to chase an unpaid invoice, my client hasn't paid, write a payment reminder, or how do I get a late-paying client to pay."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# late-invoice-chaser

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a staged sequence of messages (gentle nudge → firm reminder → final notice → next steps) timed to the overdue days, with late-fee and work-pause options and a note on what to keep for the record.
