---
name: scope-creep-response
description: "Handle scope creep on client work without torching the relationship — classify the ask against the agreement, respond with the goodwill/change-order/renegotiate move that fits, and install the prevention language for next time. Use when asked my client keeps adding requests, is this scope creep, how do I say that's out of scope nicely, or write a change order email."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# scope-creep-response

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the classification of the ask, the graduated response with ready-to-send wording, and the contract language that prevents the rerun.
