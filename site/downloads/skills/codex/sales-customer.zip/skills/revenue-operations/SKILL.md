---
name: revenue-operations
description: Analyzes sales pipeline health, revenue forecasting accuracy, and go-to-market
  efficiency metrics for SaaS revenue optimization. Use when analyzing sales pipeline
  coverage, forecasting revenue, evaluating go-to-market performance, reviewing sales
  metrics, assessing pipeline analysis, tracking forecast accuracy with MAPE, calculating
  GTM efficiency, or measuring sales efficiency and unit economics for SaaS teams.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# revenue-operations

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

