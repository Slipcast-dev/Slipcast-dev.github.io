---
name: customer-outage-notice
description: "Write clear customer-facing outage and service-disruption notifications. Use when asked to write an outage notice, a status-page update, a service-disruption email, a maintenance notice, or an incident update sequence."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# customer-outage-notice

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces status-page updates for each phase (investigating → identified → monitoring → resolved), a customer email, and a resolved/post-incident summary, in plain, reassuring language.
