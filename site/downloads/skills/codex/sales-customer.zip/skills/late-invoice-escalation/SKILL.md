---
name: late-invoice-escalation
description: "Collect overdue invoices with a graduated escalation ladder — friendly nudge to firm notice to work-stop to final demand, each with send-ready wording and timing, plus the prevention terms that stop the next one. Use when asked my client hasn't paid me, write a payment reminder email, invoice is 60 days overdue what do I do, or client is ghosting my invoices."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# late-invoice-escalation

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the situation read, the escalation ladder with dates and verbatim messages, the work-stop decision point, and the payment terms that prevent reruns.
