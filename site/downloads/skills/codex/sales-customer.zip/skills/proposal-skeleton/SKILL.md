---
name: proposal-skeleton
description: "Structure an internal proposal that gets a decision — the problem-cost-options-recommendation-ask spine, the objection pre-handling that shortens the meeting, and the reversibility framing that makes yes easier. Use when asked write a proposal for the new tool or process or hire, how do I pitch this internally, structure my case for the change, or my proposals keep dying in review."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# proposal-skeleton

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the proposal skeleton filled from the actual case, the objections table, the decision-sized ask, and the one-page discipline.
