---
name: creator-deal-decoder
description: "Decode a brand deal or UGC contract before signing — usage rights, exclusivity windows, whitelisting, payment terms, and kill clauses ranked 🔴🟡🟢 by what they can cost a creator, plus the counter-ask email. Use when a creator says 'is this brand deal fair', 'what does perpetual usage mean', 'they sent me a contract', or 'should I sign this collab agreement'. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# creator-deal-decoder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a clause-by-clause decode, a money-math check on the rate, and a ready-to-send negotiation email.
