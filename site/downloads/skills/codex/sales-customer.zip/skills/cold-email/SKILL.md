---
name: cold-email
description: "Write a cold sales/B2B outreach email that earns a reply. Use when asked to write a cold email, a sales outreach email, a prospecting email, or a cold email sequence to a business prospect."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cold-email

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a short, personalised email — subject, a relevant opener, one clear value-led ask, and a low-friction CTA — plus 2 follow-ups, written to be replied to, not deleted.
