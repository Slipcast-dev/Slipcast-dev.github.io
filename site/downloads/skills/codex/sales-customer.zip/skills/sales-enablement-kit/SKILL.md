---
name: sales-enablement-kit
description: "Build a sales enablement kit so reps can sell a product, feature, or launch confidently. Use when asked to create sales enablement materials, a rep-ready one-pager, talk tracks, objection handling, or a launch enablement package."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sales-enablement-kit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete kit — positioning summary, discovery questions, talk track, demo flow, objection handling, competitive counters, and a call-to-action for reps.
