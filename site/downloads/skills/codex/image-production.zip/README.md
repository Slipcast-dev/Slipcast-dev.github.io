# Обработка изображений / Image editing and production · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
## Состав / Contents

Ретушь, обработка серии, кадрирование и контроль экспорта.

Retouching, batch processing, crops and export checks.

Рекомендуемый порядок / Suggested order:

1. [image-edit-batch-export](skills/image-edit-batch-export/SKILL.md)
2. [image-rendered-output-qa](skills/image-rendered-output-qa/SKILL.md)
