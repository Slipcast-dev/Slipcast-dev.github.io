---
name: fleet-maintenance-programme
description: "Design a preventive maintenance programme that keeps vehicles legal and out of the workshop at the wrong moment — intervals set by duty cycle, the inspection items that actually cause roadside failures, and the defect-reporting loop that closes. Use when asked to build a fleet maintenance schedule, set PM intervals, reduce breakdowns or roadside violations, or design a vehicle inspection programme."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# fleet-maintenance-programme

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the interval schedule by duty cycle, the inspection checklists by level, the defect-reporting and rectification loop, the parts and downtime planning, and the compliance record structure.
