---
name: cn-fupan
description: "Run a 复盘 (fupan), the structured project review widely used in Chinese companies: review the goal, assess the result, analyse why, and draw rules for next time, with a blame-free tone and owned actions. Use when asked 帮我做复盘, 项目复盘, 活动复盘, 复盘会怎么开, or a fupan or retrospective in Chinese."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# cn-fupan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the 复盘 document in Chinese with goal versus result, root causes split into controllable and uncontrollable, lessons stated as reusable rules, and an action list with owners and dates, plus a meeting agenda.
