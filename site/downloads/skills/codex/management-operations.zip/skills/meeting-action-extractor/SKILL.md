---
name: meeting-action-extractor
description: "Pull the action items and decisions out of meeting notes or a transcript — each with an owner, a due date, and enough context to become a ticket — plus the open questions. Use when asked to extract action items, turn these notes into tasks, who owns what from this meeting, or pull the to-dos from this transcript."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# meeting-action-extractor

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the ticket-ready action list (owner + due + context), the decisions made, the open questions with no owner yet, and a flag for any 'someone should…' that never got assigned.
