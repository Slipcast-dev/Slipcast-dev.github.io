---
name: last-two-weeks-handoff
description: "Turn your notice period into a handoff that makes you missed for the right reasons — the transition doc nobody has to call you about, the knowledge-transfer sessions, and the graceful goodbye mechanics. Use when asked I just resigned how do I hand off my work, write my transition document, plan my last two weeks, or what do I do before I leave my job."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# last-two-weeks-handoff

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the handoff inventory, the transition doc template filled with your reality, the KT session plan, and the last-day checklist.
