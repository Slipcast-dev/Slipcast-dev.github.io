---
name: committee-handover-pack
description: "Capture everything an outgoing club secretary, chair, or organizer carries in their head before they disappear — accounts and logins with owners, the annual rhythm calendar, key relationships and their quirks, the unwritten rules, and the first-90-days guide for the successor. Use when a committee member is stepping down, when someone says 'it all lives in Linda's head', or right after elections."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# committee-handover-pack

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a complete handover pack plus the one-hour handover meeting agenda.
