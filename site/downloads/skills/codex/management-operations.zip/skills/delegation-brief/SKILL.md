---
name: delegation-brief
description: "Delegate so the work comes back right the first time — the brief that transfers outcome, context, and constraints (not just the task), the autonomy level stated explicitly, and the check-in design that catches drift without hovering. Use when asked hand this off properly, my delegations come back wrong, write a brief for this task I'm giving away, or how much detail do I give."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# delegation-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the delegation brief with the outcome and guardrails, the autonomy level, the check-in points, and the questions-welcome contract.
