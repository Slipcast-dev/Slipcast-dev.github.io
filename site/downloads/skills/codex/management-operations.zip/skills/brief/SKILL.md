---
name: brief
description: /c-level-agents:brief [topic] — Generate a one-page strategy brief from
  an office-hours intake. First step in the strategic sprint pipeline. Use when a
  strategic question needs to be framed before boardroom deliberation — e.g. locking
  options, assumptions, and success criteria for a pricing change or a market-entry
  decision.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
