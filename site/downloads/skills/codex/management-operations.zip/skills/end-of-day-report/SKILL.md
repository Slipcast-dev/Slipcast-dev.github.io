---
name: end-of-day-report
description: "Produce an end-of-day report an unattended agent can send honestly: what shipped (verified), what is drafted or waiting, what is blocked and on whom, and tomorrow's first action. Use when asked for an end-of-day report, what did my agent do today, wrap up my day, or a daily close-out summary."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# end-of-day-report

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a six-line close-out in the shared status vocabulary, every claim cited, with unverified items marked unverified rather than assumed done.
