---
name: post-mortem
description: /c-level-agents:post-mortem [decision] — Honest retrospective on an executed
  decision, scored against original assumptions and dissent. Closes the strategic
  sprint loop. Use when a decision hits its 90-day review checkpoint or its kill criteria
  trigger — e.g. scoring last quarter's pricing change against its pre-committed success
  metrics.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# post-mortem

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
