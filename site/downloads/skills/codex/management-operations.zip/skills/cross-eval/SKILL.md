---
name: cross-eval
description: /c-level-agents:cross-eval [memo] — Multi-model consensus on a board
  memo or strategy brief. Claude + Codex + Gemini cross-review with graceful degradation.
  Use when a high-stakes memo needs an independent sanity check before the boardroom
  — e.g. a bet-the-company pivot or fundraise terms.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# cross-eval

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
