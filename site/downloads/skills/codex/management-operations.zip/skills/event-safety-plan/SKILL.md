---
name: event-safety-plan
description: "Produce the event safety documentation that satisfies a venue or licensing authority and actually works on the day — the risk assessment, crowd and capacity plan, emergency procedures, and the roles that must be filled. Use when asked to write an event risk assessment, safety plan, event management plan, or emergency procedure, or when a venue or authority has requested safety documentation. Not a substitute for competent safety advice, which many events legally require."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# event-safety-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the risk assessment, the crowd and capacity position, emergency and evacuation procedures, the medical and welfare plan, and the roles-and-competence schedule.
