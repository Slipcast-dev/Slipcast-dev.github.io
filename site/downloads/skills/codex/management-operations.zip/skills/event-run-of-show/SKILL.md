---
name: event-run-of-show
description: "Build the minute-by-minute run of show that lets an event run without the planner being asked anything — every cue, who owns it, what happens if it slips, and the version each supplier actually needs. Use when asked to write a run of show, event schedule, show flow, or production schedule, or to prepare the day-of timeline for a conference, wedding, launch, or gala."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# event-run-of-show

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the master timeline with owners and cues, the load-in and load-out schedule, the supplier-specific extracts, the contingency triggers, and the on-the-day contact sheet.
