---
name: standing-meeting-audit
description: "Audit the recurring meetings a team has accreted — each standing slot tested against its original purpose, current attendance reality, and outcomes, with keep/shrink/merge/kill verdicts and the two-week cancellation experiment that settles arguments. Use when asked audit our recurring meetings, our calendar is all standing syncs, which meetings should die, or reset the team's meeting load."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# standing-meeting-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the inventory with per-meeting verdicts, the experiment protocol, the merge map, and the re-accretion guard.
