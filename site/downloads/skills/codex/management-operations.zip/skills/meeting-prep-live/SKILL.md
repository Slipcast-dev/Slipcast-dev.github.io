---
name: meeting-prep-live
description: Prepare the user for a REAL upcoming meeting by pulling the actual Calendar
  event, its attendees, the linked Drive docs, and the last email/Slack thread — then
  producing a brief. Use when asked to prep me for my next meeting, get me ready for
  the 2pm, or what do I need for the sync with X in Cowork. Reads the event via the
  Google Calendar connector, gathers the attached and related material via Drive/Gmail,
  and produces a one-page meeting-brief artifact with objective, context, open threads,
  and the questions to ask.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Отделяй решения от допущений и укажи зависимости, критерии выбора и следующий шаг.
<!-- slipcast-model-profile:end -->


# meeting-prep-live

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

