---
name: recurring-meeting-pruner
description: "Prune your own recurring-meeting load — the personal calendar audit (your role in each, honestly), the four exit moves (leave, delegate, downgrade to notes, halve), and the graceful exit scripts that don't burn standing. Use when asked get me out of some of these meetings, my calendar is 80% recurring, which meetings can I stop attending, or leave a meeting politely."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# recurring-meeting-pruner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the personal audit with role verdicts, the exit move per meeting, the scripts, and the calendar-shape after.
