---
name: sop-meeting-prep
description: "Prepare an S&OP cycle readout that surfaces the demand-supply gaps and forces the three decisions the meeting must make. Use when asked to prep an S&OP meeting, build the executive S&OP deck, summarize demand vs supply for the monthly cycle, or prepare a supply review readout."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# sop-meeting-prep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a gap table, scenario levers with costs, an inventory projection, a decisions-required list, and a pre-read package.
