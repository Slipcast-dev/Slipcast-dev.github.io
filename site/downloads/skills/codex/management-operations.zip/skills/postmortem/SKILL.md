---
name: postmortem
description: /em:postmortem — Honest analysis of what went wrong. Use after a failed
  launch, missed quarter, or bad hire to run a blameless 5-Whys retrospective with
  a change register — e.g. dissecting why the Q3 release slipped six weeks.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# postmortem

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

