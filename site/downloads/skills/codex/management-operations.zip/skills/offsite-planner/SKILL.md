---
name: offsite-planner
description: "Plan a team offsite that earns its cost — the purpose split (connection vs. decisions vs. planning, weighted on purpose), the agenda that alternates work and air, the logistics runbook, and the follow-through that makes Monday different from before. Use when asked plan our team offsite, design two days for the team, make this offsite not a waste, or what do we actually do at the offsite."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# offsite-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the purpose weighting, the day designs, the logistics checklist, and the commitments-capture that survives re-entry.
