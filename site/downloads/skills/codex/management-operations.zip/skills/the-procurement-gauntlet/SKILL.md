---
name: the-procurement-gauntlet
description: "Simulate enterprise procurement and security review of your product before your first big deal meets it for real — the questionnaire, the gaps, the deal-slowing findings. Use when asked to prep for enterprise procurement, simulate a security review, why do enterprise deals stall, or get ready for vendor assessment."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# the-procurement-gauntlet

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the reviewer's findings memo (security, legal, compliance, vendor-risk), the stall-risk ranking, and a debrief with the artifacts to prepare before the real gauntlet.
