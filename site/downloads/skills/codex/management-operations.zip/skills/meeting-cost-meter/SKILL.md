---
name: meeting-cost-meter
description: "Price meetings in money and focus — the attendee-hours × loaded-rate math, the recurring multiplier that turns a weekly 30-minutes into a real annual number, and the cost-vs-outcome read that decides what the price buys. Use when asked what does this meeting cost, price our meeting culture, is this recurring meeting worth it, or make the case for fewer attendees."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# meeting-cost-meter

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the cost computation with stated assumptions, the recurring annualization, the cost-per-outcome read, and the reduction levers ranked.
