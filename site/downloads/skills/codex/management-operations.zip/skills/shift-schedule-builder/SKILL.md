---
name: shift-schedule-builder
description: "Build a staff shift schedule that matches coverage to demand while hitting a labor-cost target. Use when asked to build a shift schedule, staff a rota, plan coverage for a restaurant/retail/shift-based team, or balance labor cost against service."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# shift-schedule-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a day-part coverage plan mapped to forecast demand, role-by-role assignments, the projected labor cost vs. target, and the fairness/compliance guardrails (rest between shifts, overtime, availability).
