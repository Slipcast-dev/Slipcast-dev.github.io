# SOP Writer Skill

Produces formal, audit-ready SOPs suitable for regulated industries, ISO certification, or operational scaling.

> **Not quite this?** Use `cn-sop-writer` when it is a one-station shop-floor work instruction (作业指导书) for a factory.

## Required Inputs
- **SOP title** (e.g. "SOP-001: New Client Onboarding")
- **Department / function**
- **Process description**
- **Regulatory or quality standard** (ISO 9001, GMP, CQC, FCA, etc.)
- **Roles involved**
- **Tools or equipment used**

## Output Structure

---

**[COMPANY NAME] — Standard Operating Procedure**

| Document ID | [SOP-XXX] |
|---|---|
| Title | [Title] |
| Department | [Department] |
| Version | 1.0 |
| Effective date | [Date] |
| Review date | [Date] |
| Status | Draft / Under review / Approved |

---

### 1. Purpose
[1-2 sentences. Why does this SOP exist?]

### 2. Scope
**Applies to:** [Roles, departments, locations]
**Does not apply to:** [Explicit exclusions]

### 3. Definitions
| Term | Definition |
|---|---|
| [Term] | [Plain English definition] |

### 4. Responsibilities
| Role | Responsibility |
|---|---|
| [Role] | [Specific responsibility] |

### 5. Required Materials / Tools / Access
- [Item]

### 6. Procedure

| Step | Action | Responsible | Record/Output |
|---|---|---|---|
| 6.1.1 | [Imperative action: "Open [system] and navigate to [location]"] | [Role] | [What to record] |

NOTE: Steps must be written in imperative form. Each step must have one action only.

### 7. Quality Checks

| Check point | What to verify | Pass criteria | If fail |
|---|---|---|---|
| [After step X] | [What to check] | [What good looks like] | [What to do] |

### 8. Non-Conformance
1. [Immediate action]
2. [Who to notify]
3. [How to document deviation]

### 9. References
[Related SOPs, policies, standards]

### 10. Document History

| Version | Date | Author | Changes |
|---|---|---|---|
| 1.0 | [Date] | [Name] | Initial release |

## Quality Checks
- [ ] All steps written in imperative form ("Open...", "Navigate...", "Confirm...")
- [ ] Each step has exactly one action
- [ ] Role specified for every step
- [ ] Quality checkpoints at critical stages
- [ ] Non-conformance process defines who to notify and how to document
- [ ] Document history table and review date are included

## Example Trigger Phrases
- "Write an SOP for [process]"
- "Create a standard operating procedure for [task]"
- "Write a work instruction for [process]"

## Anti-Patterns

- [ ] Do not write steps that contain more than one action — each step must be a single, auditable action in imperative form
- [ ] Do not omit a role from any step — every action must be assigned to a specific role or the SOP cannot be enforced
- [ ] Do not skip the non-conformance section — an SOP without a deviation process cannot meet audit or regulatory requirements
- [ ] Do not produce an SOP without a review date and version history — undated documents cannot be relied upon for compliance
- [ ] Do not use passive voice in procedure steps — write "Open the system" not "The system should be opened"
