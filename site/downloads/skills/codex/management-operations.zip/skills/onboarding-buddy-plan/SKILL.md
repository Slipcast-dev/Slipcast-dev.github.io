---
name: onboarding-buddy-plan
description: "Design the buddy system that makes new-hire onboarding human — the buddy's actual job (context and safety, not training), the 30-day touchpoint plan, the ask-me-anything contract, and the buddy selection that avoids the two classic miscasts. Use when asked set up an onboarding buddy program, I'm buddying the new hire what do I do, our onboarding is docs with no humans, or the new person is drowning quietly."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# onboarding-buddy-plan

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the buddy role definition, the touchpoint schedule, the first-week script, and the escalation line.
