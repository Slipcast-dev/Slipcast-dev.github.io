---
name: event-vendor-brief
description: "Brief an event supplier so they quote accurately and deliver what you pictured — the outcome, the constraints, the deliverables, and the questions you need answered in the quote. Use when asked to brief an event supplier, write a vendor brief for caterers, AV, or production, send an RFP for an event, or compare supplier quotes that are not comparable."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# event-vendor-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the outcome brief, the deliverables and constraints, the quote-response template that makes bids comparable, the evaluation criteria, and the questions each supplier must answer.
