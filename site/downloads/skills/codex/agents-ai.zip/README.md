# ИИ, Codex и агенты / AI, Codex and Agents · Codex

Перенесите нужные папки из skills/ в .agents/skills/ проекта или домашней папки.

Copy the skill folders you need from skills/ to .agents/skills/ in your project or home directory.

Рекомендации по моделям / Model guidance: [MODEL_GUIDE.md](MODEL_GUIDE.md).

Лицензии и авторство / Licenses and attribution: ATTRIBUTION.json and skill files.
