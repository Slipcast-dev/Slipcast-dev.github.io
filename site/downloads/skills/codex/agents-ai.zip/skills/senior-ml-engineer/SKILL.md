---
name: senior-ml-engineer
description: ML engineering skill for productionizing models, building MLOps pipelines,
  and integrating LLMs. Covers model deployment, feature stores, drift monitoring,
  RAG systems, and cost optimization. Use when the user asks about deploying ML models
  to production, setting up MLOps infrastructure (MLflow, Kubeflow, Kubernetes, Docker),
  monitoring model performance or drift, building RAG pipelines, or integrating LLM
  APIs with retry logic and cost controls. Focused on production and operational concerns
  rather than model research or initial training.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-ml-engineer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

