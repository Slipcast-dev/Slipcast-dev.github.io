---
name: skill-tester
description: 'Validate, test, and score the quality of skills within the claude-skills
  ecosystem. Comprehensive meta-skill: structure validation, Python script testing
  (syntax + imports + runtime + output format), multi-dimensional quality scoring
  with letter grades and tier classification (BASIC/STANDARD/POWERFUL). Use when authoring
  a new skill, auditing existing skills for tier promotion, setting up pre-commit
  hooks for skill quality, or integrating skill QA into CI.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# skill-tester

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

