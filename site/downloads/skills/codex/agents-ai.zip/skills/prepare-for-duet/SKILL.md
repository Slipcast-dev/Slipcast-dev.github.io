---
name: prepare-for-duet
description: "A readiness audit for proactive agents, useful while you are still on the waitlist: what in your memory, recurring prompts, connectors and inbox habits will help or hurt an agent that acts between your messages. Use when asked to prepare for Duet, get ready before my invite lands, audit my setup for a proactive agent, or what should I tidy before connecting my accounts."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# prepare-for-duet

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a scored readiness audit with the five tidy-ups worth doing now, each useful in the ordinary Claude app today even if the invite never comes.
