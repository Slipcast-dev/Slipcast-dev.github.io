---
name: delegate-to-ai
description: "Decide what in your workload to hand to AI and what to keep yourself — like managing a fast, capable, but unreliable new hire — so you get leverage without offloading the things that need you. Use when asked what should I delegate to AI, what can AI take off my plate, where should I use AI in my work, or what should I keep doing myself."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# delegate-to-ai

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a sort of your tasks into delegate-fully / delegate-with-review / keep-human, the reasoning behind each line, how to brief the AI on the delegated ones, and where your judgment is the actual value — a delegation map that frees your time without giving away your edge.
