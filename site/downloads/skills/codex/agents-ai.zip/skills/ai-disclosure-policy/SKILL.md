---
name: ai-disclosure-policy
description: "Decide when and how your product and communications must (or should) label AI-generated content, and write the disclosure policy — surface-by-surface rules, exact label wording, and the review trigger for regulations like the EU AI Act's transparency obligations. Use when asked 'do we have to label AI content', 'write our AI disclosure policy', 'are we covered for the AI Act', or when marketing/support/product start shipping AI-generated output. Not legal advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# ai-disclosure-policy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a disclosure policy with a per-surface matrix and ready-to-use label copy.
