---
name: prompt-debugging
description: "Figure out why a prompt isn't working and fix it — diagnose the actual failure (ambiguity, missing context, wrong format, conflicting instructions) instead of randomly rewording. Use when asked why isn't my prompt working, the AI keeps ignoring my instructions, my prompt gives inconsistent results, or how do I fix this prompt."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# prompt-debugging

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a diagnosis of the specific failure mode, the targeted fix for it (not a vibes rewrite), a corrected prompt, a check that it generalizes rather than fixing one case, and the principle behind the fix so you stop hitting it — turning prompt frustration into a debuggable, repeatable process.
