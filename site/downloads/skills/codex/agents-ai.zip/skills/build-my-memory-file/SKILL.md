---
name: build-my-memory-file
description: "Interview you into a durable personal MEMORY.md — your decision rules, patterns, past failures, and preferences — that any AI can read to help you better, with privacy guardrails built in. Use when asked to build my memory file, help my AI remember me, create a MEMORY.md, or set up context about myself."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# build-my-memory-file

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a structured personal-context file drawn out through good questions (how you decide, what you keep repeating, what you don't want to repeat), organized for an AI to use — while explicitly refusing to store sensitive data like credentials, financial, health, or others' personal info.
