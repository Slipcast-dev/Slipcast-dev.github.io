---
name: prompt-governance
description: 'Use when managing prompts in production at scale: versioning prompts,
  running A/B tests on prompts, building prompt registries, preventing prompt regressions,
  or creating eval pipelines for production AI features. Triggers: ''manage prompts
  in production'', ''prompt versioning'', ''prompt regression'', ''prompt A/B test'',
  ''prompt registry'', ''eval pipeline''. NOT for writing or improving individual
  prompts (use senior-prompt-engineer). NOT for RAG pipeline design (use rag-architect).
  NOT for LLM cost reduction (use llm-cost-optimizer).'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# prompt-governance

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

