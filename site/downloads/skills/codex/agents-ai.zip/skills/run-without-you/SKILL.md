---
name: run-without-you
description: Phase 4 of building a Claude Managed Agent — make it run without you.
  Turn a graded agent into a recurring scheduled deployment (POSIX-cron), an event-driven
  curl trigger, or confirmed on-demand use, then finalize the versioned roadmap. Use
  when the user says "run it every morning", "put it on a schedule", "nightly", "weekly",
  "automate this", "make it recurring", or when the orchestrator routes phase=run-without-you.
  deployment_builder.py builds the POST /v1/deployments payload (initial_events must
  include user.message; optionally nests a user.define_outcome so each firing self-grades);
  cron_validator.py validates the 5-field cron + IANA timezone and prints the wall-clock
  DST note; next_directions_writer.py writes NEXT-DIRECTIONS.md. No tool makes API
  calls — the deployment is created via BYOK curl. Distinct from grade-iterate (the
  in-session loop) and wrap-up (closeout).
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# run-without-you

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

