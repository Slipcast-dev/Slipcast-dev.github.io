---
name: agent-decision-receipts
description: 'Mint a tamper-evident, post-quantum-signed receipt for a consequential
  agent action (deploy, delete, pay, grant-access, model decision) so it can be verified
  later from the certificate alone. Use when an autonomous agent takes a side-effecting
  action that may need to be proven later, or when satisfying EU AI Act Article 12
  record-keeping. Three decisions: whether an action needs a receipt, minting it,
  verifying it. Signing is delegated to the open-source OpenAgentOntology package.
  Not after-the-fact log analysis; not a hosted notary; not a legal opinion.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# agent-decision-receipts

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

