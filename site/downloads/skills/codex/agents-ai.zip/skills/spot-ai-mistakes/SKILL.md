---
name: spot-ai-mistakes
description: "Learn to recognize where and how AI tends to go wrong — the specific failure patterns — so you catch its mistakes on sight instead of getting burned by confident errors. Use when asked how do I know when AI is wrong, what are AI's common mistakes, how do I catch AI errors, or where does AI mess up."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# spot-ai-mistakes

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the failure patterns most relevant to how you use AI (hallucinated facts, fake citations, outdated info, sycophancy, math slips, missed nuance), the tells that give each away, a quick check for the ones that would hurt you, and a calibrated trust level — so you develop the instinct to catch AI's errors before they cost you.
