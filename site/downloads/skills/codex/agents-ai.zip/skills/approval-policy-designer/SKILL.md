---
name: approval-policy-designer
description: "Design the approval policy for a proactive agent across every connected app: for each kind of action, whether it may act alone, must ask first, or must never do it, with money limits, recipient rules and an audit line. Use when asked what my agent should be allowed to do on its own, set approval rules for Duet, which actions need my yes, design an approval policy for my AI agent, or set spending or sending limits for an agent."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# approval-policy-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a per-app action table (act, ask, never), the thresholds, the default for anything unlisted, and the one-line rule to paste into the agent's instructions.
