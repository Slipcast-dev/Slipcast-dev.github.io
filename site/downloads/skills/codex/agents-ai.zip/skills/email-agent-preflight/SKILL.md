---
name: email-agent-preflight
description: "Run the pre-flight checklist before an agent touches an inbox — the read-vs-send permission line, the injection-in-email-body threat, the send-guard rules, and the blast-radius limits that keep a compromised agent from mailing the company. Use when asked let my agent read/send email safely, set up guardrails before the agent touches my inbox, is it safe to give the agent email access, or review my email agent's permissions."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# email-agent-preflight

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the permission tier, the injection defenses, the send-gate rules, and the incident kill-switch.
