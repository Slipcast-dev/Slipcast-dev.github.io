---
name: context-bankruptcy
description: "Declare bankruptcy on a long-lived AI agent's accumulated memory — audit what it currently believes, separate ground truth from stale and wrong, purge deliberately, restate the truths that survive, and log what was lost. Use when an agent keeps acting on outdated facts, contradicts itself across sessions, 'remembers' things wrong, or after a reorg/pivot makes its worldview obsolete."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# context-bankruptcy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a belief audit, a keep/correct/purge ledger, a restated ground-truth file, and the bankruptcy record.
