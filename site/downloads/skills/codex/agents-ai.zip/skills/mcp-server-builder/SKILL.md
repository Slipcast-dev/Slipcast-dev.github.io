---
name: mcp-server-builder
description: Design and ship production-ready MCP (Model Context Protocol) servers
  from OpenAPI contracts instead of hand-written tool wrappers. Python and TypeScript
  support, schema validation, safe evolution. Use when exposing an existing API as
  an MCP server, building tool integrations for Claude or Codex or Cursor, or scaffolding
  an MCP project from scratch.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# mcp-server-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

