---
name: loop
description: Start an autonomous experiment loop with user-selected interval (10min,
  1h, daily, weekly, monthly). Uses CronCreate for scheduling. Use when the user runs
  /ar:loop or asks to run an autoresearch experiment continuously on a schedule.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# loop

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

