---
name: autoresearch-agent
description: 'Autonomous experiment loop that optimizes any file by a measurable metric.
  Inspired by Karpathy''s autoresearch. The agent edits a target file, runs a fixed
  evaluation, keeps improvements (git commit), discards failures (git reset), and
  loops indefinitely. Use when: user wants to optimize code speed, reduce bundle/image
  size, improve test pass rate, optimize prompts, improve content quality (headlines,
  copy, CTR), or run any measurable improvement loop. Requires: a target file, an
  evaluation command that outputs a metric, and a git repo.'
license: MIT
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# autoresearch-agent

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
