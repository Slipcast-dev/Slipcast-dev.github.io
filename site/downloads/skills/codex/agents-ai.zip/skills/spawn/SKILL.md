---
name: spawn
description: Launch N parallel subagents in isolated git worktrees to compete on the
  session task. Use when the user runs /hub:spawn or asks to start the competing agents
  for an initialized AgentHub session.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# spawn

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

