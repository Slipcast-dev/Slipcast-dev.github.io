---
name: ai-context-primer
description: "Build the context an AI needs to do a task well — the background, constraints, examples, and format it can't guess — so you get a great result on the first try instead of a generic one you have to keep correcting. Use when asked why does AI give me generic answers, how do I give AI better context, my AI results are mediocre, or how do I get it right the first time."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ai-context-primer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the specific context this task needs (who/what/constraints/examples/format), a reusable primer you can paste ahead of the request, the difference between a starved prompt and a well-briefed one, and what to leave out — turning vague back-and-forth into a strong first result.
