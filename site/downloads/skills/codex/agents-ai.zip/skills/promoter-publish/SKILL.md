---
name: promoter-publish
description: "Register a finished skill in this library and produce the complete release package: the bundle wiring and marketplace entry, the regenerated catalogue and exports, the headline count in every living document, the CHANGELOG entry, the gates to run, and the exact git and release commands. Use when asked to publish this skill, release the new skill, add it to the marketplace, ship the promoted skill, or as the last step of the promote loop."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# promoter-publish

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the full release package, never a partial one, with a confirmation step before anything is pushed.
