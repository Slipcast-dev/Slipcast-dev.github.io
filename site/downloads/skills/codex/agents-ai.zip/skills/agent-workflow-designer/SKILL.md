---
name: agent-workflow-designer
description: Design production-grade multi-agent workflows with clear pattern choice
  (sequential, parallel, hierarchical), handoff contracts, failure handling, and cost/context
  controls. Use when architecting a multi-step agent pipeline, choosing between single-agent
  vs multi-agent approaches, or refactoring an LLM workflow that suffers from context
  bloat or unreliable handoffs.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# agent-workflow-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

