---
name: ai-usage-policy
description: "Write an AI usage policy people can actually follow — approved tools, data rules, disclosure duties, and review obligations, in one page instead of legal fog. Use when asked for a company AI policy, acceptable-use rules for ChatGPT/Claude/Copilot at work, guidance on what data may go into AI tools, or to fix a policy nobody reads. Not a substitute for legal advice; pairs with compliance-checklist for regulatory mapping and ai-ethics-review for system-level assessments."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ai-usage-policy

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page usable policy plus the decision log behind it.
