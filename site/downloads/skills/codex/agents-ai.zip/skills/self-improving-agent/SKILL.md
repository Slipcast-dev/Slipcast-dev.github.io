---
name: self-improving-agent
description: Curate the agent's own memory into durable project knowledge. Reviews
  Claude Code auto-memory (MEMORY.md and its topic files) for learnings worth keeping,
  promotes proven ones into AGENTS.md or .claude/rules/, records a correction as a
  lesson that persists across sessions, prunes stale or duplicate entries, and turns
  a recurring fix into a reusable skill. Use whenever the user asks what you have
  learned or saved about the project, which memories should become permanent rules,
  to remember a lesson or stop repeating a mistake, or to clean up, audit or check
  the health of memory.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# self-improving-agent

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
