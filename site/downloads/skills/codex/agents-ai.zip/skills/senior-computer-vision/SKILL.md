---
name: senior-computer-vision
description: Computer vision engineering skill for object detection, image segmentation,
  and visual AI systems. Covers CNN and Vision Transformer architectures, YOLO/Faster
  R-CNN/DETR detection, Mask R-CNN/SAM segmentation, and production deployment with
  ONNX/TensorRT. Includes PyTorch, torchvision, Ultralytics, Detectron2, and MMDetection
  frameworks. Use when building detection pipelines, training custom models, optimizing
  inference, or deploying vision systems.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-computer-vision

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

