---
name: hub-run
description: One-shot lifecycle command that chains init → baseline → spawn → eval
  → merge in a single invocation. Use when the user runs /hub:hub-run or asks to execute
  a full AgentHub competition end-to-end.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# hub-run

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

