---
name: get-more-from-ai
description: "Level up how you actually use AI — from basic one-shot questions to the techniques that get dramatically better results — matched to what you already do. Use when asked how do I get better at using AI, how do power users use AI, I feel like I'm using AI at 10%, or teach me to use AI better."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# get-more-from-ai

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an honest read of how you use AI now, the two or three highest-leverage techniques to add next (giving context, iterating, showing examples, breaking down tasks, verifying), a concrete before/after on your own use, and a simple practice path — so you close the gap between basic and expert without drowning in tips.
