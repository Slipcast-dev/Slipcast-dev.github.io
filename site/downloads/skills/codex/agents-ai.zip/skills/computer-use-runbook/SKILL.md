---
name: computer-use-runbook
description: "Write the step-by-step runbook a computer-use or browser agent follows to finish a real online task, such as cancelling a subscription or changing an energy supplier: what to look for on screen, one action per step, how to know it worked, and where to stop for a human. Use when asked to write instructions for a browser agent, make my agent cancel or change something online, or check whether a task is safe to hand to an agent."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# computer-use-runbook

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the runbook, the stop points and the final verification.
