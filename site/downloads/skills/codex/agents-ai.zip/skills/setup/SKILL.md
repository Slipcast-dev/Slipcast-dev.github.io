---
name: setup
description: Set up a new autoresearch experiment interactively. Collects domain,
  target file, eval command, metric, direction, and evaluator. Use when the user runs
  /ar:setup or asks to start optimizing a file with the autoresearch loop.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# setup

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

