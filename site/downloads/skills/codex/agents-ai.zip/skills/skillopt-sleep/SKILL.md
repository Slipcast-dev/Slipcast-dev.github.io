---
name: skillopt-sleep
description: 'Use when the user wants their Claude agent to self-improve from past
  usage, asks about a nightly/offline ''sleep'' or ''dream'' cycle, memory/skill consolidation,
  or says things like ''make my agent better the more I use it'', ''review my past
  sessions'', ''learn my preferences'', ''consolidate what you learned'', ''run the
  sleep cycle'', or wants to schedule offline self-optimization. Drives the skillopt_sleep
  engine: harvest past sessions → mine recurring tasks → replay offline → consolidate
  validated AGENTS.md and SKILL.md behind a held-out gate.'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# skillopt-sleep

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Runtime отсутствует в установленном наборе: scripts/sleep.sh и пакет skillopt_sleep не включены. Доступны только инструкции; запуск, adopt и schedule возвращают blocked до отдельной установки и проверки CLI.
