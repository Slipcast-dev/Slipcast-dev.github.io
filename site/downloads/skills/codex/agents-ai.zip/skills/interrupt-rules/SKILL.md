---
name: interrupt-rules
description: "Write the between-brief alert rules for a proactive agent: exactly what may interrupt you, what waits for the next brief, and the wording of an interruption. Use when asked to set interrupt rules, only alert me for X, stop my agent pinging me, decide what counts as urgent for Duet, or define when an AI assistant may break my focus."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# interrupt-rules

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a short ruleset with named interrupt triggers, a default of silence, quiet hours, and the three-line alert format.
