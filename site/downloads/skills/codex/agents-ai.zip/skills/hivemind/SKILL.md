---
name: hivemind
description: Orchestrate free opencode workers from Claude Code to cut token costs.
  Use when delegating grunt work to a single worker or a parallel swarm (scout/coder/tester)
  with worktree isolation, benchmarking against opencode, or when the user says "spawn
  a worker", "swarm", "delegate to opencode", or "/oc".
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# hivemind

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
