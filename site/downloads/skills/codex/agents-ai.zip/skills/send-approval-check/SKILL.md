---
name: send-approval-check
description: "The gate before an agent sends anything on your behalf: one card showing recipient, sending account, subject, attachments, and the single sentence that commits you to something, so approving the wording is never mistaken for approving the send. Use when asked to check before sending, show me exactly what is about to go out, set up a send approval gate, or review this outgoing email or message an agent drafted."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# send-approval-check

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the approval card, the commitment sentence quoted, the risk flags, and an explicit approve-the-send question separate from the draft.
