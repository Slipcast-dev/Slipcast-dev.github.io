---
name: ai-workflow-designer
description: "Design an AI-assisted workflow for a recurring task — which steps to hand to AI, which to keep human, and how they connect — so you get leverage without losing quality or control. Use when asked how do I use AI for [process], automate this with AI, design an AI workflow, or where does AI fit in my process."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# ai-workflow-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a map of the task's steps split into AI-does / human-does / human-checks, the right tool/prompt for each AI step, the hand-offs and review points, the failure modes to guard against, and a start-small rollout — turning a manual process into a reliable AI-assisted one that keeps you in control.
