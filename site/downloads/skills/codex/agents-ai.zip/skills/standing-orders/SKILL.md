---
name: standing-orders
description: "Write the operating manual a proactive agent follows between your messages: who is a VIP, what it may always do, what it must never do, the tone it writes in, and when it must stop and ask. Use when asked to write standing orders for my agent, set ground rules for Duet, tell my agent how to behave when I am not there, write my agent's operating manual, or set always and never rules for a proactive agent."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# standing-orders

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a one-page standing-orders file to paste into the agent's memory or instructions, with the always list, the never list, VIPs, tone rules, escalation triggers and a review date.
