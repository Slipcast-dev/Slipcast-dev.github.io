---
name: agent-severance
description: "Offboard an AI agent the way you'd offboard an employee — inventory what it knew and touched, export then purge its memory, revoke every credential and access grant, and write the handover for its successor (human or agent). Use when decommissioning an agent or bot, switching agent vendors, ending an AI pilot, or when someone asks 'what did this thing have access to?'."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# agent-severance

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a severance checklist, an access-revocation table, a memory disposition record, and a successor handover.
