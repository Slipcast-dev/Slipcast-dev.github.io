---
name: promote
description: Graduate a proven pattern from auto-memory (MEMORY.md) to AGENTS.md or
  .claude/rules/ for permanent enforcement. Use when the user runs /si:promote or
  asks to make a learned behavior permanent.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# promote

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
