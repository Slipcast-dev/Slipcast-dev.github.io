---
name: memory-file-maintenance
description: "Keep your AI memory/context file (MEMORY.md, AGENTS.md, custom instructions) healthy over time — pruning the stale, adding the new, and keeping it sharp so your AI keeps getting you right. Use when asked review my memory file, my AI context is outdated, clean up my AGENTS.md, or maintain my AI instructions."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# memory-file-maintenance

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a review of your existing memory/instructions file (what's stale, contradictory, bloated, or missing), edits to prune and sharpen it, additions from recent patterns worth remembering, and a light maintenance habit — because a memory file that isn't tended drifts from who you actually are, with a privacy check on what should never be stored.
