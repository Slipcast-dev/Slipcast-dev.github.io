---
name: ai-tool-picker
description: "Figure out which AI tool actually fits the task in front of you — chatbot, coding assistant, image model, agent, or none — instead of forcing one tool onto everything. Use when asked which AI tool should I use for, what's the best AI for, do I even need AI for this, or should I use ChatGPT or something else."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ai-tool-picker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a match between your task and the right kind of AI tool (with why), the trade-offs that matter for your case, when the answer is a non-AI tool or plain human effort, and how to try it cheaply before committing — so you pick by fit, not by hype or habit.
