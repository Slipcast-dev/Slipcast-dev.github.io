---
name: loop-library
description: Discover, find, compare, audit, repair, adapt, and design repeatable
  AI-agent loops with explicit triggers, actions, verification, stopping conditions,
  guardrails, and handoffs. Use when a user asks to analyze a codebase for potential
  loops, mine coding-thread history for work done more than once, turn repeated engineering
  work into a loop, find or recommend a published loop, create a recurring agent workflow
  or automation cadence, turn an outcome into a bounded copy-ready loop, or review
  an existing loop for weak checks, unsafe authority, unbounded repetition, stale
  state, or unclear stopping behavior.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# loop-library

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

