---
name: ai-content-audit
description: "Audit a content library, docs site, or blog for AI-generated filler that's eroding trust and search performance — and triage what to fix, rewrite, or delete. Use when asked to find slop in a content library, audit AI-written content quality, explain why content engagement or rankings dropped after scaling with AI, or set a quality bar for AI-assisted publishing. For a single article's AI-citability use aeo-optimizer; for the strategy itself use content-calendar or seo-content-brief."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# ai-content-audit

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces an audited inventory with per-piece verdicts, the detection signals used, a triage plan, and a publishing quality gate that prevents recurrence.
