---
name: prompt-library-builder
description: "Build a personal library of reusable prompts for the things you ask AI again and again — so you stop rewriting the same request from scratch. Use when asked help me build a prompt library, save my best prompts, I keep writing the same prompts, or organize my AI prompts."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# prompt-library-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a captured set of your recurring AI tasks turned into reusable, parameterized prompt templates, an organization scheme so you can find them, guidance on what makes a prompt reusable (clear role, inputs, output format), and how to store and improve them — turning ad-hoc prompting into a personal toolkit that compounds.
