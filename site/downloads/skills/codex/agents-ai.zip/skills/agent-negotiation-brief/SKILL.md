---
name: agent-negotiation-brief
description: "Brief an AI agent that will negotiate for you with another party's agent or a person (a refund, a price, a meeting time, a contract term): your goal, your opening, your limits, your walk-away point, what it must never reveal, and when it must come back to you. Use when asked to let my agent negotiate, brief my AI for a negotiation, set limits for an agent bargaining on my behalf, or prepare for agent-to-agent negotiation."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# agent-negotiation-brief

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the brief, the concession ladder, the never-reveal list and the hand-back triggers.
