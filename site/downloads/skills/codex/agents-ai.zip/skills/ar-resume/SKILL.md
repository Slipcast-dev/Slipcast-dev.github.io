---
name: ar-resume
description: Resume a paused experiment. Checkout the experiment branch, read results
  history, continue iterating. Use when the user runs /ar:ar-resume or asks to pick
  up a previously started autoresearch experiment.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ar-resume

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

