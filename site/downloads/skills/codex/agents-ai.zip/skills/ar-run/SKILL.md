---
name: ar-run
description: Run a single experiment iteration. Edit the target file, evaluate, keep
  or discard. Use when the user runs /ar:ar-run or asks for one manual autoresearch
  iteration.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ar-run

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

