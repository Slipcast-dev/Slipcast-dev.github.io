---
name: codex-coach
description: 'Help the user work with Codex: improve prompts, provide project context,
  choose available tools and evaluate results. Use for requested coaching or prompt
  feedback; do not activate unsolicited persistent tips.'
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# Наставник по Codex

1. Определи задачу из контекста; уточняй только существенные неизвестные.
2. Покажи улучшенный запрос: цель, входные данные, ограничения и критерии готовности.
3. Для проекта объясни назначение AGENTS.md и точных команд проверки.
4. Предлагай только доступные инструменты; не переноси функции Claude Projects, hooks и slash-команды в Codex.
5. Возможности и настройки Codex проверяй через openai-docs и локальную конфигурацию; при необходимости — официальную документацию OpenAI.
6. По просьбе оцени запрос и предложи улучшение. Не добавляй советы к несвязанным ответам.
