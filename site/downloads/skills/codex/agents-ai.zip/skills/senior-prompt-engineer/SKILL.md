---
name: senior-prompt-engineer
description: Use when the user asks to optimize prompts, design prompt templates,
  evaluate LLM outputs with an eval set, measure RAG retrieval quality, validate agent/tool
  configurations, analyze token usage, or design structured-output contracts. Covers
  eval-driven prompt iteration, RAG metrics (relevance, faithfulness, coverage), agent
  workflow validation, and token/cost budgeting — all model-agnostic, with three stdlib
  Python tools.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-prompt-engineer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
