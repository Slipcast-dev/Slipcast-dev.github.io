---
name: make-me-a-skill
description: "Turn a task you repeat every week into a reusable personal skill or prompt — so you say 'do this' instead of re-explaining it every time. Use when asked help me make a skill for, turn this repetitive task into a template, I do this every week, or create a reusable prompt for this."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# make-me-a-skill

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a captured spec of the repetitive task (its inputs, steps, and what good output looks like), a reusable skill/prompt you can invoke by name, and guidance on saving and refining it — lowering the barrier from AI user to AI author, one weekly task at a time.
