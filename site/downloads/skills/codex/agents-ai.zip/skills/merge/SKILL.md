---
name: merge
description: Merge the winning agent's branch into base, archive losers, and clean
  up worktrees. Use when the user runs /hub:merge or asks to land the winning AgentHub
  result and tidy the session.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# merge

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

