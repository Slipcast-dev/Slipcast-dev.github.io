---
name: run-an-agent-team
description: "Design a small team of AI agents to tackle a complex task in parallel — who does what, how they hand off, and how to keep them coordinated — instead of one overloaded agent doing everything serially. Use when asked how do I use multiple AI agents, set up an agent team, orchestrate agents for, or run agents in parallel."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

<!-- slipcast-model-profile:start -->
## Выполнение в Codex

- Рекомендуемая модель: **GPT-6.2 Sol**. Для более сложного случая вручную выберите **GPT-6.2 Astra** в /model, если она доступна.
- Работай в текущей модели Codex и загружай только нужные разделы. Разбей работу на проверяемые шаги и сообщи о результатах проверок.
- Открой относящиеся к задаче файлы, сохрани существующие контракты и проверь изменённый сценарий.
<!-- slipcast-model-profile:end -->


# run-an-agent-team

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a decomposition of the task into agent roles, a coordination pattern (parallel vs sequential, how outputs combine), the context each agent needs (and what to keep isolated), a review/quality step, and the guardrails to keep it from going off the rails — practical multi-agent design for real tasks.
