---
name: explorer-pipeline
description: "Use when asked to make an interactive 3D explorer of a topic from start to finish, go from a topic to a clickable 3D learning page, or run the whole 3D explorer process."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# explorer-pipeline

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a staged run of explorer-interface-brief, model-prompt-pack and explorer-viewer-builder in order for one topic, with the hand-offs between them, and a build checklist that tracks every asset, source and test until the explorer ships.
