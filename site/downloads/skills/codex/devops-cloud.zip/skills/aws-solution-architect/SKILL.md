---
name: aws-solution-architect
description: Design AWS architectures for startups using serverless patterns and IaC
  templates. Use when asked to design serverless architecture, create CloudFormation
  templates, optimize AWS costs, set up CI/CD pipelines, or migrate to AWS. Covers
  Lambda, API Gateway, DynamoDB, ECS, Aurora, and cost optimization.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# aws-solution-architect

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

