---
name: fortnightly-release-planner
description: Use when asked to plan releases for a side project or small open-source
  repo, turn a backlog into a release schedule, ship smaller and more often, or write
  a ROADMAP.md. Turns a backlog into small themed two-week releases and produces ROADMAP.md,
  a theme and scope for each release with what is deliberately left out, and a changelog
  template. For a stakeholder roadmap narrative inside a company, use roadmap-narrative.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# fortnightly-release-planner

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

