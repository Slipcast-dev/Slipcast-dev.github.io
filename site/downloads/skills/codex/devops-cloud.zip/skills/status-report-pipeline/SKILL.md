---
name: status-report-pipeline
description: "Build the pipeline that turns team updates into the rollup report without the Friday scramble — the collection format that aggregates cleanly, the altitude translation (team detail → leadership signal), and the automation-lite assembly that takes minutes. Use when asked I compile status from five teams every week, streamline our reporting chain, my Friday is spent chasing updates, or make the rollup write itself."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# status-report-pipeline

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the collection design, the translation rules, the assembly routine, and the chase-elimination mechanics.
