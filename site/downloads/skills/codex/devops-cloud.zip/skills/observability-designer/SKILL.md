---
name: observability-designer
description: Design production-ready observability strategies combining metrics, logs,
  and traces. Includes SLI/SLO design, golden-signals monitoring, alert optimization.
  Use when adding observability to a new service, refactoring alerting that is too
  noisy, or designing an SLO program before scaling production load.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# observability-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

