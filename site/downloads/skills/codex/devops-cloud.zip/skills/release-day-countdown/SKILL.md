---
name: release-day-countdown
description: "Plan an independent music release backwards from release day — the 8-week countdown with distributor upload deadlines flagged, playlist pitch windows, the pre-save decision made honestly, content batched before the chaos, and a release week that doesn't depend on luck. Use when a musician says 'I'm releasing a single/EP', 'when should I submit to playlists', 'plan my release', or uploaded to a distributor with no plan."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# release-day-countdown

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the week-by-week countdown, the asset checklist, and release-week runbook.
