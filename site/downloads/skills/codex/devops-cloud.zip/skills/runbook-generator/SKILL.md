---
name: runbook-generator
description: Generate operational runbooks from a service name — deployment, incident
  response, maintenance, and rollback workflows. Templated structure customizable
  per environment. Use when documenting on-call procedures for a new service, standardizing
  incident response across teams, or producing runbooks before launching to production.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# runbook-generator

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

