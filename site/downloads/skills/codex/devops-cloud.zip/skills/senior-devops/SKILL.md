---
name: senior-devops
description: Comprehensive DevOps skill for CI/CD, infrastructure automation, containerization,
  and cloud platforms (AWS, GCP, Azure). Includes pipeline setup, infrastructure as
  code, deployment automation, and monitoring. Use when setting up pipelines, deploying
  applications, managing infrastructure, implementing monitoring, or optimizing deployment
  processes.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# senior-devops

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

