---
name: signature-pipeline-watch
description: "Have a proactive agent watch documents waiting for signature in DocuSign, Adobe Sign or PandaDoc: which are stuck, for how long, with whom, which have expiry dates coming, and which signed ones still need countersigning or filing, reported in the brief with drafted reminders a human sends. Use when asked to track contracts waiting for signature, chase unsigned DocuSign envelopes, have Duet watch my e-signatures, what contracts are stuck, or remind me about documents nobody has signed."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# signature-pipeline-watch

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the watch rules, the pipeline lines by stage and age, the drafted reminder per stuck envelope, and the interrupt rule for expiring envelopes.
