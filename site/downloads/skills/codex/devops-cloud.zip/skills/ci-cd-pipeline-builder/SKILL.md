---
name: ci-cd-pipeline-builder
description: Generate pragmatic CI/CD pipelines from detected project stack signals
  — fast baseline generation, repeatable checks, environment-aware deployment stages.
  Use when setting up CI for a new project, refactoring existing pipelines, or standardizing
  deployment workflows across multiple repos.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ci-cd-pipeline-builder

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

