---
name: performance-profiler
description: Systematic performance profiling for Node.js, Python, and Go applications.
  Identifies CPU, memory, and I/O bottlenecks, generates flamegraphs, analyzes bundle
  sizes, optimizes database queries, runs load tests with k6 and Artillery. Always
  measures before and after. Use when investigating a slow endpoint, planning a performance
  budget, or hunting a memory leak in production.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# performance-profiler

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

