---
name: ai-security
description: Use when assessing AI/ML systems for prompt injection, jailbreak vulnerabilities,
  model inversion risk, data poisoning exposure, or agent tool abuse. Covers MITRE
  ATLAS technique mapping, injection signature detection, and adversarial robustness
  scoring.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ai-security

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

