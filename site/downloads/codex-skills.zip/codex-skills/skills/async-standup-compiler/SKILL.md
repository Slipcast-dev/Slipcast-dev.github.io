---
name: async-standup-compiler
description: Compile the team's REAL updates into one async standup — pull what people
  posted in Slack (and moved in Notion/Linear), not a template for running standups.
  Use when asked to compile today's standup, pull the team's updates into one post,
  what did the team ship, or run async standup in Cowork. Reads a Slack channel and
  (optionally) the tracker via connectors, groups updates by person into shipped /
  in-progress / blocked, surfaces the blockers needing attention, and produces a standup-digest
  artifact ready to post back.
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# async-standup-compiler

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

