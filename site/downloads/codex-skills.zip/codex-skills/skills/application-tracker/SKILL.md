---
name: application-tracker
description: "Set up and keep a job application tracker: one master CV, every tailored version, where each was sent, its status, next action and follow-up date, plus a weekly review of what is working. Use when asked to track my job applications, organise my job search, which CV did I send to which company, or what should I follow up on this week."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# application-tracker

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tracker table (markdown or CSV) with one row per application, a version log linking each to its tailored CV, this week's actions, and a short weekly review of response rates by source.
