---
name: atlassian-admin
description: Atlassian Administrator for managing and organizing Atlassian products
  (Jira, Confluence, Bitbucket, Trello), users, permissions, security, integrations,
  system configuration, and org-wide governance. Use when asked to add users to Jira,
  change Confluence permissions, configure access control, update admin settings,
  manage Atlassian groups, set up SSO, install marketplace apps, review security policies,
  or handle any org-wide Atlassian administration task.
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# atlassian-admin

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

