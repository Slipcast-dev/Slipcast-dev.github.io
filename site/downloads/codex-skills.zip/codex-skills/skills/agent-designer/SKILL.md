---
name: agent-designer
description: 'Use when the user asks to design a multi-agent system, pick an orchestration
  pattern (supervisor/swarm/pipeline), generate tool schemas for agents, or evaluate
  agent execution logs for cost, latency, and failure bottlenecks. Examples: ''design
  an agent architecture for research automation'', ''generate Anthropic tool schemas
  from these tool descriptions'', ''analyze these agent run logs for bottlenecks''.
  NOT for Claude Code workflow files (use workflow-builder) or single-agent prompt
  design (use agent-workflow-designer).'
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# agent-designer

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

