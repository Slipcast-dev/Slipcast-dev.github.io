---
name: aging-in-place-assessment
description: "Assess whether and how someone can safely stay in their own home as they age — the home hazards, the support gaps, and the modifications and services that make it work. Use when asked can my parent stay in their home safely, aging in place assessment, is it safe for them to live alone, or what do we need for them to stay home. Not medical advice."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# aging-in-place-assessment

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a room-by-room safety read (fall hazards, accessibility), an honest look at the daily-living and support gaps, the modifications and services that could close them, warning signs that home may no longer be safe, and how to raise it respectfully — helping a family make a clear-eyed, dignity-preserving decision.
