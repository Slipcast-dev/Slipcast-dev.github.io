---
name: announcement-card
description: "Write a short, punchy announcement designed to be shared as an image or social card. Use when asked to announce a launch, milestone, feature, hire, funding, or win — something to post on LinkedIn/X/Slack."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# announcement-card

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces a tight, visually-structured announcement (headline, one-liner, 2-3 proof points, CTA) that looks great exported as a PNG card from the playground.
