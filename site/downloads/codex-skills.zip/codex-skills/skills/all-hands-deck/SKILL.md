---
name: all-hands-deck
description: "Build an all-hands that lands with everyone from intern to VP — the mixed-altitude structure (the story for all, the numbers for some), the wins-with-names section done right, the hard-news slide handled straight, and the Q&A design that gets real questions. Use when asked build the all-hands deck, make the monthly town hall not boring, how do we share the numbers with everyone, or announce this change at all-hands."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# all-hands-deck

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the segment structure, the altitude-mixed content rules, the hard-news handling, and the Q&A mechanics.
