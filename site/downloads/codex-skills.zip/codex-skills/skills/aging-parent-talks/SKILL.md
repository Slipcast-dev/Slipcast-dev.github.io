---
name: aging-parent-talks
description: "Prepare the conversations with aging parents that everyone postpones — the driving talk, the money talk, the care-options talk, the moving talk — each with an opener that doesn't ambush, a dignity-first script, rehearsal against realistic resistance, and the fallback when it goes badly. Use when someone says 'I need to talk to my dad about driving', 'my mum won't discuss her finances', 'we need to talk about care', or is dreading a visit for exactly this reason. A preparation tool, not family therapy — and it says so when the situation needs more."
metadata:
  source-package: pm-claude-skills-main
  adapted-for: Codex
---

# aging-parent-talks

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.

## Требования к результату

Produces the conversation plan, a rehearsal, and the small-steps fallback.
