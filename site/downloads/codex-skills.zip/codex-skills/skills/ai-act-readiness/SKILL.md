---
name: ai-act-readiness
description: /compliance-os:ai-act-readiness [system] — EU AI Act 6-question forcing
  interrogation. Use during AI-system intake, before EU deployment, or during annual
  compliance refresh as Article 113 obligations phase in (2025-02-02 / 2025-08-02
  / 2026-08-02 / 2027-08-02).
metadata:
  source-package: claude-skills-main
  adapted-for: Codex
---

# ai-act-readiness

## Работа в Codex

Прочитай нужные разделы [процедуры](WORKFLOW.md) и только необходимые ресурсы. Пути считай от файла ссылки.
Соблюдай AGENTS.md, цель, стек и полномочия. Навык не разрешает запуск агентов, hooks и фоновых действий.
Используй доступные API Codex и штатный MCP; команды Claude не переноси механически. Укажи недоступные зависимости.
Перед запуском проверь код, зависимости, пути и эффекты. Примеры не доказательство; актуальные API и тарифы сверяй по первоисточникам.
Уточняй существенное; порученные обратимые действия выполняй сам.



## Особенности переноса

- Исходные команды или настройки требуют проверки совместимости.
