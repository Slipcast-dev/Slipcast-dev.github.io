[Русский](CHANGELOG.md) | [English](CHANGELOG.en.md)

# Changelog

## 2.0 — 2026-11-19

- Release for Astra 6.2 and Sol 6.2 from Codex-skills-backup-2026-11-19.zip.
- Refreshed 1671 skill folders and retained 139 existing skills: 1810 skills across 22 categories in total.
- Updated the repository description, Russian and English README, information badges, and banners.
- Updated links to the current codex-skills repository name.
- Added catalog/snapshot.json with the snapshot inventory and original ZIP SHA-256.
- Attached the original supplied archive without repackaging and SHA256SUMS.txt to the release.

## 1.2.0 — 2026-11-05

- Refreshed 1787 existing skills from the November 5, 2026 user snapshot and added systems-engineering.
- Updated 1546 descriptions, catalogs, and category pages in Russian and English.
- Removed 1646 obsolete references/activation-details.md files from updated folders.
- Retained 22 existing skills absent from the new snapshot: 1810 skills across 22 categories in total.
- Source package and license for systems-engineering are not specified in its files (unknown / NOASSERTION).

## 1.1.0 — 2026-11-03

- Russian and English documentation and catalog navigation.
- English versions of category pages, license and provenance notes, and community documents, with language switches.
- English translations of Russian catalog descriptions; original skill instructions and resources preserved in their source languages.
- Bilingual issue and pull request templates and a RU/EN languages badge.

## 1.0.0 — 2026-11-03

- Initial public collection of 1809 user skills for OpenAI Codex.
- A catalog across 22 topic categories with descriptions for every skill.
- Original licenses and provenance, installation instructions, and community documents.
- Catalog checks in GitHub Actions and a release archive with a download counter.
