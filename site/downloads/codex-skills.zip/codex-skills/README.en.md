[Русский](README.md) | [English](README.en.md)

<p align="center">
  <img src="assets/banner.svg" alt="Codex Skills — a collection of user skills for OpenAI Codex" width="100%">
</p>

# Codex Skills

**User skills for OpenAI Codex, organized by topic.** The collection contains 1810 skills across 22 categories, covering software development, AI, documents, business, and everyday tasks. Each skill has its own `SKILL.md`; each category has a complete list of its skills and descriptions.

[![Astra 6.2](https://img.shields.io/badge/Astra-6.2-a78bfa?style=flat-square)](https://github.com/Slipcast-dev/codex-skills/releases/tag/v2.0)
[![Sol 6.2](https://img.shields.io/badge/Sol-6.2-6ee7b7?style=flat-square)](https://github.com/Slipcast-dev/codex-skills/releases/tag/v2.0)
[![Snapshot](https://img.shields.io/badge/snapshot-2026--11--19-334155?style=flat-square)](catalog/snapshot.json)

[![Catalog validation](https://github.com/Slipcast-dev/codex-skills/actions/workflows/validate.yml/badge.svg)](https://github.com/Slipcast-dev/codex-skills/actions/workflows/validate.yml)
[![Skills](https://img.shields.io/badge/skills-1810-0f766e)](CATALOG.en.md)
[![Categories](https://img.shields.io/badge/categories-22-2563eb)](CATALOG.en.md)
[![Release](https://img.shields.io/github/v/release/Slipcast-dev/codex-skills)](https://github.com/Slipcast-dev/codex-skills/releases/latest)
[![Release downloads](https://img.shields.io/github/downloads/Slipcast-dev/codex-skills/total?label=release%20downloads)](https://github.com/Slipcast-dev/codex-skills/releases)
[![GitHub stars](https://img.shields.io/github/stars/Slipcast-dev/codex-skills?style=flat)](https://github.com/Slipcast-dev/codex-skills/stargazers)
[![Last commit](https://img.shields.io/github/last-commit/Slipcast-dev/codex-skills)](https://github.com/Slipcast-dev/codex-skills/commits/main)
[![Format](https://img.shields.io/badge/format-SKILL.md-7c3aed)](https://developers.openai.com/codex/skills)
[![Languages](https://img.shields.io/badge/languages-RU%20%7C%20EN-0284c7)](README.md)
[![Licenses](https://img.shields.io/badge/licenses-per--skill-64748b)](THIRD_PARTY_NOTICES.en.md)

An independent community collection. This repository is not an official OpenAI product and does not imply endorsement or support from OpenAI. Bundled Codex system skills and skills from installed plugins are excluded.

Documentation and navigation are available in Russian and English. Skill instructions and resources are preserved in their source languages. Most descriptions were originally written in English; Russian descriptions have English translations in the English catalog. The main repository README is [in Russian](README.md).

## Version 2.0 — November 19, 2026

An updated skills snapshot for **Astra 6.2** and **Sol 6.2** in Codex. **1671 skill folders** were refreshed from the November 19 archive; **139 skills** were retained from the previous version. The full repository contains **1810 skills across 22 categories**.

![Version 2.0 snapshot](assets/release-banner.svg)

| Release | Contents |
| --- | --- |
| [Release v2.0](https://github.com/Slipcast-dev/codex-skills/releases/tag/v2.0) | 2026-11-19 · Astra 6.2 / Sol 6.2 |
| [Original ZIP](https://github.com/Slipcast-dev/codex-skills/releases/download/v2.0/Codex-skills-backup-2026-11-19.zip) | 1671 skills; the supplied archive, without repackaging |
| [SHA256SUMS.txt](https://github.com/Slipcast-dev/codex-skills/releases/download/v2.0/SHA256SUMS.txt) | Original archive checksum |
| [Snapshot inventory](catalog/snapshot.json) | Date, models, SHA-256, and lists of updated and retained skills |

The archive contains the refreshed portion of the collection. Clone the repository or download **Source code** from the release page for all 1810 skills. In the original ZIP, skill folders sit directly under `Codex-skills-backup-2026-11-19/`; select a skill folder and install it in full. Publication checks cover file integrity and the catalog; all skills have not been run on both models.

## Categories and search

Open **[the complete catalog](CATALOG.en.md)** for every category, its skill count, and links to detailed lists. Each category page lists all of its skills and their purposes.

| Topic | Page |
| --- | --- |
| AI, Codex, and agents | [Skill list](categories/agents-ai.en.md) |
| Software development and architecture | [Skill list](categories/development.en.md) |
| DevOps, cloud, and operations | [Skill list](categories/devops-cloud.en.md) |
| Security and privacy | [Skill list](categories/security-privacy.en.md) |
| Data and analytics | [Skill list](categories/data-analytics.en.md) |
| Design and creativity | [Skill list](categories/design-creative.en.md) |
| Product and strategy | [Skill list](categories/product-strategy.en.md) |
| Marketing, SEO, and growth | [Skill list](categories/marketing-growth.en.md) |
| Writing and communication | [Skill list](categories/writing-communication.en.md) |
| All 22 categories | **[Open the catalog](CATALOG.en.md)** |

Categories provide editorial navigation by purpose. Each skill has one primary category; it does not identify the author or license. To search the whole collection, use [the machine-readable catalog](catalog/skills.json) or GitHub search within this repository.

## Install one skill

Start by reading its `SKILL.md`, related files, and license. A skill may require separate applications, libraries, MCP connections, or other skills. These dependencies are not installed automatically.

### Through Codex

If `$skill-installer` is available in your installation, send Codex this request:

```text
$skill-installer Install the skill from https://github.com/Slipcast-dev/codex-skills/tree/main/skills/focused-fix
```

For skill locations, discovery, and invocation, see [the official Codex documentation](https://developers.openai.com/codex/skills).

### Manual installation: macOS and Linux

Git must be installed. This example copies one skill into the user directory `~/.agents/skills` and skips the copy if a folder with the same name already exists:

```sh
git clone https://github.com/Slipcast-dev/codex-skills.git
cd codex-skills
mkdir -p "$HOME/.agents/skills"
if [ -e "$HOME/.agents/skills/focused-fix" ]; then
  echo "The focused-fix skill already exists. Back it up or rename it first."
else
  cp -R skills/focused-fix "$HOME/.agents/skills/"
fi
```

### Manual installation: Windows PowerShell

```powershell
git clone https://github.com/Slipcast-dev/codex-skills.git
Set-Location codex-skills
$skillsDirectory = Join-Path $HOME '.agents/skills'
$destination = Join-Path $skillsDirectory 'focused-fix'
New-Item -ItemType Directory -Force -Path $skillsDirectory | Out-Null
if (Test-Path $destination) {
    throw 'The focused-fix skill already exists. Back it up or rename it first.'
}
Copy-Item -Recurse -Path 'skills/focused-fix' -Destination $destination
```

Copy **the complete skill folder**, including `WORKFLOW.md`, `references/`, `scripts/`, and license files when present. Restart Codex if the skill does not appear, then mention it in your request using `$focused-fix`.

These commands describe manual file placement. They do not establish that every skill and its dependencies work on every operating system. The collection also excludes user agent definitions from `.codex/agents`.

## Download the collection

On **[the latest release page](https://github.com/Slipcast-dev/codex-skills/releases/latest)**, the original ZIP in **Assets** contains 1671 refreshed skills. Download **Source code (zip/tar.gz)** or clone the repository for the complete collection of 1810 skills. Extract the chosen archive and install selected skills as complete folders using the instructions above.

The **release downloads** badge counts downloads of files attached to GitHub releases. It does not include `git clone`, automatically generated **Source code (zip/tar.gz)** archives, or individual skill installations. The badge is provided by [Shields.io](https://shields.io/badges/git-hub-downloads-all-assets-all-releases).

## Collection structure

```text
skills/<skill-name>/   Complete skill folder with SKILL.md and supporting files
categories/           Topic-based skill lists with descriptions, in RU and EN
catalog/              Machine-readable skills, categories, and provenance
assets/               Repository artwork
scripts/              Catalog maintenance tools
.github/              Checks and contribution templates
```

Folders in `skills/` remain side by side because some original instructions reference neighboring folders through `../`. Moving skills into physical category folders could break those links. Category navigation is stored separately. If a skill references a neighboring skill, check whether it is available and install it separately when needed.

## Licenses and provenance

The collection includes materials from different authors. **A single license does not automatically apply to every skill.** Each skill is governed by its original `LICENSE`, `NOTICE`, and other notices. These files are preserved alongside the skill.

See [THIRD_PARTY_NOTICES.en.md](THIRD_PARTY_NOTICES.en.md) for a summary and materials whose license is unspecified; [LICENSE](LICENSE) defines the scope of the repository's license. There is no separate license file for 135 skills. The source package and license for the added `systems-engineering` skill are unspecified. A missing license file does not automatically assign an MIT license or establish terms for downstream use. A catalog entry does not itself grant new rights to third-party materials. The original legal license text is preserved without translation.

## Contributing and support

- [Propose a correction or a new skill](CONTRIBUTING.en.md)
- [Code of conduct](CODE_OF_CONDUCT.en.md)
- [Report a vulnerability](SECURITY.en.md)
- [Questions and help](SUPPORT.en.md)
- [Changelog](CHANGELOG.en.md)

Issue templates, contributor instructions, and the security policy follow [GitHub's recommendations for public repositories](https://docs.github.com/en/communities/setting-up-your-project-for-healthy-contributions/about-community-profiles-for-public-repositories).
