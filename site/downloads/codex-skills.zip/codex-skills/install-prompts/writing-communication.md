# Промт для установки: Тексты, документы и коммуникация → Codex

Скопируй текст ниже и вставь в Codex.

```text
Установи в Codex пользовательские навыки категории «Тексты, документы и коммуникация» (`writing-communication`, 156 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "writing-communication"` в `catalog/skills.json` (то же списком в `categories/writing-communication.md`), например `all-hands-deck`, `altitude-shifter`, `announcement-card`, `apology-letter`, `awkward-message-helper`, `behuman`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='writing-communication']"`. Должно получиться 156.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `chart-choice`, `consulting-proposal`, `content-production`, `content-strategy`, `data-slide-design`, `decision-meeting-format`, `doc-versioning-discipline`, `evidence-grading`, `executive-summary`, `faq-builder`, `filename-convention`, `kpi-tracker-design`, `launch-readiness`, `localization-brief`, `meeting-prep-pack`, `onboarding-buddy-plan`, `product-launch-checklist`, `professional-brain`, `promotion-packet`, `proposal-skeleton`, `runbook-writer`, `self-review`, `social-content`, `source-triangulation`, `spreadsheet-audit`, `tos-decoder`, `workshop-designer`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```
