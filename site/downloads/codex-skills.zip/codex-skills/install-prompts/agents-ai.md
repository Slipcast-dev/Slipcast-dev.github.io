# Промт для установки: ИИ, Codex и агенты → Codex

Скопируй текст ниже и вставь в Codex.

```text
Установи в Codex пользовательские навыки категории «ИИ, Codex и агенты» (`agents-ai`, 146 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "agents-ai"` в `catalog/skills.json` (то же списком в `categories/agents-ai.md`), например `agent-decision-receipts`, `agent-design-review`, `agent-designer`, `agent-era-pricing`, `agent-harness`, `agent-hiring-panel`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='agents-ai']"`. Должно получиться 146.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `action-runner`, `chief-of-staff`, `dataset-datasheet`, `eval-rubric-designer`, `executive-mentor`, `file-access-preflight`, `injection-spotter`, `playwright-pro`, `pm-spec-writing`, `professional-brain`, `repo-map`, `session-handoff`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```
