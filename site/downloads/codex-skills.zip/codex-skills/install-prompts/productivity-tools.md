# Промт для установки: Продуктивность и инструменты → Codex

Скопируй текст ниже и вставь в Codex.

```text
Установи в Codex пользовательские навыки категории «Продуктивность и инструменты» (`productivity-tools`, 116 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "productivity-tools"` в `catalog/skills.json` (то же списком в `categories/productivity-tools.md`), например `archive-strategy`, `atlassian-admin`, `atlassian-templates`, `attention-reset`, `bennett-time-audit`, `body-double-session`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='productivity-tools']"`. Должно получиться 116.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `async-update-format`, `beneficiary-audit`, `blast-radius-drill`, `browser-agent-preflight`, `cs-escalation-brief`, `decision-journal`, `decision-logger`, `decision-meeting-format`, `delegation-brief`, `email-agent-preflight`, `escalation-email`, `escalation-tree`, `follow-up-chaser`, `grill-me`, `meeting-cost-meter`, `office-hours-design`, `out-of-office-designer`, `performance-profiler`, `recurring-meeting-pruner`, `saying-no-kindly`, `session-handoff`, `spreadsheet-handover`, `version-chaos-untangler`, `working-agreements`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```
