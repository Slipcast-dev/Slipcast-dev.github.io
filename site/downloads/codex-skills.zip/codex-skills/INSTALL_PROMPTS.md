# Промты для установки навыков в Codex

В этом репозитории навыки лежат одной плоской папкой `skills/` (навыки ссылаются друг на друга через `../`), а категории описаны в `catalog/skills.json`. Поэтому промт написан на каждую категорию; каждый лежит отдельным файлом в `install-prompts/<категория>.md`. Промт вставляется в Codex как есть.

| Категория | Файл | Навыков |
|---|---|---:|
| ИИ, Codex и агенты | [`install-prompts/agents-ai.md`](install-prompts/agents-ai.md) | 146 |
| Безопасность и приватность | [`install-prompts/security-privacy.md`](install-prompts/security-privacy.md) | 44 |
| Разработка ПО и архитектура | [`install-prompts/development.md`](install-prompts/development.md) | 100 |
| DevOps, облака и эксплуатация | [`install-prompts/devops-cloud.md`](install-prompts/devops-cloud.md) | 47 |
| Тестирование и качество | [`install-prompts/testing-quality.md`](install-prompts/testing-quality.md) | 30 |
| Данные и аналитика | [`install-prompts/data-analytics.md`](install-prompts/data-analytics.md) | 98 |
| Дизайн и творчество | [`install-prompts/design-creative.md`](install-prompts/design-creative.md) | 61 |
| Продукт и стратегия | [`install-prompts/product-strategy.md`](install-prompts/product-strategy.md) | 100 |
| Маркетинг, SEO и рост | [`install-prompts/marketing-growth.md`](install-prompts/marketing-growth.md) | 105 |
| Продажи и работа с клиентами | [`install-prompts/sales-customer.md`](install-prompts/sales-customer.md) | 78 |
| Бизнес и руководство | [`install-prompts/business-leadership.md`](install-prompts/business-leadership.md) | 62 |
| Управление, проекты и процессы | [`install-prompts/management-operations.md`](install-prompts/management-operations.md) | 89 |
| Карьера, HR и команды | [`install-prompts/people-career.md`](install-prompts/people-career.md) | 99 |
| Финансы, учёт и покупки | [`install-prompts/finance-personal.md`](install-prompts/finance-personal.md) | 132 |
| Право, договоры и соответствие | [`install-prompts/legal-compliance.md`](install-prompts/legal-compliance.md) | 106 |
| Тексты, документы и коммуникация | [`install-prompts/writing-communication.md`](install-prompts/writing-communication.md) | 156 |
| Обучение и образование | [`install-prompts/education-learning.md`](install-prompts/education-learning.md) | 48 |
| Здоровье и забота | [`install-prompts/health-care.md`](install-prompts/health-care.md) | 68 |
| Дом, семья и отношения | [`install-prompts/home-family.md`](install-prompts/home-family.md) | 65 |
| Путешествия, досуг и образ жизни | [`install-prompts/travel-lifestyle.md`](install-prompts/travel-lifestyle.md) | 35 |
| Продуктивность и инструменты | [`install-prompts/productivity-tools.md`](install-prompts/productivity-tools.md) | 116 |
| Отрасли, производство и строительство | [`install-prompts/industry-operations.md`](install-prompts/industry-operations.md) | 25 |

## Все навыки сразу

```text
Установи в Codex все пользовательские навыки из локальной копии репозитория `~/Desktop/codex-skills` (1810 навыков, папки лежат плоско в `skills/<имя>/`).

1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Создай `~/.agents/skills`, если её нет. Для каждой папки `skills/<имя>` с `SKILL.md`: если навык с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти, не перезаписывай; иначе скопируй папку целиком (`cp -R`).
3. Не запускай скрипты из навыков, не ставь пакеты и не настраивай MCP.
4. Проверь, что у каждого установленного навыка есть `SKILL.md` с `name` и `description`.
5. Отчёт: установлено / пропущено (с разбивкой по категориям из `catalog/skills.json`). Затем перезапусти Codex; вызов навыка — `$<имя>`.
```

## ИИ, Codex и агенты (`agents-ai`, 146)

```text
Установи в Codex пользовательские навыки категории «ИИ, Codex и агенты» (`agents-ai`, 146 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "agents-ai"` в `catalog/skills.json` (то же списком в `categories/agents-ai.md`), например `agent-decision-receipts`, `agent-design-review`, `agent-designer`, `agent-era-pricing`, `agent-harness`, `agent-hiring-panel`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='agents-ai']"`. Должно получиться 146.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `action-runner`, `chief-of-staff`, `dataset-datasheet`, `eval-rubric-designer`, `executive-mentor`, `file-access-preflight`, `injection-spotter`, `playwright-pro`, `pm-spec-writing`, `professional-brain`, `repo-map`, `session-handoff`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Безопасность и приватность (`security-privacy`, 44)

```text
Установи в Codex пользовательские навыки категории «Безопасность и приватность» (`security-privacy`, 44 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "security-privacy"` в `catalog/skills.json` (то же списком в `categories/security-privacy.md`), например `account-recovery-plan`, `ai-security`, `brand-impersonation-response`, `ciso-advisor`, `ciso-review`, `cloud-security`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='security-privacy']"`. Должно получиться 44.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `adversarial-reviewer`, `agent-protocol`, `browser-agent-preflight`, `code-reviewer`, `dependency-auditor`, `email-agent-preflight`, `file-access-preflight`, `incident-commander`, `incident-response`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Разработка ПО и архитектура (`development`, 100)

```text
Установи в Codex пользовательские навыки категории «Разработка ПО и архитектура» (`development`, 100 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "development"` в `catalog/skills.json` (то же списком в `categories/development.md`), например `adversarial-reviewer`, `api-client`, `api-design-reviewer`, `api-docs-writer`, `api-for-yourself`, `api-integration-engineering`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='development']"`. Должно получиться 100.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `andreessen`, `senior-security`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## DevOps, облака и эксплуатация (`devops-cloud`, 47)

```text
Установи в Codex пользовательские навыки категории «DevOps, облака и эксплуатация» (`devops-cloud`, 47 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "devops-cloud"` в `catalog/skills.json` (то же списком в `categories/devops-cloud.md`), например `aws-solution-architect`, `azure-cloud-architect`, `backup-and-disaster-recovery`, `backup-strategy`, `chaos-engineering`, `ci-cd-pipeline-builder`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='devops-cloud']"`. Должно получиться 47.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `action-runner`, `async-update-format`, `document-retention-map`, `plain-language-rewrite`, `pr-crisis-response`, `professional-brain`, `replica-brand`, `replica-diff`, `replica-launch`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Тестирование и качество (`testing-quality`, 30)

```text
Установи в Codex пользовательские навыки категории «Тестирование и качество» (`testing-quality`, 30 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "testing-quality"` в `catalog/skills.json` (то же списком в `categories/testing-quality.md`), например `a11y-audit`, `accessibility-audit`, `api-test-plan`, `api-test-suite-builder`, `browserstack`, `coverage`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='testing-quality']"`. Должно получиться 30.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Ссылок на навыки из других категорий нет — дополнительно ставить ничего не нужно.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Данные и аналитика (`data-analytics`, 98)

```text
Установи в Codex пользовательские навыки категории «Данные и аналитика» (`data-analytics`, 98 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "data-analytics"` в `catalog/skills.json` (то же списком в `categories/data-analytics.md`), например `ab-test-readout`, `ab-test-setup`, `analytics-strategy`, `analytics-tracking`, `autopilot-charter`, `boolean-search-builder`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='data-analytics']"`. Должно получиться 98.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `budget-tracker-design`, `citation-hygiene`, `decision-journal`, `decision-log-setup`, `deck-outline-first`, `knowledge-gardening`, `marketing-funnel-plan`, `migration-day-runbook`, `product-research`, `professional-brain`, `slide-density-rules`, `what-to-ask`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Дизайн и творчество (`design-creative`, 61)

```text
Установи в Codex пользовательские навыки категории «Дизайн и творчество» (`design-creative`, 61 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "design-creative"` в `catalog/skills.json` (то же списком в `categories/design-creative.md`), например `ad-creative`, `apple-hig-expert`, `art-direction`, `brand-identity`, `brand-style-guide`, `budget-tracker-design`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='design-creative']"`. Должно получиться 61.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `document-retention-map`, `filename-convention`, `folder-structure-designer`, `outline-before-prose`, `professional-brain`, `quarterly-tax-rhythm`, `session-handoff`, `subscription-audit`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Продукт и стратегия (`product-strategy`, 100)

```text
Установи в Codex пользовательские навыки категории «Продукт и стратегия» (`product-strategy`, 100 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "product-strategy"` в `catalog/skills.json` (то же списком в `categories/product-strategy.md`), например `agile-product-owner`, `andreessen`, `assumption-audit`, `assumption-bounty`, `assumption-mapper`, `async-decision-memo`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='product-strategy']"`. Должно получиться 100.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `action-runner`, `agent-protocol`, `async-instead`, `change-management`, `coo-advisor`, `evidence-grading`, `executive-mentor`, `interview-mapper`, `professional-brain`, `proposal-skeleton`, `scrum-master`, `spec-to-repo`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Маркетинг, SEO и рост (`marketing-growth`, 105)

```text
Установи в Codex пользовательские навыки категории «Маркетинг, SEO и рост» (`marketing-growth`, 105 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "marketing-growth"` в `catalog/skills.json` (то же списком в `categories/marketing-growth.md`), например `ad-copy`, `ads-creative-development`, `ads-performance-analytics`, `aeo`, `aeo-optimizer`, `app-store-optimization`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='marketing-growth']"`. Должно получиться 105.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `agent-protocol`, `content-creator`, `inbox-unsubscribe-purge`, `lifecycle-crm-plan`, `marketing-strategy-pmm`, `replica-design`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Продажи и работа с клиентами (`sales-customer`, 78)

```text
Установи в Codex пользовательские навыки категории «Продажи и работа с клиентами» (`sales-customer`, 78 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "sales-customer"` в `catalog/skills.json` (то же списком в `categories/sales-customer.md`), например `account-plan`, `bid-tender-review`, `car-buying-negotiation`, `case-for-support`, `channel-economics`, `chief-customer-officer-advisor`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='sales-customer']"`. Должно получиться 78.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `case-study-writeup`, `competitive-scan-lite`, `deck-narrative-arc`, `executive-summary`, `freelance-rate`, `incident-postmortem`, `incident-public-statement`, `pr-crisis-response`, `pricing-strategy`, `professional-brain`, `spreadsheet-handover`, `subscription-audit`, `tos-decoder`, `vendor-breakup-email`, `vendor-comparison-matrix`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Бизнес и руководство (`business-leadership`, 62)

```text
Установи в Codex пользовательские навыки категории «Бизнес и руководство» (`business-leadership`, 62 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "business-leadership"` в `catalog/skills.json` (то же списком в `categories/business-leadership.md`), например `acquirer-red-team`, `agm-in-a-box`, `arquiteto-de-empresa`, `board`, `board-deck-builder`, `board-deck-narrative`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='business-leadership']"`. Должно получиться 62.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `agent-protocol`, `challenge`, `chief-ai-officer-advisor`, `chief-customer-officer-advisor`, `chief-data-officer-advisor`, `context-engine`, `cs-onboard`, `deck-narrative-arc`, `deck-outline-first`, `exec-vs-working-deck`, `first-client-contract`, `general-counsel-advisor`, `handbook-page`, `hard-call`, `offsite-planner`, `postmortem`, `presenter-notes`, `professional-brain`, `proposal-skeleton`, `quarterly-tax-rhythm`, `stress-test`, `travel-brief`, `wedding-budget`, `wedding-logistics-planner`, `workshop-designer`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Управление, проекты и процессы (`management-operations`, 89)

```text
Установи в Codex пользовательские навыки категории «Управление, проекты и процессы» (`management-operations`, 89 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "management-operations"` в `catalog/skills.json` (то же списком в `categories/management-operations.md`), например `action-runner`, `after-action-report`, `agenda-or-cancel`, `ambiguity-resolver`, `analyst-relations-brief`, `application-tracker`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='management-operations']"`. Должно получиться 89.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `board-meeting`, `channel-hygiene`, `citation-hygiene`, `context-engine`, `context-switch-budget`, `contract-renewal-tracker`, `decision-log-setup`, `decision-logger`, `decision-meeting-format`, `deep-work-blocking`, `demo-script`, `doc-versioning-discipline`, `executive-mentor`, `faq-builder`, `handbook-page`, `professional-brain`, `purchase-justification`, `relocation-planner`, `repo-map`, `runbook-writer`, `skill-vetting`, `status-report-pipeline`, `survey-design-basics`, `template-designer`, `the-price-pushback`, `tos-decoder`, `vendor-comparison-matrix`, `working-agreements`, `workshop-designer`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Карьера, HR и команды (`people-career`, 99)

```text
Установи в Codex пользовательские навыки категории «Карьера, HR и команды» (`people-career`, 99 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "people-career"` в `catalog/skills.json` (то же списком в `categories/people-career.md`), например `360-feedback-template`, `academic-cv`, `apprentice-first-week`, `ask-for-a-raise`, `ats-detector`, `benefits-cliff-check`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='people-career']"`. Должно получиться 99.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `ai-assisted-performance-review`, `brag-doc`, `company-brief`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Финансы, учёт и покупки (`finance-personal`, 132)

```text
Установи в Codex пользовательские навыки категории «Финансы, учёт и покупки» (`finance-personal`, 132 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "finance-personal"` в `catalog/skills.json` (то же списком в `categories/finance-personal.md`), например `401k-plan-decoder`, `annual-report-tutor`, `appliance-buying-guide`, `audited-boundary-check`, `auto-repair-estimate-decoder`, `bank-fee-refund`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='finance-personal']"`. Должно получиться 132.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `budget-tracker-design`, `citation-hygiene`, `contract-renewal-tracker`, `exec-vs-working-deck`, `expense-sheet-design`, `meeting-cost-meter`, `policy-drafter`, `proposal-skeleton`, `saying-no-kindly`, `spreadsheet-or-database`, `token-cost`, `vendor-comparison-matrix`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Право, договоры и соответствие (`legal-compliance`, 106)

```text
Установи в Codex пользовательские навыки категории «Право, договоры и соответствие» (`legal-compliance`, 106 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "legal-compliance"` в `catalog/skills.json` (то же списком в `categories/legal-compliance.md`), например `ai-act-readiness`, `aims-audit`, `band-agreement`, `beneficiary-audit`, `capa-officer`, `carbon-accounting-check`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='legal-compliance']"`. Должно получиться 106.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `async-update-format`, `digital-legacy-planner`, `information-security-manager-iso27001`, `late-invoice-escalation`, `ma-playbook`, `meeting-cost-meter`, `runbook-writer`, `scope-creep-response`, `template-designer`, `working-agreements`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Тексты, документы и коммуникация (`writing-communication`, 156)

```text
Установи в Codex пользовательские навыки категории «Тексты, документы и коммуникация» (`writing-communication`, 156 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "writing-communication"` в `catalog/skills.json` (то же списком в `categories/writing-communication.md`), например `all-hands-deck`, `altitude-shifter`, `announcement-card`, `apology-letter`, `awkward-message-helper`, `behuman`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='writing-communication']"`. Должно получиться 156.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `chart-choice`, `consulting-proposal`, `content-production`, `content-strategy`, `data-slide-design`, `decision-meeting-format`, `doc-versioning-discipline`, `evidence-grading`, `executive-summary`, `faq-builder`, `filename-convention`, `kpi-tracker-design`, `launch-readiness`, `localization-brief`, `meeting-prep-pack`, `onboarding-buddy-plan`, `product-launch-checklist`, `professional-brain`, `promotion-packet`, `proposal-skeleton`, `runbook-writer`, `self-review`, `social-content`, `source-triangulation`, `spreadsheet-audit`, `tos-decoder`, `workshop-designer`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Обучение и образование (`education-learning`, 48)

```text
Установи в Codex пользовательские навыки категории «Обучение и образование» (`education-learning`, 48 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "education-learning"` в `catalog/skills.json` (то же списком в `categories/education-learning.md`), например `chess-opening-coach`, `cn-class-meeting`, `cn-gaokao-planner`, `cn-homework-helper-parent`, `cn-kaoyan-planner`, `cn-lesson-plan`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='education-learning']"`. Должно получиться 48.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Ссылок на навыки из других категорий нет — дополнительно ставить ничего не нужно.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Здоровье и забота (`health-care`, 68)

```text
Установи в Codex пользовательские навыки категории «Здоровье и забота» (`health-care`, 68 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "health-care"` в `catalog/skills.json` (то же списком в `categories/health-care.md`), например `accommodation-request`, `aging-in-place-assessment`, `aging-parent-talks`, `air-quality`, `behavior-intervention-plan`, `burnout-recovery-plan`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='health-care']"`. Должно получиться 68.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `research-protocol`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Дом, семья и отношения (`home-family`, 65)

```text
Установи в Codex пользовательские навыки категории «Дом, семья и отношения» (`home-family`, 65 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "home-family"` в `catalog/skills.json` (то же списком в `categories/home-family.md`), например `after-the-disaster`, `blended-family-plan`, `boundary-setting-scripts`, `childcare-comparison`, `cn-extracurricular-plan`, `cn-help-parents-admin`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='home-family']"`. Должно получиться 65.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `benefits-decoder`, `estate-settlement-organizer`, `home-contractor-quote-decoder`, `lease-decoder`, `meeting-prep-pack`, `office-hours-design`, `recurring-meeting-pruner`, `task-triage-matrix`, `the-car-dealership`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Путешествия, досуг и образ жизни (`travel-lifestyle`, 35)

```text
Установи в Codex пользовательские навыки категории «Путешествия, досуг и образ жизни» (`travel-lifestyle`, 35 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "travel-lifestyle"` в `catalog/skills.json` (то же списком в `categories/travel-lifestyle.md`), например `accessible-travel-planner`, `arrival-setup`, `birdwatching-log`, `board-game-designer`, `board-game-night-planner`, `cocktail-from-what-i-have`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='travel-lifestyle']"`. Должно получиться 35.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `demo-script`, `expense-discipline`, `expense-sheet-design`, `meeting-prep-pack`, `out-of-office-designer`, `wedding-vendor-contract-decoder`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Продуктивность и инструменты (`productivity-tools`, 116)

```text
Установи в Codex пользовательские навыки категории «Продуктивность и инструменты» (`productivity-tools`, 116 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "productivity-tools"` в `catalog/skills.json` (то же списком в `categories/productivity-tools.md`), например `archive-strategy`, `atlassian-admin`, `atlassian-templates`, `attention-reset`, `bennett-time-audit`, `body-double-session`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='productivity-tools']"`. Должно получиться 116.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `async-update-format`, `beneficiary-audit`, `blast-radius-drill`, `browser-agent-preflight`, `cs-escalation-brief`, `decision-journal`, `decision-logger`, `decision-meeting-format`, `delegation-brief`, `email-agent-preflight`, `escalation-email`, `escalation-tree`, `follow-up-chaser`, `grill-me`, `meeting-cost-meter`, `office-hours-design`, `out-of-office-designer`, `performance-profiler`, `recurring-meeting-pruner`, `saying-no-kindly`, `session-handoff`, `spreadsheet-handover`, `version-chaos-untangler`, `working-agreements`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```

## Отрасли, производство и строительство (`industry-operations`, 25)

```text
Установи в Codex пользовательские навыки категории «Отрасли, производство и строительство» (`industry-operations`, 25 навыков) из локальной копии репозитория `~/Desktop/codex-skills`.

Как устроен репозиторий: все папки навыков лежат плоско в `~/Desktop/codex-skills/skills/<имя>/`, категория задана только в каталоге. Состав категории — записи с `"category": "industry-operations"` в `catalog/skills.json` (то же списком в `categories/industry-operations.md`), например `architectural-programme-brief`, `architectural-specification`, `architecture-client-presentation`, `bom-cost-review`, `change-order-writer`, `cn-quality-traceability`.
Куда: пользовательские навыки Codex `~/.agents/skills/<имя>/`.

Шаги:
1. Если `~/Desktop/codex-skills` нет — склонируй `https://github.com/Slipcast-dev/codex-skills.git` туда.
2. Получи список имён из корня репозитория: `python3 -c "import json;[print(s['name']) for s in json.load(open('catalog/skills.json'))['skills'] if s['category']=='industry-operations']"`. Должно получиться 25.
3. Создай `~/.agents/skills`, если её нет. Для каждого имени: если папка с таким именем уже есть в `~/.agents/skills` или `~/.codex/skills` — пропусти и запиши в отчёт, не перезаписывай. Иначе скопируй `skills/<имя>` целиком (`cp -R`), вместе с `WORKFLOW.md`, `references/`, `scripts/`, `LICENSE`.
4. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на соседние навыки из других категорий: `boolean-search-builder`, `competitive-scan-lite`, `demo-script`, `proposal-skeleton`, `recruiter-outreach`, `survey-design-basics`, `vendor-breakup-email`. Установи их тоже — по тем же правилам.
5. Не запускай скрипты из папок навыков, не ставь пакеты и не настраивай MCP — только копирование файлов. Если в `SKILL.md` указаны внешние зависимости (программы, MCP, API-ключи), перечисли их в отчёте.
6. Проверка: у каждого навыка категории есть `~/.agents/skills/<имя>/SKILL.md` (или он уже был в `~/.codex/skills`) с полями `name` и `description` в YAML-заголовке.
7. Отчёт: сколько установлено, сколько пропущено и какие, какие зависимости доставлены, что требует ручной настройки.

После установки перезапусти Codex. Навык вызывается упоминанием `$<имя-навыка>` в запросе или выбирается Codex автоматически по описанию.
```
