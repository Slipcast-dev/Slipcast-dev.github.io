# Промты для установки навыков в Claude Code

Каждый промт вставляется в Claude Code как есть. Тот же промт лежит в файле `INSTALL_PROMPT.md` внутри папки категории.

| Категория | Папка | Навыков |
|---|---|---:|
| ИИ и агенты | [`skills/ai-agents/`](skills/ai-agents/INSTALL_PROMPT.md) | 174 |
| Разработка ПО | [`skills/software-engineering/`](skills/software-engineering/INSTALL_PROMPT.md) | 175 |
| Безопасность и соответствие требованиям | [`skills/security-compliance/`](skills/security-compliance/INSTALL_PROMPT.md) | 61 |
| Данные и аналитика | [`skills/data-analytics/`](skills/data-analytics/INSTALL_PROMPT.md) | 80 |
| Продукт и дизайн | [`skills/product-design/`](skills/product-design/INSTALL_PROMPT.md) | 68 |
| Маркетинг, продажи и рост | [`skills/marketing-sales/`](skills/marketing-sales/INSTALL_PROMPT.md) | 181 |
| Бизнес, стратегия и финансы | [`skills/business-strategy/`](skills/business-strategy/INSTALL_PROMPT.md) | 188 |
| Команды, HR и лидерство | [`skills/people-leadership/`](skills/people-leadership/INSTALL_PROMPT.md) | 137 |
| Тексты и коммуникация | [`skills/writing-communication/`](skills/writing-communication/INSTALL_PROMPT.md) | 255 |
| Образование и исследования | [`skills/education-research/`](skills/education-research/INSTALL_PROMPT.md) | 75 |
| Продуктивность и рабочие процессы | [`skills/productivity/`](skills/productivity/INSTALL_PROMPT.md) | 115 |
| Мышление и принятие решений | [`skills/thinking-decisions/`](skills/thinking-decisions/INSTALL_PROMPT.md) | 26 |
| Право и государственные услуги | [`skills/legal-government/`](skills/legal-government/INSTALL_PROMPT.md) | 53 |
| Личные финансы | [`skills/personal-finance/`](skills/personal-finance/INSTALL_PROMPT.md) | 63 |
| Здоровье и благополучие | [`skills/health-wellness/`](skills/health-wellness/INSTALL_PROMPT.md) | 27 |
| Дом, семья и образ жизни | [`skills/personal-life/`](skills/personal-life/INSTALL_PROMPT.md) | 138 |

## Все категории сразу

```text
Установи в Claude Code все навыки из локальной копии репозитория `~/Desktop/claude-skills` (1816 навыков в 16 категориях).

1. Если `~/Desktop/claude-skills` нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` туда.
2. Прочитай `scripts/install.sh` и выполни из корня репозитория `scripts/install.sh` без аргументов. Он раскладывает навыки плоско в `~/.claude/skills/<имя>/`, копирует папки целиком и пропускает уже установленные. Ничего не перезаписывай.
3. Не запускай скрипты из папок навыков и не ставь пакеты.
4. `driver-mas` требует `~/.claude/mas/bin/mas` и определения агентов, `skill-finder` — `~/.claude/skill-index.tsv`. Проверь их наличие и сообщи.
5. Проверь, что у каждого установленного навыка есть `SKILL.md` с `name` и `description`.
6. Отчёт: установлено / пропущено по категориям. Если навыки не видны в `/`, перезапусти Claude Code.
```

## ИИ и агенты (`ai-agents`, 174)

```text
Установи в Claude Code навыки (Agent Skills) категории «ИИ и агенты» (`ai-agents`, 174 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/ai-agents/` — каждая подпапка с `SKILL.md` это один навык (например `action-runner`, `aeo`, `agent-decision-receipts`, `agent-design-review`, `agent-designer`, `agent-era-pricing`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/ai-agents` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh ai-agents`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `chief-of-staff`, `cloud-security`, `compliance-readiness`, `dataset-datasheet`, `executive-mentor`, `incident-response`, `professional-brain`, `promotion-packet`, `security-pen-testing`, `self-review`, `threat-detection`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
   `driver-mas` требует отдельно настроенный MAS CLI (`~/.claude/mas/bin/mas`) и определения агентов, `skill-finder` — индекс `~/.claude/skill-index.tsv`. Установщик их не создаёт: проверь, есть ли они, и сообщи мне.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 158 из 174 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 16 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Разработка ПО (`software-engineering`, 175)

```text
Установи в Claude Code навыки (Agent Skills) категории «Разработка ПО» (`software-engineering`, 175 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/software-engineering/` — каждая подпапка с `SKILL.md` это один навык (например `adversarial-reviewer`, `ai-code-review`, `air-quality`, `api-design-reviewer`, `api-integration-engineering`, `api-test-plan`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/software-engineering` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh software-engineering`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `agent-protocol`, `browser-automation`, `customer-success-manager`, `document-retention-map`, `executive-mentor`, `folder-structure-designer`, `incident-response`, `red-team`, `replica-brand`, `replica-launch`, `security-pen-testing`, `session-handoff`, `spreadsheet-audit`, `threat-detection`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 135 из 175 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 40 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Безопасность и соответствие требованиям (`security-compliance`, 61)

```text
Установи в Claude Code навыки (Agent Skills) категории «Безопасность и соответствие требованиям» (`security-compliance`, 61 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/security-compliance/` — каждая подпапка с `SKILL.md` это один навык (например `account-recovery-plan`, `atlassian-admin`, `brand-impersonation-response`, `chuhai-market-entry`, `ciso-advisor`, `ciso-review`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/security-compliance` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh security-compliance`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `adversarial-reviewer`, `agent-protocol`, `ai-act-readiness`, `ai-security`, `aims-audit`, `cloud-security`, `code-reviewer`, `incident-commander`, `mdr-745-specialist`, `pr-crisis-response`, `quality-manager-qms-iso13485`, `red-team`, `risk-management-specialist`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 54 из 61 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 7 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Данные и аналитика (`data-analytics`, 80)

```text
Установи в Claude Code навыки (Agent Skills) категории «Данные и аналитика» (`data-analytics`, 80 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/data-analytics/` — каждая подпапка с `SKILL.md` это один навык (например `ab-test-planner`, `ab-test-readout`, `ab-test-setup`, `ads-performance-analytics`, `analytics-strategy`, `analytics-tracking`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/data-analytics` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh data-analytics`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `budget-tracker-design`, `citation-hygiene`, `decision-journal`, `deck-outline-first`, `interview-synthesis`, `professional-brain`, `scam-message-decoder`, `slide-density-rules`, `source-triangulation`, `survey-design-basics`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 74 из 80 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 6 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Продукт и дизайн (`product-design`, 68)

```text
Установи в Claude Code навыки (Agent Skills) категории «Продукт и дизайн» (`product-design`, 68 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/product-design/` — каждая подпапка с `SKILL.md` это один навык (например `a11y-audit`, `accessibility-audit`, `agile-product-owner`, `ai-feature-prd`, `art-direction`, `brand-identity`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/product-design` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh product-design`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `adversarial-reviewer`, `agent-spec`, `ai-eval-plan`, `code-reviewer`, `experiment-designer`, `faq-builder`, `llm-cost-latency-budget`, `professional-brain`, `rag-design-doc`, `scrum-master`, `senior-security`, `spec-to-repo`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 62 из 68 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 6 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Маркетинг, продажи и рост (`marketing-sales`, 181)

```text
Установи в Claude Code навыки (Agent Skills) категории «Маркетинг, продажи и рост» (`marketing-sales`, 181 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/marketing-sales/` — каждая подпапка с `SKILL.md` это один навык (например `account-plan`, `ad-copy`, `ad-creative`, `ads-creative-development`, `aeo-optimizer`, `altitude-shifter`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/marketing-sales` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh marketing-sales`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `action-runner`, `agent-protocol`, `async-update-format`, `citation-hygiene`, `content-creator`, `cs-escalation-brief`, `deck-narrative-arc`, `deck-outline-first`, `doc-versioning-discipline`, `exec-vs-working-deck`, `executive-summary`, `freelance-rate`, `handbook-page`, `interview-synthesis`, `kpi-tracker-design`, `offsite-planner`, `plain-language-rewrite`, `presenter-notes`, `professional-brain`, `renewal-playbook`, `replica-design`, `repo-map`, `session-handoff`, `travel-brief`, `wedding-budget`, `wedding-logistics-planner`, `workshop-designer`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 172 из 181 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 9 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Бизнес, стратегия и финансы (`business-strategy`, 188)

```text
Установи в Claude Code навыки (Agent Skills) категории «Бизнес, стратегия и финансы» (`business-strategy`, 188 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/business-strategy/` — каждая подпапка с `SKILL.md` это один навык (например `ambiguity-resolver`, `approval-policy-designer`, `architectural-programme-brief`, `archive-strategy`, `arquiteto-de-empresa`, `audited-boundary-check`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/business-strategy` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh business-strategy`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `agent-protocol`, `async-update-format`, `atlassian-templates`, `beneficiary-audit`, `boolean-search-builder`, `capa-officer`, `chief-data-officer-advisor`, `context-crusher`, `decision-log-setup`, `deep-work-blocking`, `demo-script`, `email-triage-system`, `evidence-grading`, `faq-builder`, `filename-convention`, `folder-structure-designer`, `general-counsel-advisor`, `hard-call`, `incident-postmortem`, `meeting-cost-meter`, `office-hours-design`, `postmortem`, `professional-brain`, `proposal-skeleton`, `purchase-justification`, `quality-documentation-manager`, `quality-manager-qms-iso13485`, `recruiter-outreach`, `recurring-meeting-pruner`, `regulatory-affairs-head`, `repo-map`, `runbook-writer`, `saying-no-kindly`, `session-handoff`, `skill-vetting`, `spreadsheet-handover`, `stress-test`, `subscription-audit`, `survey-design-basics`, `template-designer`, `the-price-pushback`, `token-cost`, `token-diet`, `tos-decoder`, `working-agreements`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 188 из 188 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 0 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Команды, HR и лидерство (`people-leadership`, 137)

```text
Установи в Claude Code навыки (Agent Skills) категории «Команды, HR и лидерство» (`people-leadership`, 137 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/people-leadership/` — каждая подпапка с `SKILL.md` это один навык (например `360-feedback-template`, `acquirer-red-team`, `after-action-report`, `andreessen`, `application-tracker`, `ar-resume`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/people-leadership` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh people-leadership`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `agenda-or-cancel`, `agent-protocol`, `brag-doc`, `capa-officer`, `case-study-writeup`, `channel-hygiene`, `context-switch-budget`, `decision-journal`, `deep-work-blocking`, `demo-script`, `desk-research-sprint`, `document-retention-map`, `folder-structure-designer`, `office-hours-design`, `product-research`, `proposal-skeleton`, `qms-audit-expert`, `quality-documentation-manager`, `research-repo-setup`, `risk-management-specialist`, `runbook-writer`, `source-triangulation`, `survey-design-basics`, `template-designer`, `the-price-pushback`, `workshop-designer`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 136 из 137 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 1 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Тексты и коммуникация (`writing-communication`, 255)

```text
Установи в Claude Code навыки (Agent Skills) категории «Тексты и коммуникация» (`writing-communication`, 255 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/writing-communication/` — каждая подпапка с `SKILL.md` это один навык (например `all-hands-deck`, `analyst-relations-brief`, `announcement-card`, `api-docs-writer`, `apology-letter`, `architectural-specification`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/writing-communication` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh writing-communication`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `action-runner`, `brag-doc`, `chart-choice`, `citation-hygiene`, `consulting-proposal`, `content-strategy`, `counteroffer-decoder`, `data-slide-design`, `digital-legacy-planner`, `doc-versioning-discipline`, `evidence-grading`, `faq-builder`, `filename-convention`, `house-style-enforcer`, `inbox-unsubscribe-purge`, `incident-public-statement`, `kpi-tracker-design`, `lifecycle-crm-plan`, `meeting-prep-pack`, `pr-crisis-response`, `presenter-notes`, `product-positioning-doc`, `professional-brain`, `proposal-skeleton`, `relocation-planner`, `review-comments-resolver`, `social-content`, `status-report-pipeline`, `support-macro`, `transcreation`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 240 из 255 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 15 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Образование и исследования (`education-research`, 75)

```text
Установи в Claude Code навыки (Agent Skills) категории «Образование и исследования» (`education-research`, 75 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/education-research/` — каждая подпапка с `SKILL.md` это один навык (например `academic-cv`, `annual-report-tutor`, `behavior-intervention-plan`, `bennett-time-audit`, `chess-opening-coach`, `citation-hygiene`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/education-research` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh education-research`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `decision-log-setup`, `interview-mapper`, `interview-synthesis`, `knowledge-gardening`, `professional-brain`, `source-triangulation`, `what-to-ask`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 69 из 75 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 6 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Продуктивность и рабочие процессы (`productivity`, 115)

```text
Установи в Claude Code навыки (Agent Skills) категории «Продуктивность и рабочие процессы» (`productivity`, 115 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/productivity/` — каждая подпапка с `SKILL.md` это один навык (например `agenda-or-cancel`, `agm-in-a-box`, `api-for-yourself`, `architecture-decision-record`, `async-decision-memo`, `atlassian-templates`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/productivity` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh productivity`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `action-runner`, `agent-protocol`, `async-instead`, `async-update-format`, `context-switch-budget`, `cs-escalation-brief`, `data-cleaning-pass`, `decision-meeting-format`, `deck-narrative-arc`, `deck-outline-first`, `delegation-brief`, `email-triage-system`, `escalation-email`, `escalation-tree`, `estate-settlement-organizer`, `exec-vs-working-deck`, `filename-convention`, `follow-up-chaser`, `lifecycle-crm-plan`, `meeting-cost-meter`, `out-of-office-designer`, `outline-before-prose`, `recurring-meeting-pruner`, `runbook-writer`, `saying-no-kindly`, `standing-meeting-audit`, `version-chaos-untangler`, `working-agreements`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 111 из 115 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 4 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Мышление и принятие решений (`thinking-decisions`, 26)

```text
Установи в Claude Code навыки (Agent Skills) категории «Мышление и принятие решений» (`thinking-decisions`, 26 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/thinking-decisions/` — каждая подпапка с `SKILL.md` это один навык (например `assumption-audit`, `assumption-bounty`, `assumption-mapper`, `brainstorming`, `business-idea-validator`, `devils-advocate-on-demand`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/thinking-decisions` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh thinking-decisions`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `cloud-security`, `incident-response`, `security-pen-testing`, `threat-detection`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 25 из 26 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 1 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Право и государственные услуги (`legal-government`, 53)

```text
Установи в Claude Code навыки (Agent Skills) категории «Право и государственные услуги» (`legal-government`, 53 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/legal-government/` — каждая подпапка с `SKILL.md` это один навык (например `band-agreement`, `car-lease-decoder`, `class-action-claim-finder`, `cn-severance-calculator`, `contract-review`, `digital-death-plan`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/legal-government` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh legal-government`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `benefits-decoder`, `home-contractor-quote-decoder`, `late-invoice-escalation`, `launch-readiness`, `product-launch-checklist`, `scope-creep-response`, `the-car-dealership`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 53 из 53 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 0 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Личные финансы (`personal-finance`, 63)

```text
Установи в Claude Code навыки (Agent Skills) категории «Личные финансы» (`personal-finance`, 63 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/personal-finance/` — каждая подпапка с `SKILL.md` это один навык (например `401k-plan-decoder`, `arrival-setup`, `auto-repair-estimate-decoder`, `bank-fee-refund`, `bankruptcy-decision`, `big-purchase-timing`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/personal-finance` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh personal-finance`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `citation-hygiene`, `emergency-fund`, `exec-vs-working-deck`, `first-client-contract`, `meeting-cost-meter`, `pricing-your-services`, `proposal-skeleton`, `quarterly-tax-rhythm`, `spreadsheet-or-database`, `token-diet`, `vendor-comparison-matrix`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 63 из 63 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 0 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Здоровье и благополучие (`health-wellness`, 27)

```text
Установи в Claude Code навыки (Agent Skills) категории «Здоровье и благополучие» (`health-wellness`, 27 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/health-wellness/` — каждая подпапка с `SKILL.md` это один навык (например `accommodation-request`, `burnout-recovery-plan`, `clinical-trial-protocol`, `controlled-substance-audit`, `couch-to-goal-runner`, `diagnosis-limbo-kit`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/health-wellness` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh health-wellness`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `research-protocol`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 27 из 27 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 0 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```

## Дом, семья и образ жизни (`personal-life`, 138)

```text
Установи в Claude Code навыки (Agent Skills) категории «Дом, семья и образ жизни» (`personal-life`, 138 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/personal-life/` — каждая подпапка с `SKILL.md` это один навык (например `accessible-travel-planner`, `after-the-disaster`, `aging-in-place-assessment`, `aging-parent-talks`, `appliance-buying-guide`, `apprentice-first-week`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/personal-life` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh personal-life`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `data-breach-response`, `demo-script`, `doc-versioning-discipline`, `estate-settlement-organizer`, `expense-discipline`, `expense-sheet-design`, `faq-builder`, `folder-structure-designer`, `iep-504-meeting-kit`, `inspection-report-decoder`, `medical-records-request`, `meeting-prep-pack`, `office-hours-design`, `out-of-office-designer`, `recurring-meeting-pruner`, `session-handoff`, `shared-drive-cleanup`, `spreadsheet-handover`, `statement-coach`, `sun-and-moon`, `task-triage-matrix`, `token-cost`, `version-chaos-untangler`, `wedding-vendor-contract-decoder`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 138 из 138 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 0 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```
