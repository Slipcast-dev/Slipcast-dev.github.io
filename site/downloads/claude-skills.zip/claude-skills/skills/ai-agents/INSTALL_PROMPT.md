# Промт для установки: ИИ и агенты → Claude Code

Скопируй текст ниже и вставь в Claude Code.

```text
Установи в Claude Code навыки (Agent Skills) категории «ИИ и агенты» (`ai-agents`, 174 навыков) из локальной копии репозитория `~/Desktop/claude-skills`.

Источник: `~/Desktop/claude-skills/skills/ai-agents/` — каждая подпапка с `SKILL.md` это один навык (например `action-runner`, `aeo`, `agent-decision-receipts`, `agent-design-review`, `agent-designer`, `agent-era-pricing`).
Куда: личные навыки Claude Code `~/.claude/skills/<имя-навыка>/` — плоско, без папки категории.

Шаги:
1. Убедись, что `~/Desktop/claude-skills/skills/ai-agents` существует. Если репозитория нет — склонируй `https://github.com/Slipcast-dev/claude-skills.git` в `~/Desktop/claude-skills`.
2. Прочитай `scripts/install.sh`, затем выполни из корня репозитория: `scripts/install.sh ai-agents`. Скрипт копирует каждую папку навыка целиком (с `references/`, `scripts/`, `LICENSE`) и пропускает навыки, которые уже есть в `~/.claude/skills`. Ничего не перезаписывай и не удаляй.
3. Зависимости. Навыки этой категории ссылаются через `../<имя>/` на навыки из других категорий: `chief-of-staff`, `cloud-security`, `compliance-readiness`, `dataset-datasheet`, `executive-mentor`, `incident-response`, `professional-brain`, `promotion-packet`, `security-pen-testing`, `self-review`, `threat-detection`. Найди каждый в `~/Desktop/claude-skills/skills/*/<имя>` и установи так же — целой папкой и без перезаписи.
4. Не запускай скрипты из папок навыков и не ставь пакеты — только копирование файлов.
   `driver-mas` требует отдельно настроенный MAS CLI (`~/.claude/mas/bin/mas`) и определения агентов, `skill-finder` — индекс `~/.claude/skill-index.tsv`. Установщик их не создаёт: проверь, есть ли они, и сообщи мне.
5. Проверка: для каждого навыка категории должен существовать `~/.claude/skills/<имя>/SKILL.md` с полями `name` и `description` в YAML-заголовке, а `name` должен совпадать с именем папки.
6. Отчёт: сколько навыков установлено, сколько пропущено (уже были) и каких именно, какие зависимости доставлены, какие проблемы найдены.

Справка: 158 из 174 навыков имеют `disable-model-invocation: true` и вызываются только явно — командой `/<имя-навыка>`; ещё 16 Claude может выбирать автоматически. Если навыки не появились в списке `/`, перезапусти Claude Code.
```
